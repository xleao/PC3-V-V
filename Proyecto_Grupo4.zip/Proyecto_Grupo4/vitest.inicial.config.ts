import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['__tests__/setup.ts'],
    include: [
      'tests/cobertura-inicial/mi-reserva-card.inicial.test.tsx',
    ],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html', 'json-summary', 'json'],
      include: [
        'src/components/condominios/espacios-comunes-usuario/mi-reserva-card.tsx',
      ],
    },
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      'firebase-functions/v2/scheduler': path.resolve(__dirname, './tests/stubs/firebase-functions-scheduler.ts'),
      'firebase-admin': path.resolve(__dirname, './tests/stubs/firebase-admin.ts'),
    },
  },
});
