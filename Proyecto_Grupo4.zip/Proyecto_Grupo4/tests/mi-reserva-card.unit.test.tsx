import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { Timestamp } from 'firebase/firestore';
import type { ReservaEspacioComun } from '@/types';

const toastMock = vi.fn();

vi.mock('@/hooks/use-toast', () => ({
  useToast: () => ({ toast: toastMock }),
}));

vi.mock('@/hooks/use-language', () => ({
  useLanguage: () => ({
    language: 'es',
    t: (key: string) => {
      const dict: Record<string, string> = {
        cannotCancelReservationTitle: 'No se puede cancelar',
        cannotCancelReservationAdminProcessed: 'Esta reserva ya fue procesada por la administración.',
        cancelReservationButton: 'Cancelar Reserva',
        reservationDateTime: 'Fecha y hora',
        useTypeExclusive: 'Exclusivo',
        useTypeShared: 'Compartido',
        statusValidado: 'Validado',
        statusRechazado: 'Rechazado',
        reservationStatus_SOLICITADO: 'Solicitado',
        reservationStatus_CONFIRMADO: 'Confirmado',
        reservationStatus_RECHAZADO: 'Rechazado',
        reservationStatus_CANCELADO_USUARIO: 'Cancelado por residente',
      };
      return dict[key] || key;
    },
  }),
}));

import { MiReservaCard } from '@/components/condominios/espacios-comunes-usuario/mi-reserva-card';

const FIXED_NOW = new Date('2026-10-05T10:00:00.000-05:00');

function crearReserva(overrides: Partial<ReservaEspacioComun> = {}): ReservaEspacioComun {
  const inicio = new Date(FIXED_NOW.getTime() + 7 * 24 * 60 * 60 * 1000);
  const fin = new Date(inicio.getTime() + 4 * 60 * 60 * 1000);
  return {
    id: 'res-101',
    espacioComunId: 'esp-sum-01',
    espacioComunNombre: 'Salón de Usos Múltiples',
    usuarioId: 'usr-vecino-302',
    userDisplayName: 'Carlos Mendoza (Dpto. 302)',
    userEmail: 'cmendoza@comunidad360.pe',
    fechaHoraInicio: Timestamp.fromDate(inicio),
    fechaHoraFin: Timestamp.fromDate(fin),
    estado: 'SOLICITADO',
    esExclusivo: true,
    costoReserva: 150,
    montoAlquiler: 150,
    montoGarantia: 100,
    monedaCosto: 'S/',
    motivoReserva: 'Reunión familiar',
    ...overrides,
  } as ReservaEspacioComun;
}

describe('Pruebas Unitarias — MiReservaCard (R-04 y RFC-2026-03)', () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(FIXED_NOW);
    toastMock.mockClear();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('UT-01 [C01 / Camino P1]: Habilita y ejecuta onCancel() en reserva SOLICITADA a 7 días sin comprobante', () => {
    const onCancel = vi.fn();
    const onUploadVoucher = vi.fn();
    const reserva = crearReserva({ estado: 'SOLICITADO' });

    const { rerender } = render(
      <MiReservaCard reserva={reserva} onCancel={onCancel} onUploadVoucher={onUploadVoucher} />
    );
    const boton = screen.getByRole('button', { name: /Cancelar Reserva/i });

    expect(boton).not.toBeDisabled();
    fireEvent.click(boton);
    expect(onCancel).toHaveBeenCalledTimes(1);
    expect(toastMock).not.toHaveBeenCalled();

    // Verificación adicional de variante compartida con pago diferido pendiente en el mismo estado SOLICITADO
    rerender(
      <MiReservaCard
        reserva={crearReserva({
          estado: 'SOLICITADO',
          esExclusivo: false,
          costoReserva: 0,
          pago_diferido: true,
          pago_estado_validacion: 'pendiente',
          pago_devolucion_monto: 120,
          pago_devolucion_original: 150,
          pago_devolucion_diferencia: 30,
          pago_devolucion_fecha: Timestamp.fromDate(FIXED_NOW),
          pago_devolucion_constancia_url: 'https://storage.comunidad360.pe/dev.pdf',
          pago_devolucion_descuento_evidencia_url: 'https://storage.comunidad360.pe/evid.pdf',
          pago_devolucion_descuento_motivo: 'Penalidad administrativa',
          pago_devolucion_notas: 'Transferencia BCP',
          montoGarantia: 100,
          garantia_estado: 'devuelto',
          garantia_devolucion_monto: 80,
          garantia_devolucion_diferencia: 20,
          garantia_devolucion_fecha: Timestamp.fromDate(FIXED_NOW),
          garantia_devolucion_constancia_url: 'https://storage.comunidad360.pe/gar.pdf',
          garantia_devolucion_diferencia_evidencia_url: 'https://storage.comunidad360.pe/dano.pdf',
          garantia_devolucion_diferencia_motivo: 'Limpieza extraordinaria',
        })}
        onCancel={onCancel}
        onUploadVoucher={onUploadVoucher}
      />
    );
    fireEvent.click(screen.getByRole('button', { name: /Subir Comprobante/i }));
    expect(onUploadVoucher).toHaveBeenCalledTimes(1);
  });

  it('UT-02 [C02 / E01 / Camino P1]: Habilita cancelación en reserva CONFIRMADA a 3 días cuando dias_anticipacion_cancelacion = 2', () => {
    const onCancel = vi.fn();
    const inicio3d = new Date(FIXED_NOW.getTime() + 3 * 24 * 60 * 60 * 1000);
    const reserva = crearReserva({
      estado: 'CONFIRMADO',
      dias_anticipacion_cancelacion: 2,
      fechaHoraInicio: Timestamp.fromDate(inicio3d),
    });

    render(<MiReservaCard reserva={reserva} onCancel={onCancel} />);
    const boton = screen.getByRole('button', { name: /Cancelar Reserva/i });

    expect(boton).not.toBeDisabled();
    fireEvent.click(boton);
    expect(onCancel).toHaveBeenCalledTimes(1);
  });

  it('UT-03 [C03 / Camino P3 y P4]: Bloquea cancelación cuando falta solo 1 día (< 2 días) o en estados terminales', () => {
    const onCancel = vi.fn();
    const inicio1d = new Date(FIXED_NOW.getTime() + 1 * 24 * 60 * 60 * 1000);
    const reserva = crearReserva({
      estado: 'SOLICITADO',
      dias_anticipacion_cancelacion: 2,
      fechaHoraInicio: Timestamp.fromDate(inicio1d),
    });

    const { rerender } = render(<MiReservaCard reserva={reserva} onCancel={onCancel} />);
    const boton = screen.getByRole('button', { name: /Cancelar Reserva/i });

    expect(boton).toBeDisabled();
    expect(
      screen.getByText(/Cancelación disponible con más de 2 días de anticipación/i)
    ).toBeInTheDocument();
    expect(onCancel).not.toHaveBeenCalled();

    // Estados terminales RECHAZADO y CANCELADO_USUARIO (L42-L43)
    rerender(
      <MiReservaCard
        reserva={crearReserva({ estado: 'RECHAZADO', notasAdmin: 'Área en mantenimiento preventivo' })}
        onCancel={onCancel}
      />
    );
    expect(screen.getByRole('button', { name: /Cancelar Reserva/i })).toBeDisabled();

    rerender(<MiReservaCard reserva={crearReserva({ estado: 'CANCELADO_USUARIO' })} onCancel={onCancel} />);
    expect(screen.getByRole('button', { name: /Cancelar Reserva/i })).toBeDisabled();
  });

  it('UT-04 [C06 / Camino P2]: Bloquea cancelación cuando existe comprobante validado y muestra aviso de pago', () => {
    const onCancel = vi.fn();
    const reserva = crearReserva({
      estado: 'CONFIRMADO',
      dias_anticipacion_cancelacion: 2,
      pagoNroOperacion: 'OP-772190',
      pago_estado_validacion: 'validado',
    });

    const { rerender } = render(<MiReservaCard reserva={reserva} onCancel={onCancel} />);
    const boton = screen.getByRole('button', { name: /Cancelar Reserva/i });

    expect(boton).toBeDisabled();
    expect(
      screen.getByText(/No puedes cancelar una reserva con pago registrado/i)
    ).toBeInTheDocument();
    expect(onCancel).not.toHaveBeenCalled();

    // Variante con comprobante solo por imagen (pagoConstanciaUrl)
    rerender(
      <MiReservaCard
        reserva={crearReserva({
          estado: 'SOLICITADO',
          dias_anticipacion_cancelacion: 2,
          pagoNroOperacion: null,
          pagoConstanciaUrl: 'https://storage.comunidad360.pe/vouchers/v01.png',
          pago_estado_validacion: 'validado',
        })}
        onCancel={onCancel}
      />
    );
    expect(screen.getByRole('button', { name: /Cancelar Reserva/i })).toBeDisabled();
    expect(screen.getByText(/Ver Voucher/i)).toBeInTheDocument();

    // Variante con comprobante en estado pendiente (bloqueada igualmente en L66 del código original)
    rerender(
      <MiReservaCard
        reserva={crearReserva({
          estado: 'SOLICITADO',
          dias_anticipacion_cancelacion: 2,
          pagoNroOperacion: 'OP-998123',
          pago_estado_validacion: 'pendiente',
          montoGarantia: undefined,
          motivoReserva: undefined,
          userDisplayName: undefined,
        })}
        onCancel={onCancel}
      />
    );
    expect(screen.getByRole('button', { name: /Cancelar Reserva/i })).toBeDisabled();
  });

  it('UT-05 [E06 / Excepción]: Lanza TypeError cuando fechaHoraInicio es nula (evidencia del defecto P-10)', () => {
    const onCancel = vi.fn();
    const reservaNula = crearReserva({
      fechaHoraInicio: null as unknown as Timestamp,
    });

    expect(() => {
      render(<MiReservaCard reserva={reservaNula} onCancel={onCancel} />);
    }).toThrow(TypeError);
  });
});
