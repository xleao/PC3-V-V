// Pruebas escritas contra la ESPECIFICACIÓN (R-04 + RFC-2026-03). Se espera que FALLEN con el código actual
// (D-01 y D-03): son la evidencia del análisis de falla. No forman parte de la suite de 8 pruebas que pasan.
import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { Timestamp } from 'firebase/firestore';
import { MiReservaCard } from '@/components/condominios/espacios-comunes-usuario/mi-reserva-card';

vi.mock('@/hooks/use-toast', () => ({ useToast: () => ({ toast: vi.fn() }) }));
vi.mock('@/hooks/use-language', () => ({ useLanguage: () => ({ language: 'es', t: (k: string) => (k === 'cancelReservationButton' ? 'Cancelar Reserva' : k) }) }));

const AHORA = new Date('2026-10-05T10:00:00.000-05:00');
const enDias = (n: number) => Timestamp.fromDate(new Date(AHORA.getTime() + n * 86400000));
const reserva = (o: any = {}) => ({
  id: 'r1', espacioComunId: 'e1', espacioComunNombre: 'Salón', usuarioId: 'u1', userDisplayName: 'Carlos', userEmail: 'c@x.pe',
  fechaHoraInicio: enDias(7), fechaHoraFin: enDias(7), estado: 'SOLICITADO', esExclusivo: true, ...o,
});
const boton = () => screen.getByRole('button', { name: /Cancelar Reserva/i });

describe('Defectos frente a la especificación', () => {
  beforeEach(() => { vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(AHORA); });
  afterEach(() => vi.useRealTimers());

  it('D-01 [C04] sin plazo propio, faltando 3 días, se debe poder cancelar (plazo por defecto = 2)', () => {
    render(<MiReservaCard reserva={reserva({ fechaHoraInicio: enDias(3) }) as any} onCancel={vi.fn()} />);
    expect(boton()).not.toBeDisabled();
  });

  it('D-01b [límite] con exactamente 2 días de anticipación se debe poder cancelar (al menos 2 días)', () => {
    render(<MiReservaCard reserva={reserva({ fechaHoraInicio: enDias(2), dias_anticipacion_cancelacion: 2 }) as any} onCancel={vi.fn()} />);
    expect(boton()).not.toBeDisabled();
  });

  it('D-03 [pendiente] con comprobante PENDIENTE (no validado) se debe poder cancelar', () => {
    render(<MiReservaCard reserva={reserva({ dias_anticipacion_cancelacion: 2, pagoNroOperacion: 'OP-551', pago_estado_validacion: 'pendiente' }) as any} onCancel={vi.fn()} />);
    expect(boton()).not.toBeDisabled();
  });
});
