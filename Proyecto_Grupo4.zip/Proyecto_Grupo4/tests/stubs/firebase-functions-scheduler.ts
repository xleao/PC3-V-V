export const onSchedule = (_schedule: string, handler: () => Promise<void>) => ({ run: handler });
