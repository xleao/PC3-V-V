export const apps: any[] = [];
export const initializeApp = () => {};
export const firestore: any = () => ({});
