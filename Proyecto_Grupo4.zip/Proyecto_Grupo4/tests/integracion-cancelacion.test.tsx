import React from 'react';
import { render, screen, fireEvent, waitFor, within } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { Timestamp } from 'firebase/firestore';

const updateDocMock = vi.fn().mockResolvedValue(undefined);
const docMock = vi.fn((_db, ...segments: string[]) => ({ path: segments.join('/') }));
const serverTimestampMock = vi.fn(() => ({ _sentinel: 'SERVER_TIMESTAMP' }));
const toastIntegrationMock = vi.fn();
const mockReservationsList: any[] = [];

const mockRouter = { push: vi.fn(), replace: vi.fn(), back: vi.fn(), prefetch: vi.fn() };
const mockParams = { condominioId: 'condo-piloto-01' };
const mockSearchParams = new URLSearchParams();
const mockAuthReturn = {
  user: { uid: 'usr-vecino-302', email: 'cmendoza@comunidad360.pe', displayName: 'Carlos Mendoza' },
  authLoading: false,
};
const mockCondoReturn = {
  selectedCondominio: { id: 'condo-piloto-01', nombre: 'Condominio Piloto' },
  isLoading: false,
};
const mockToastReturn = { toast: toastIntegrationMock };
const dictLang: Record<string, string> = {
  myReservationsTitle: 'Mis Reservas',
  cancelReservationButton: 'Cancelar Reserva',
  confirmCancelReservationTitle: '¿Confirmar cancelación?',
  confirmCancelReservationDesc: '¿Deseas cancelar tu reserva?',
  cancel: 'Volver',
  confirmCancel: 'Confirmar Cancelación',
  reservationCancelledSuccess: 'Reserva cancelada con éxito',
  reservationStatus_SOLICITADO: 'Solicitado',
  reservationDateTime: 'Fecha y hora',
  useTypeExclusive: 'Exclusivo',
  errorOccurred: 'Ocurrió un error',
};
const mockT = (key: string) => dictLang[key] || key;
const mockLanguageReturn = { language: 'es', t: mockT };

vi.mock('next/navigation', () => ({
  useRouter: () => mockRouter,
  useParams: () => mockParams,
  useSearchParams: () => mockSearchParams,
}));

vi.mock('@/components/layout/app-shell', () => ({
  AppShell: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

vi.mock('@/components/shared/page-title', () => ({
  PageTitle: ({ title }: { title: string }) => <h1>{title}</h1>,
}));

vi.mock('@/contexts/auth-context', () => ({
  useAuth: () => mockAuthReturn,
}));

vi.mock('@/contexts/condominio-context', () => ({
  useCondominioContext: () => mockCondoReturn,
}));

vi.mock('@/hooks/use-mobile', () => ({
  useIsMobile: () => false,
}));

vi.mock('@/components/ui/dialog', () => ({
  Dialog: ({ open, children }: { open: boolean; children: React.ReactNode }) => (open ? <div>{children}</div> : null),
  DialogContent: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  DialogHeader: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  DialogTitle: ({ children }: { children: React.ReactNode }) => <h2>{children}</h2>,
  DialogDescription: ({ children }: { children: React.ReactNode }) => <p>{children}</p>,
}));

vi.mock('@/components/ui/alert-dialog', () => ({
  AlertDialog: ({ open, children }: { open: boolean; children: React.ReactNode }) => (open ? <div role="alertdialog">{children}</div> : null),
  AlertDialogContent: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  AlertDialogHeader: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  AlertDialogTitle: ({ children }: { children: React.ReactNode }) => <h2>{children}</h2>,
  AlertDialogDescription: ({ children }: { children: React.ReactNode }) => <p>{children}</p>,
  AlertDialogFooter: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  AlertDialogCancel: ({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) => <button onClick={onClick}>{children}</button>,
  AlertDialogAction: ({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) => <button onClick={onClick}>{children}</button>,
}));

vi.mock('@/hooks/use-toast', () => ({
  useToast: () => mockToastReturn,
}));

vi.mock('@/hooks/use-language', () => ({
  useLanguage: () => mockLanguageReturn,
}));

vi.mock('@/lib/image-compress', () => ({
  compressImage: vi.fn(),
}));

vi.mock('firebase/storage', () => ({
  ref: vi.fn(),
  uploadBytesResumable: vi.fn(),
  getDownloadURL: vi.fn(),
}));

vi.mock('firebase/firestore', async () => {
  const actual = await vi.importActual<typeof import('firebase/firestore')>('firebase/firestore');
  return {
    ...actual,
    collectionGroup: vi.fn(() => ({})),
    query: vi.fn(() => ({})),
    where: vi.fn(() => ({})),
    orderBy: vi.fn(() => ({})),
    onSnapshot: vi.fn((_q, onNext) => {
      onNext({
        docs: mockReservationsList.map((r) => ({
          id: r.id,
          ref: { parent: { parent: { id: r.espacioComunId } } },
          data: () => r,
        })),
      });
      return () => {};
    }),
    doc: (...args: any[]) => docMock(args[0], ...args.slice(1)),
    getDoc: vi.fn().mockResolvedValue({
      exists: () => true,
      data: () => ({ departamentos_asignados: ['dpto-302'] }),
    }),
    updateDoc: (...args: any[]) => updateDocMock(...args),
    serverTimestamp: () => serverTimestampMock(),
  };
});

import MyReservationsPage from '@/app/condominios/[condominioId]/espacios-comunes-usuario/mis-reservas/page';

const FIXED_NOW = new Date('2026-10-05T10:00:00.000-05:00');

describe('Pruebas de Integración — Colaboración real MyReservationsPage + MiReservaCard + date-fns', () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(FIXED_NOW);
    vi.clearAllMocks();
    mockReservationsList.length = 0;
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('IT-01 [Flujo Integrado Completo]: Desde selección en MyReservationsPage real, apertura de MiReservaCard real y confirmación actualiza Firestore', async () => {
    const inicio6d = new Date(FIXED_NOW.getTime() + 6 * 24 * 60 * 60 * 1000);
    mockReservationsList.push({
      id: 'res-int-01',
      espacioComunId: 'esp-sum-01',
      espacioComunNombre: 'Salón de Usos Múltiples',
      usuarioId: 'usr-vecino-302',
      userDisplayName: 'Carlos Mendoza',
      fechaHoraInicio: Timestamp.fromDate(inicio6d),
      fechaHoraFin: Timestamp.fromDate(new Date(inicio6d.getTime() + 3600000)),
      estado: 'SOLICITADO',
      dias_anticipacion_cancelacion: 2,
      esExclusivo: true,
      montoGarantia: 100,
      pago_diferido: true,
      pago_estado_validacion: 'pendiente',
    });

    render(<MyReservationsPage />);

    // 1. Clic en el botón "Ver detalle" de MyReservationsPage para abrir el detalle (MiReservaCard real)
    const btnDetalle = await screen.findByTitle('Ver detalle');
    fireEvent.click(btnDetalle);
    await screen.findByText(/Detalle de Reserva/i);

    // 2. Verificar que MiReservaCard real renderiza la reserva y habilita el botón Cancelar Reserva
    const btnsCard = await screen.findAllByRole('button', { name: /Cancelar Reserva/i });
    expect(btnsCard[0]).not.toBeDisabled();
    fireEvent.click(btnsCard[0]);

    // 3. Confirmar dentro del AlertDialog real de MyReservationsPage
    const dialogo = await screen.findByRole('alertdialog');
    const btnConfirmar = within(dialogo).getByRole('button', { name: /Cancelar Reserva/i });
    fireEvent.click(btnConfirmar);

    // 4. Verificar que MyReservationsPage invocó updateDoc con el payload completo
    await waitFor(() => {
      expect(updateDocMock).toHaveBeenCalledTimes(1);
    });

    expect(updateDocMock).toHaveBeenCalledWith(
      { path: 'condominios/condo-piloto-01/espacios_comunes/esp-sum-01/reservas/res-int-01' },
      expect.objectContaining({
        estado: 'CANCELADO_USUARIO',
        usuarioCancelacion: 'usr-vecino-302',
        garantia_estado: 'cancelado',
        pago_estado_validacion: 'cancelado',
      })
    );
    expect(toastIntegrationMock).toHaveBeenCalledWith(
      expect.objectContaining({ title: 'Reserva cancelada con éxito' })
    );
  });
});
