import { describe, it, expect, vi, beforeEach } from 'vitest';

const {
  batchUpdateMock,
  batchCommitMock,
  collectionGroupGetMock,
  FIXED_TIMESTAMP_NOW,
  SERVER_TIMESTAMP_SENTINEL,
  dbAdminMock,
} = vi.hoisted(() => {
  const batchUpdateMock = vi.fn();
  const batchCommitMock = vi.fn().mockResolvedValue(undefined);
  const collectionGroupGetMock = vi.fn();
  const whereChainMock: any = {
    where: vi.fn(() => whereChainMock),
    get: collectionGroupGetMock,
  };

  const FIXED_TIMESTAMP_NOW = { seconds: 1791212400, nanoseconds: 0 };
  const SERVER_TIMESTAMP_SENTINEL = { _methodName: 'FieldValue.serverTimestamp' };

  const dbAdminMock = {
    collectionGroup: vi.fn(() => whereChainMock),
    batch: vi.fn(() => ({
      update: batchUpdateMock,
      commit: batchCommitMock,
    })),
    collection: vi.fn(),
  };

  return {
    batchUpdateMock,
    batchCommitMock,
    collectionGroupGetMock,
    FIXED_TIMESTAMP_NOW,
    SERVER_TIMESTAMP_SENTINEL,
    dbAdminMock,
  };
});

vi.mock('firebase-functions/v2/scheduler', () => ({
  onSchedule: (_schedule: string, handler: () => Promise<void>) => ({
    run: handler,
  }),
}));

vi.mock('firebase-admin', () => {
  const firestoreFn: any = () => dbAdminMock;
  firestoreFn.Timestamp = {
    now: () => FIXED_TIMESTAMP_NOW,
  };
  firestoreFn.FieldValue = {
    serverTimestamp: () => SERVER_TIMESTAMP_SENTINEL,
  };
  return {
    apps: [],
    initializeApp: vi.fn(),
    firestore: firestoreFn,
  };
});

import { autoliberarReservasExpiradas } from '../functions/src/index';

describe('Pruebas con Dobles y Mocks — R-05 autoliberarReservasExpiradas (Código Real)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('MK-01 [Caso Permitido R-05 / C14]: Libera reserva diferida vencida SIN comprobante invocando autoliberarReservasExpiradas real', async () => {
    const fakeRef = { id: 'res-vencida-01', path: 'condominios/c1/espacios_comunes/e1/reservas/res-vencida-01' };
    collectionGroupGetMock.mockResolvedValueOnce({
      empty: false,
      docs: [
        {
          id: 'res-vencida-01',
          ref: fakeRef,
          data: () => ({
            estado: 'SOLICITADO',
            pago_diferido: true,
            montoGarantia: 100,
            montoTotal: 250,
            pago_requerido: true,
            pagoNroOperacion: null,
            pagoConstanciaUrl: null,
          }),
        },
      ],
    });

    await (autoliberarReservasExpiradas as any).run();

    expect(dbAdminMock.collectionGroup).toHaveBeenCalledWith('reservas');
    expect(batchUpdateMock).toHaveBeenCalledTimes(1);
    expect(batchUpdateMock).toHaveBeenCalledWith(fakeRef, {
      estado: 'CANCELADO_ADMIN',
      notasAdmin: 'Cancelación automática: Plazo expirado.',
      fechaModificacion: SERVER_TIMESTAMP_SENTINEL,
      usuarioModificacion: 'system-auto-release',
      garantia_estado: 'cancelado',
      pago_estado_validacion: 'cancelado',
    });
    expect(batchCommitMock).toHaveBeenCalledTimes(1);
  });

  it('MK-02 [Caso Rechazado e Interacción Prohibida R-05 / C15]: NO libera ni invoca batch.update ni batch.commit si la reserva vencida ya tiene comprobante', async () => {
    const fakeRef = { id: 'res-con-voucher-02', path: 'condominios/c1/espacios_comunes/e1/reservas/res-con-voucher-02' };
    collectionGroupGetMock.mockResolvedValueOnce({
      empty: false,
      docs: [
        {
          id: 'res-con-voucher-02',
          ref: fakeRef,
          data: () => ({
            estado: 'SOLICITADO',
            pago_diferido: true,
            pagoNroOperacion: 'OP-449102',
            pagoConstanciaUrl: 'https://storage.comunidad360.pe/vouchers/op449102.jpg',
          }),
        },
      ],
    });

    await (autoliberarReservasExpiradas as any).run();

    expect(dbAdminMock.collectionGroup).toHaveBeenCalledWith('reservas');
    expect(batchUpdateMock).not.toHaveBeenCalled();
    expect(batchCommitMock).not.toHaveBeenCalled();
  });
});
