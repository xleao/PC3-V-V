import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { Timestamp } from 'firebase/firestore';
import type { ReservaEspacioComun } from '@/types';

const toastMock = vi.fn();

vi.mock('@/hooks/use-toast', () => ({
  useToast: () => ({ toast: toastMock }),
}));

vi.mock('@/hooks/use-language', () => ({
  useLanguage: () => ({
    language: 'es',
    t: (key: string) => {
      const dict: Record<string, string> = {
        cannotCancelReservationTitle: 'No se puede cancelar',
        cannotCancelReservationAdminProcessed: 'Esta reserva ya fue procesada por la administración.',
        cancelReservationButton: 'Cancelar Reserva',
        reservationDateTime: 'Fecha y hora',
        useTypeExclusive: 'Exclusivo',
        useTypeShared: 'Compartido',
        statusValidado: 'Validado',
      };
      return dict[key] || key;
    },
  }),
}));

import { MiReservaCard } from '@/components/condominios/espacios-comunes-usuario/mi-reserva-card';

const FIXED_NOW = new Date('2026-10-05T10:00:00.000-05:00');

function crearReserva(overrides: Partial<ReservaEspacioComun> = {}): ReservaEspacioComun {
  const inicio = new Date(FIXED_NOW.getTime() + 7 * 24 * 60 * 60 * 1000);
  const fin = new Date(inicio.getTime() + 4 * 60 * 60 * 1000);
  return {
    id: 'res-101',
    espacioComunId: 'esp-sum-01',
    espacioComunNombre: 'Salón de Usos Múltiples',
    usuarioId: 'usr-vecino-302',
    userDisplayName: 'Carlos Mendoza (Dpto. 302)',
    userEmail: 'cmendoza@comunidad360.pe',
    fechaHoraInicio: Timestamp.fromDate(inicio),
    fechaHoraFin: Timestamp.fromDate(fin),
    estado: 'SOLICITADO',
    esExclusivo: true,
    costoReserva: 150,
    montoAlquiler: 150,
    monedaCosto: 'S/',
    ...overrides,
  } as ReservaEspacioComun;
}

describe('Suite Inicial de Cobertura — MiReservaCard', () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(FIXED_NOW);
    toastMock.mockClear();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('UT-01: Permite cancelar reserva SOLICITADA con 7 días de anticipación', () => {
    const onCancel = vi.fn();
    render(<MiReservaCard reserva={crearReserva()} onCancel={onCancel} />);
    fireEvent.click(screen.getByRole('button', { name: /Cancelar Reserva/i }));
    expect(onCancel).toHaveBeenCalledTimes(1);
  });

  it('UT-02: Bloquea cancelación cuando falta 1 día (fuera de plazo)', () => {
    const onCancel = vi.fn();
    const inicio1d = new Date(FIXED_NOW.getTime() + 1 * 24 * 60 * 60 * 1000);
    render(
      <MiReservaCard
        reserva={crearReserva({
          dias_anticipacion_cancelacion: 2,
          fechaHoraInicio: Timestamp.fromDate(inicio1d),
        })}
        onCancel={onCancel}
      />
    );
    expect(screen.getByRole('button', { name: /Cancelar Reserva/i })).toBeDisabled();
  });

  it('UT-03: Bloquea cancelación cuando tiene comprobante registrado', () => {
    const onCancel = vi.fn();
    render(
      <MiReservaCard
        reserva={crearReserva({
          estado: 'CONFIRMADO',
          pagoNroOperacion: 'OP-772190',
          pago_estado_validacion: 'validado',
        })}
        onCancel={onCancel}
      />
    );
    expect(screen.getByRole('button', { name: /Cancelar Reserva/i })).toBeDisabled();
  });
});
