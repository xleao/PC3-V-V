/**
 * Utility to compress images on the client side using the HTML5 Canvas API.
 * Non-image files are bypassed automatically.
 */
export async function compressImage(
  file: File,
  maxWidth = 1920,
  maxHeight = 1080,
  quality = 0.8
): Promise<File> {
  // 1. Bypass if the file is not an image
  if (!file.type.startsWith('image/')) {
    return file;
  }

  return new Promise((resolve) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(file);

    img.onload = () => {
      // Clean up object URL as soon as the image is loaded into memory
      URL.revokeObjectURL(objectUrl);

      let width = img.width;
      let height = img.height;

      // 2. Calculate new dimensions keeping the aspect ratio
      if (width > height) {
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }
      }

      // 3. Draw image to canvas
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        // Fallback to original file if context creation fails
        resolve(file);
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);

      // 4. Export canvas to jpeg blob
      canvas.toBlob(
        (blob) => {
          if (blob) {
            // Construct a new File object with a .jpg extension
            const originalNameWithoutExt = file.name.substring(0, file.name.lastIndexOf('.')) || file.name;
            const newFileName = `${originalNameWithoutExt}.jpg`;
            
            const compressedFile = new File([blob], newFileName, {
              type: 'image/jpeg',
              lastModified: Date.now(),
            });
            resolve(compressedFile);
          } else {
            resolve(file);
          }
        },
        'image/jpeg',
        quality
      );
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      resolve(file); // Fallback on image loading error
    };

    img.src = objectUrl;
  });
}
