import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(amount: number | undefined | null, currencySymbol: string = 'S/') {
  if (amount === undefined || amount === null || isNaN(amount)) return `${currencySymbol} 0.00`;
  const formatted = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount);
  return `${currencySymbol} ${formatted}`;
}

/**
 * Removes any undefined fields from an object to prevent Firestore errors.
 */
export function cleanFirestorePayload<T extends Record<string, any>>(obj: T): T {
  const result: any = Array.isArray(obj) ? [] : {};
  Object.keys(obj).forEach(key => {
    const value = obj[key];
    if (value !== undefined) {
      if (value !== null && typeof value === 'object' && !(value instanceof Date) && typeof (value as any).toDate !== 'function') {
        if (value.constructor === Object || Array.isArray(value)) {
          result[key] = cleanFirestorePayload(value);
        } else {
          result[key] = value;
        }
      } else {
        result[key] = value;
      }
    }
  });
  return result;
}
