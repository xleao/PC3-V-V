import { initializeApp, getApps, getApp, deleteApp, type FirebaseOptions } from 'firebase/app';
import { 
  getAuth, 
  type User as FirebaseUserType,
  createUserWithEmailAndPassword as firebaseCreateUserWithEmailAndPassword,
  GoogleAuthProvider
} from 'firebase/auth'; 
import { getFirestore, doc, setDoc, getDoc, collection, getDocs, writeBatch, query, where, type DocumentData, updateDoc, serverTimestamp, FieldValue, deleteDoc } from 'firebase/firestore';
import { getStorage } from "firebase/storage";
import type { Role, Condominio as CondominioType, RolPlantilla, UserNotificationSettings } from '@/types';
import { errorEmitter, FirestorePermissionError } from '@/firebase';
import { firebaseConfig as staticConfig } from '@/firebase/config';

const firebaseConfig: FirebaseOptions = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || staticConfig.apiKey,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || staticConfig.authDomain,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || staticConfig.projectId,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || staticConfig.storageBucket,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || staticConfig.messagingSenderId,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || staticConfig.appId,
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID || staticConfig.measurementId,
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
storage.maxUploadRetryTime = 300000; // 5 minutos para subida de archivos
storage.maxOperationRetryTime = 300000; // 5 minutos para metadatos y descargas

// Providers
const googleProvider = new GoogleAuthProvider();

export { app, auth, db, storage, googleProvider };

export interface UserProfile extends DocumentData {
  uid: string;
  email: string | null;
  roles: string[];
  displayName?: string | null;
  photoURL?: string | null;
  createdAt?: FieldValue | Date; 
  fecha_modificacion?: FieldValue | Date; 
  isSystemAdmin?: boolean;
  assignedCondominios?: CondominioType[] | null; 
  telefono?: string;
  contactoEmergenciaNombre?: string;
  contactoEmergenciaRelacion?: string;
  contactoEmergenciaTelefono?: string;
  vehiculos?: Array<{ patente: string; marca: string; modelo: string; color: string }>;
  mascotas?: Array<{ nombre: string; especie: string; raza: string; fotoUrl?: string }>;
  preferenciasNotificaciones?: UserNotificationSettings;
  idiomaPreferido?: 'es' | 'en';
  temaPreferido?: 'claro' | 'oscuro' | 'sistema';
}

/**
 * Creates a new user in Firebase Authentication using a secondary instance.
 */
export const createAuthUser = async (email: string, passwordValue: string): Promise<FirebaseUserType> => {
  if (!email || !passwordValue) {
    throw new Error("Email and password are required to create an auth user.");
  }

  const normalizedEmail = email.toLowerCase().trim();
  const secondaryAppName = `admin-create-user-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const secondaryApp = initializeApp(firebaseConfig, secondaryAppName);
  const secondaryAuth = getAuth(secondaryApp);

  try {
    const userCredential = await firebaseCreateUserWithEmailAndPassword(secondaryAuth, normalizedEmail, passwordValue);
    const newUser = userCredential.user;
    await secondaryAuth.signOut();
    return newUser;
  } catch (error) {
    console.error("Error in createAuthUser (secondary instance):", error);
    throw error;
  } finally {
    await deleteApp(secondaryApp);
  }
};

/**
 * Creates or updates a user profile document in Firestore (Non-blocking).
 */
export const createUserProfileDocument = async (user: FirebaseUserType, additionalData: Partial<UserProfile> = {}): Promise<void> => {
  if (!user) return;

  const userRef = doc(db, `users/${user.uid}`);
  const snapshot = await getDoc(userRef);

  let rolesToSet = ['user'];
  if (additionalData.roles && Array.isArray(additionalData.roles) && additionalData.roles.length > 0) {
    rolesToSet = additionalData.roles;
  }
  
  const profileData: UserProfile = {
    uid: user.uid,
    email: (additionalData.email || user.email || '').toLowerCase().trim(),
    displayName: additionalData.displayName || user.displayName || user.email?.split('@')[0] || '',
    photoURL: user.photoURL || additionalData.photoURL || null, 
    roles: rolesToSet,
    isSystemAdmin: additionalData.isSystemAdmin === undefined ? false : additionalData.isSystemAdmin,
  };
  
  const { createdAt, fecha_modificacion, ...dataToSet } = profileData;

  if (!snapshot.exists()) {
    await setDoc(userRef, { 
      ...dataToSet, 
      createdAt: serverTimestamp(),
      fecha_modificacion: serverTimestamp() 
    }).catch(async (error) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: userRef.path,
        operation: 'create',
        requestResourceData: dataToSet
      }));
      throw error;
    });
  } else {
    const updatePayload: any = { ...dataToSet, fecha_modificacion: serverTimestamp() };
    await updateDoc(userRef, updatePayload).catch(async (error) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: userRef.path,
        operation: 'update',
        requestResourceData: updatePayload
      }));
      throw error;
    });
  }
};

/**
 * Retrieves a user profile document from Firestore.
 */
export const getUserProfileDocument = async (uid: string): Promise<UserProfile | null> => {
  if (!uid) return null;
  const userRef = doc(db, `users/${uid}`);
  const snapshot = await getDoc(userRef);
  return snapshot.exists() ? (snapshot.data() as UserProfile) : null;
};

/**
 * Checks if a user is a system administrator.
 */
export const checkIfSystemAdmin = async (userEmail: string): Promise<boolean> => {
  if (!userEmail) return false;
  const normalizedEmail = userEmail.toLowerCase().trim();
  try {
    const usersCollectionRef = collection(db, 'users');
    const q = query(usersCollectionRef, where('email', '==', normalizedEmail));
    const querySnapshot = await getDocs(q);
    return !querySnapshot.empty && querySnapshot.docs[0].data()?.isSystemAdmin === true;
  } catch (error) {
    return false;
  }
};

/**
 * Retrieves a list of condominios to which a user is assigned.
 */
export const getCondominiosForUser = async (userEmail: string): Promise<CondominioType[]> => {
  if (!userEmail) return [];
  const normalizedEmail = userEmail.toLowerCase().trim();
  const assignedCondominios: CondominioType[] = [];
  try {
    const condominiosColRef = collection(db, 'condominios');
    // Intentamos obtener los condominios. Si falla por permisos, es que el usuario no es Admin Pro.
    const condominiosSnapshot = await getDocs(condominiosColRef).catch(err => {
      if (err.code === 'permission-denied') return null;
      throw err;
    });

    if (!condominiosSnapshot) {
      // Si no podemos listar todos (normal para residentes), 
      // el sistema debería depender de la lista ya cargada en el perfil 
      // o una consulta más específica. Por ahora devolvemos vacío para evitar el crash.
      return [];
    }

    for (const condoDoc of condominiosSnapshot.docs) {
      const userInCondoRef = doc(db, 'condominios', condoDoc.id, 'usuarios', normalizedEmail);
      const userInCondoSnap = await getDoc(userInCondoRef);
      if (userInCondoSnap.exists()) {
        assignedCondominios.push({ id: condoDoc.id, ...condoDoc.data() } as CondominioType);
      }
    }
  } catch (error) {
    console.error("Error fetching condominios for user:", error);
  }
  return assignedCondominios;
};

export const getAllUserProfiles = async (): Promise<UserProfile[]> => {
  const usersCollectionRef = collection(db, 'users');
  const usersSnapshot = await getDocs(usersCollectionRef);
  return usersSnapshot.docs.map(docSnap => ({ ...docSnap.data(), uid: docSnap.id } as UserProfile));
};

export const setSystemAdminStatus = async (email: string, makeAdmin: boolean, userId?: string): Promise<void> => {
  let targetUserId = userId;
  const normalizedEmail = email.toLowerCase().trim();

  if (!targetUserId) {
    const usersCollectionRef = collection(db, 'users');
    const q = query(usersCollectionRef, where('email', '==', normalizedEmail));
    const querySnapshot = await getDocs(q);
    if (!querySnapshot.empty) {
      targetUserId = querySnapshot.docs[0].id;
    } else {
      throw new Error(`User with email ${normalizedEmail} not found.`);
    }
  }

  const userProfileRef = doc(db, 'users', targetUserId);
  const updateData = { isSystemAdmin: makeAdmin, fecha_modificacion: serverTimestamp() };
  updateDoc(userProfileRef, updateData).catch(async (error) => {
    errorEmitter.emit('permission-error', new FirestorePermissionError({
      path: userProfileRef.path,
      operation: 'update',
      requestResourceData: updateData
    }));
  });
};

export const updateUserGlobalRole = async (userId: string, newRoles: string[]): Promise<void> => {
  const userProfileRef = doc(db, 'users', userId);
  const updateData = { roles: newRoles, fecha_modificacion: serverTimestamp() };
  updateDoc(userProfileRef, updateData).catch(async (error) => {
    errorEmitter.emit('permission-error', new FirestorePermissionError({
      path: userProfileRef.path,
      operation: 'update',
      requestResourceData: updateData
    }));
  });
};

export const getAllGlobalRoles = async (): Promise<Role[]> => {
  const rolesCollectionRef = collection(db, 'roles_globales');
  const rolesSnapshot = await getDocs(rolesCollectionRef);
  return rolesSnapshot.docs.map(docSnap => ({ id: docSnap.id, ...docSnap.data() } as Role));
};

export const getAllRoleTemplates = async (): Promise<RolPlantilla[]> => {
  const templatesCollectionRef = collection(db, 'roles_plantilla');
  const templatesSnapshot = await getDocs(templatesCollectionRef);
  return templatesSnapshot.docs.map(docSnap => ({ id: docSnap.id, ...docSnap.data() } as RolPlantilla));
};

export const seedCondominioRolesFromTemplates = async (condominioId: string): Promise<void> => {
  const currentUser = auth.currentUser;
  const userUID = currentUser ? currentUser.uid : 'system_seed';

  const templatesQuery = query(collection(db, 'roles_plantilla'), where('es_rol_predeterminado', '==', true));
  const templatesSnapshot = await getDocs(templatesQuery);
  
  if (templatesSnapshot.empty) return;

  const batch = writeBatch(db);
  templatesSnapshot.forEach(templateDoc => {
    const templateData = templateDoc.data() as RolPlantilla;
    const newCondoRoleRef = doc(db, 'condominios', condominioId, 'roles', templateDoc.id);
    batch.set(newCondoRoleRef, {
      name: templateData.name,
      description: templateData.description,
      permissions: templateData.permissions || [],
      fecha_modificacion: serverTimestamp(),
      usuario_modificacion: userUID,
    });
  });

  await batch.commit();
};

export const deleteSystemUserProfile = async (uid: string): Promise<void> => {
  if (!uid) throw new Error("User ID is required.");
  const userDocRef = doc(db, 'users', uid);
  deleteDoc(userDocRef).catch(async (error) => {
    errorEmitter.emit('permission-error', new FirestorePermissionError({
      path: userDocRef.path,
      operation: 'delete',
    }));
  });
};
