"use client";

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams } from 'next/navigation';
import Image from 'next/image';
import { cn } from '@/lib/utils';
import { AppShell } from '@/components/layout/app-shell';
import { PageTitle } from '@/components/shared/page-title';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Icons } from '@/components/icons';
import { useLanguage } from '@/hooks/use-language';
import type { Condominio, ReservaEspacioComun } from '@/types';
import { db, storage, UserProfile } from '@/lib/firebase';
import { useAuth } from '@/contexts/auth-context';
import {
  doc,
  getDoc,
  collection,
  collectionGroup,
  query,
  where,
  orderBy,
  onSnapshot,
  updateDoc,
  serverTimestamp,
  Timestamp,
  writeBatch,
  increment,
  getDocs,
  limit,
} from 'firebase/firestore';
import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { useToast } from '@/hooks/use-toast';
import { notificationService } from '@/services/notification-service';
import { format, isPast, startOfMonth, endOfMonth, subDays, addDays, subMonths, startOfDay, endOfDay, parseISO } from 'date-fns';
import { es as esLocale, enUS as enLocale } from 'date-fns/locale';
import { useCondominioContext } from '@/contexts/condominio-context';
import { Input } from '@/components/ui/input';
import { usePermissions } from '@/hooks/use-permissions';
import { logAuditAction } from '@/services/audit-service';

interface ReservaParaValidacionView extends ReservaEspacioComun {
  userEmail?: string;
  userDisplayName?: string | null;
  paymentValidatorEmail?: string;
  requiere_aprobacion?: boolean;
  montoAlquiler?: number;
  montoGarantia?: number;
  garantia_estado?: 'pendiente' | 'devuelto' | 'no_aplica' | 'cancelado';
  garantia_devolucion_fecha?: any;
  garantia_devolucion_constancia_url?: string | null;
  garantia_devolucion_nro_operacion?: string | null;
  garantia_devolucion_cuenta_id?: string | null;
  garantia_devolucion_transaccion_id?: string | null;
  garantia_devolucion_notas?: string | null;
  garantia_devolucion_monto?: number;
  garantia_devolucion_original?: number;
  garantia_devolucion_diferencia?: number;
  garantia_devolucion_diferencia_motivo?: string | null;
  garantia_devolucion_diferencia_evidencia_url?: string | null;
}

function formatCurrency(amount: number | undefined | null, currencySymbol: string = 'S/') {
  if (amount === undefined || amount === null || isNaN(amount)) return `${currencySymbol} 0.00`;
  return `${currencySymbol} ${amount.toFixed(2)}`;
}


export default function CondoAdminValidateReservationsPage() {
  const { t, language } = useLanguage();
  const params = useParams();
  const { toast } = useToast();
  const { user: authUser } = useAuth();
  const { selectedCondominio: currentCondoFromContext } = useCondominioContext();
  const { hasPermission, isLoadingPermissions } = usePermissions();

  const canValidate = hasPermission('approve_or_reject_reservation');

  const condominioId = params.condominioId as string;

  const [condominio, setCondominio] = useState<Condominio | null>(null);
  const [allReservations, setAllReservations] = useState<ReservaParaValidacionView[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'solicitadas' | 'confirmadas' | 'rechazadas-canceladas' | 'garantias'>('solicitadas');
  const [garantiaSubTab, setGarantiaSubTab] = useState<'pendientes' | 'devueltas'>('pendientes');

  // Devolución de Garantía states
  const [isRefundDialogOpen, setIsRefundDialogOpen] = useState(false);
  const [reservationForRefund, setReservationForRefund] = useState<ReservaParaValidacionView | null>(null);
  const [refundOpNumber, setRefundOpNumber] = useState('');
  const [refundSourceAccountId, setRefundSourceAccountId] = useState('');
  const [refundConstanciaFile, setRefundConstanciaFile] = useState<File | null>(null);
  const [refundConstanciaPreview, setRefundConstanciaPreview] = useState<string | null>(null);
  const [isRefundUploading, setIsRefundUploading] = useState(false);
  const [refundUploadProgress, setRefundUploadProgress] = useState<number | null>(null);
  const [refundNotes, setRefundNotes] = useState('');
  const [cuentas, setCuentas] = useState<any[]>([]);

  // Custom refund amount states
  const [defineCustomRefund, setDefineCustomRefund] = useState(false);
  const [customRefundAmount, setCustomRefundAmount] = useState<string>('');
  const [refundPenaltyReason, setRefundPenaltyReason] = useState('');
  const [refundEvidenceFile, setRefundEvidenceFile] = useState<File | null>(null);
  const [refundEvidencePreview, setRefundEvidencePreview] = useState<string | null>(null);

  // New admin cancellation states
  const [reservationForCancel, setReservationForCancel] = useState<ReservaParaValidacionView | null>(null);
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false);
  const [isCancelRefundDialogOpen, setIsCancelRefundDialogOpen] = useState(false);
  const [cancelSourceAccountId, setCancelSourceAccountId] = useState('');
  const [cancelOpNumber, setCancelOpNumber] = useState('');
  const [cancelConstanciaFile, setCancelConstanciaFile] = useState<File | null>(null);
  const [cancelConstanciaPreview, setCancelConstanciaPreview] = useState<string | null>(null);
  const [isCancelUploading, setIsCancelUploading] = useState(false);
  const [cancelUploadProgress, setCancelUploadProgress] = useState<number | null>(null);
  const [cancelNotes, setCancelNotes] = useState('');

  // Custom cancellation refund amount states
  const [cancelDefineCustomRefund, setCancelDefineCustomRefund] = useState(false);
  const [cancelCustomRefundAmount, setCancelCustomRefundAmount] = useState<string>('');
  const [cancelPenaltyReason, setCancelPenaltyReason] = useState('');
  const [cancelEvidenceFile, setCancelEvidenceFile] = useState<File | null>(null);
  const [cancelEvidencePreview, setCancelEvidencePreview] = useState<string | null>(null);

  const handleCancelEvidenceFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setCancelEvidenceFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setCancelEvidencePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  // State hooks for pending validation payment cancellation
  const [isCancelPendingValidationDialogOpen, setIsCancelPendingValidationDialogOpen] = useState(false);
  const [cancelPendingWillRefund, setCancelPendingWillRefund] = useState<boolean | null>(null);

  // Date and account controls for cancellation/refund
  const [refundGuaranteeDate, setRefundGuaranteeDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [cancelRefundDate, setCancelRefundDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [cancelIngresoAccountId, setCancelIngresoAccountId] = useState('');
  const [cancelIngresoOpNumber, setCancelIngresoOpNumber] = useState('');
  const [cancelIngresoPaymentDate, setCancelIngresoPaymentDate] = useState(() => new Date().toISOString().split('T')[0]);

  useEffect(() => {
    if (!condominioId) return;
    const q = query(collection(db, 'condominios', condominioId, 'cuentas'), orderBy('nombre'));
    return onSnapshot(q, (snap) => {
      setCuentas(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
  }, [condominioId]);

  const [selectedReservationForAction, setSelectedReservationForAction] = useState<ReservaParaValidacionView | null>(null);
  const [isApproveConfirmOpen, setIsApproveConfirmOpen] = useState(false);
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');

  const [filterEspacioComunNombre, setFilterEspacioComunNombre] = useState('');
  const [filterUsuario, setFilterUsuario] = useState('');
  const [dateFilterType, setDateFilterType] = useState<string>('recent');
  const [customDateStart, setCustomDateStart] = useState<string>('');
  const [customDateEnd, setCustomDateEnd] = useState<string>('');
  const [appliedDateStart, setAppliedDateStart] = useState<string>('');
  const [appliedDateEnd, setAppliedDateEnd] = useState<string>('');

  const [selectedMobileReserva, setSelectedMobileReserva] = useState<ReservaParaValidacionView | null>(null);
  const [highlightFirstMobileReserva, setHighlightFirstMobileReserva] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setHighlightFirstMobileReserva(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  const [receiptModalOpen, setReceiptModalOpen] = useState(false);
  const [selectedReceiptUrl, setSelectedReceiptUrl] = useState<string | null>(null);

  const [detailReserva, setDetailReserva] = useState<ReservaParaValidacionView | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const espacioComunCache = React.useRef<Record<string, { requiere_aprobacion: boolean }>>({});

  const formatDateRange = (start: Timestamp, end: Timestamp) => {
    const locale = language === 'es' ? esLocale : enLocale;
    const startDate = start.toDate();
    const endDate = end.toDate();
    // Format: Jan 1, 2023, 10:00 AM - 12:00 PM
    return `${format(startDate, 'PP p', { locale })} - ${format(endDate, 'p', { locale })}`;
  };

  const formatDate = (timestamp: any) => {
    if (!timestamp) return '';
    try {
      const date = typeof timestamp.toDate === 'function' ? timestamp.toDate() : new Date(timestamp);
      const locale = language === 'es' ? esLocale : enLocale;
      return format(date, 'PP p', { locale });
    } catch (e) {
      console.error("Error formatting date:", e);
      return '';
    }
  };

  const fetchUserData = useCallback(async (uid: string | undefined): Promise<UserProfile | null> => {
    if (!uid) return null;
    try {
      const userRef = doc(db, 'users', uid);
      const userSnap = await getDoc(userRef);
      return userSnap.exists() ? (userSnap.data() as UserProfile) : null;
    } catch (e) {
      console.error("Error fetching user data for UID:", uid, e);
      return null;
    }
  }, []);


  const fetchData = useCallback(async () => {
    if (!condominioId) {
      setError(t('errorOccurred'));
      setIsLoadingData(false);
      return () => { }; // Return an empty function for cleanup
    }
    setIsLoadingData(true);
    setError(null);

    const condoRef = doc(db, 'condominios', condominioId);
    const unsubscribeCondo = onSnapshot(condoRef, (docSnap) => {
      if (docSnap.exists()) {
        setCondominio({ id: docSnap.id, ...docSnap.data() } as Condominio);
      } else {
        setError(t('condominioNotFound'));
        setCondominio(null);
        setIsLoadingData(false);
      }
    }, (err) => {
      console.error("Error fetching condo:", err);
      setError(t('errorOccurred'));
      setIsLoadingData(false);
    });

    let startLimit: Date;
    let endLimit: Date;
    const today = new Date();

    if (dateFilterType === 'recent') {
      startLimit = startOfDay(subDays(today, 7));
      endLimit = endOfDay(addDays(today, 30));
    } else if (dateFilterType === 'current_month') {
      startLimit = startOfMonth(today);
      endLimit = endOfMonth(today);
    } else if (dateFilterType === 'previous_month') {
      const prev = subMonths(today, 1);
      startLimit = startOfMonth(prev);
      endLimit = endOfMonth(prev);
    } else {
      // Custom
      startLimit = appliedDateStart ? startOfDay(parseISO(appliedDateStart)) : startOfDay(subDays(today, 30));
      endLimit = appliedDateEnd ? endOfDay(parseISO(appliedDateEnd)) : endOfDay(today);
    }

    const qReservas = query(
      collectionGroup(db, 'reservas'),
      where('condominioId', '==', condominioId),
      where('fechaHoraInicio', '>=', Timestamp.fromDate(startLimit)),
      where('fechaHoraInicio', '<=', Timestamp.fromDate(endLimit)),
      orderBy('fechaHoraInicio', 'asc')
    );

    const unsubscribeReservas = onSnapshot(qReservas, async (snapshot) => {
      const fetchedReservationsPromises = snapshot.docs.map(async (docSnap) => {
        const data = docSnap.data() as ReservaEspacioComun;
        const userProfile = await fetchUserData(data.usuarioId);
        let paymentValidatorProfile: UserProfile | null = null;
        if (data.pago_usuario_validacion) {
          paymentValidatorProfile = await fetchUserData(data.pago_usuario_validacion);
        }

        // Fetch common area requiere_aprobacion (cached per area)
        let requiere_aprobacion = true;
        if (data.espacioComunId) {
          if (espacioComunCache.current[data.espacioComunId] !== undefined) {
            requiere_aprobacion = espacioComunCache.current[data.espacioComunId].requiere_aprobacion;
          } else {
            try {
              const ecRef = doc(db, 'condominios', condominioId, 'espacios_comunes', data.espacioComunId);
              const ecSnap = await getDoc(ecRef);
              if (ecSnap.exists()) {
                requiere_aprobacion = ecSnap.data().requiere_aprobacion !== false;
              }
              espacioComunCache.current[data.espacioComunId] = { requiere_aprobacion };
            } catch {
              requiere_aprobacion = true;
            }
          }
        }

        return {
          ...data,
          id: docSnap.id,
          userEmail: userProfile?.email || data.usuarioId,
          userDisplayName: userProfile?.displayName || data.usuarioId,
          paymentValidatorEmail: paymentValidatorProfile?.email || data.pago_usuario_validacion,
          requiere_aprobacion,
        } as ReservaParaValidacionView;
      });
      const fetchedReservations = await Promise.all(fetchedReservationsPromises);
      setAllReservations(fetchedReservations);
      setIsLoadingData(false);
    }, (err) => {
      console.error("Error fetching reservations for validation: ", err);
      setError(t('errorOccurred'));
      toast({ title: t('errorOccurred'), description: "Failed to load reservations.", variant: "destructive" });
      setIsLoadingData(false);
    });

    return () => {
      unsubscribeCondo();
      unsubscribeReservas();
    };
  }, [condominioId, t, toast, fetchUserData, dateFilterType, appliedDateStart, appliedDateEnd]);

  useEffect(() => {
    let unsubscribePromise = fetchData();
    return () => {
      unsubscribePromise.then(cleanup => {
        if (typeof cleanup === 'function') {
          cleanup();
        }
      }).catch(err => console.error("Error during fetchData cleanup", err));
    };
  }, [fetchData]);

  const filteredReservations = useMemo(() => {
    return allReservations.filter(res => {
      const nombreMatch = filterEspacioComunNombre
        ? res.espacioComunNombre.toLowerCase().includes(filterEspacioComunNombre.toLowerCase())
        : true;
      const usuarioMatch = filterUsuario
        ? (res.userEmail?.toLowerCase().includes(filterUsuario.toLowerCase()) ||
          res.userDisplayName?.toLowerCase().includes(filterUsuario.toLowerCase()))
        : true;
      return nombreMatch && usuarioMatch;
    });
  }, [allReservations, filterEspacioComunNombre, filterUsuario]);


  const getReservationsByStatus = (status: 'solicitadas' | 'confirmadas' | 'rechazadas-canceladas' | 'garantias') => {
    switch (status) {
      case 'solicitadas':
        return filteredReservations.filter(r => r.estado === 'SOLICITADO');
      case 'confirmadas':
        return filteredReservations.filter(r => r.estado === 'CONFIRMADO');
      case 'rechazadas-canceladas':
        return filteredReservations.filter(r =>
          r.estado === 'RECHAZADO' || r.estado === 'CANCELADO_USUARIO' || r.estado === 'CANCELADO_ADMIN'
        ).sort((a, b) => {
          const getTime = (res: ReservaParaValidacionView) => {
            const ts = (res.fechaModificacion || res.fechaCreacion) as any;
            return ts?.toMillis?.() || 0;
          };
          return getTime(b) - getTime(a);
        });
      case 'garantias':
        return filteredReservations.filter(r =>
          r.estado === 'CONFIRMADO' &&
          (r.montoGarantia || 0) > 0 &&
          (garantiaSubTab === 'pendientes' ? r.garantia_estado === 'pendiente' : r.garantia_estado === 'devuelto')
        ).sort((a, b) => b.fechaHoraInicio.toMillis() - a.fechaHoraInicio.toMillis());
      default:
        return [];
    }
  };

  const handleOpenApproveDialog = (reserva: ReservaParaValidacionView) => {
    setSelectedReservationForAction(reserva);
    setIsApproveConfirmOpen(true);
  };

  const handleConfirmApproveReservation = async () => {
    if (!selectedReservationForAction || !authUser) {
      toast({ title: t('errorOccurred'), variant: 'destructive' });
      return;
    }
    const reservaRef = doc(db, 'condominios', condominioId, 'espacios_comunes', selectedReservationForAction.espacioComunId, 'reservas', selectedReservationForAction.id!);
    try {
      await updateDoc(reservaRef, {
        estado: 'CONFIRMADO',
        fechaModificacion: serverTimestamp(),
        usuarioModificacion: authUser.uid,
        notasAdmin: '',
      });

      // 🛡️ Log Audit Action
      await logAuditAction({
        condominioId,
        action: 'Aprobar Reserva',
        module: 'Espacios Comunes',
        type: 'validate',
        details: `Reserva aprobada para ${selectedReservationForAction.espacioComunNombre}. Usuario: ${selectedReservationForAction.userEmail || selectedReservationForAction.usuarioId}. Rango: ${formatDateRange(selectedReservationForAction.fechaHoraInicio, selectedReservationForAction.fechaHoraFin)}`,
        user: {
          uid: authUser.uid,
          email: authUser.email || '',
          displayName: authUser.displayName
        }
      });

      toast({ title: t('reservationApprovedSuccess') });

      // 🔔 Notificación al Residente: Reserva Aprobada
      await notificationService.sendNotification({
        userId: selectedReservationForAction.userEmail || selectedReservationForAction.usuarioId,
        title: "Reserva Aprobada",
        message: `¡Excelente! Tu reserva de ${selectedReservationForAction.espacioComunNombre} ha sido aprobada.`,
        type: 'reservation',
        condominioId,
        link: `/condominios/${condominioId}/espacios-comunes-usuario/mis-reservas`,
        metadata: { category: 'reservations' }
      });
    } catch (err: any) {
      console.error("Error approving reservation:", err);
      toast({ title: t('errorApprovingReservation'), description: err.message, variant: 'destructive' });
    } finally {
      setIsApproveConfirmOpen(false);
      setSelectedReservationForAction(null);
    }
  };

  const handleOpenRejectDialog = (reserva: ReservaParaValidacionView) => {
    setSelectedReservationForAction(reserva);
    setRejectionReason('');
    setIsRejectDialogOpen(true);
  };

  const handleConfirmRejectReservation = async () => {
    if (!selectedReservationForAction || !authUser || !rejectionReason.trim()) {
      toast({ title: t('rejectionReasonRequired'), variant: 'destructive' });
      return;
    }
    const reservaRef = doc(db, 'condominios', condominioId, 'espacios_comunes', selectedReservationForAction.espacioComunId, 'reservas', selectedReservationForAction.id!);
    try {
      await updateDoc(reservaRef, {
        estado: 'RECHAZADO',
        notasAdmin: rejectionReason.trim(),
        fechaModificacion: serverTimestamp(),
        usuarioModificacion: authUser.uid,
        pago_diferido: false,
        pago_estado_validacion: 'rechazado',
      });

      // 🛡️ Log Audit Action
      await logAuditAction({
        condominioId,
        action: 'Rechazar Reserva',
        module: 'Espacios Comunes',
        type: 'validate',
        details: `Reserva rechazada para ${selectedReservationForAction.espacioComunNombre}. Motivo: ${rejectionReason}. Usuario: ${selectedReservationForAction.userEmail || selectedReservationForAction.usuarioId}.`,
        user: {
          uid: authUser.uid,
          email: authUser.email || '',
          displayName: authUser.displayName
        }
      });

      toast({ title: t('reservationRejectedSuccess') });

      // 🔔 Notificación al Residente: Reserva Rechazada
      await notificationService.sendNotification({
        userId: selectedReservationForAction.userEmail || selectedReservationForAction.usuarioId,
        title: "Reserva Rechazada",
        message: `Tu solicitud de reserva para ${selectedReservationForAction.espacioComunNombre} no pudo ser aprobada. Motivo: ${rejectionReason}`,
        type: 'reservation',
        condominioId,
        link: `/condominios/${condominioId}/espacios-comunes-usuario/mis-reservas`,
        metadata: { category: 'reservations' }
      });
    } catch (err: any) {
      console.error("Error rejecting reservation:", err);
      toast({ title: t('errorRejectingReservation'), description: err.message, variant: 'destructive' });
    } finally {
      setIsRejectDialogOpen(false);
      setSelectedReservationForAction(null);
      setRejectionReason('');
    }
  };

  const handleOpenCancelReservaDialog = (reserva: ReservaParaValidacionView) => {
    setReservationForCancel(reserva);
    
    const hasVoucherPending = reserva.costoReserva && reserva.costoReserva > 0 && 
                              reserva.pago_estado_validacion === 'pendiente' && 
                              reserva.pagoConstanciaUrl;
                              
    const hasPaid = reserva.costoReserva && reserva.costoReserva > 0 && 
                    reserva.pago_estado_validacion === 'validado';
                    
    if (hasVoucherPending) {
      setCancelSourceAccountId('');
      setCancelOpNumber('');
      setCancelConstanciaFile(null);
      setCancelConstanciaPreview(null);
      setCancelNotes('');
      setCancelUploadProgress(null);
      setIsCancelUploading(false);
      
      // Initialize custom cancel refund states
      setCancelDefineCustomRefund(false);
      const rentalCost = reserva.montoAlquiler ?? ((reserva.costoReserva ?? 0) - (reserva.montoGarantia || 0));
      const isGarantiaDevuelta = reserva.garantia_estado === 'devuelto';
      const expectedAmount = isGarantiaDevuelta ? rentalCost : (reserva.costoReserva ?? 0);
      setCancelCustomRefundAmount(expectedAmount.toString());
      setCancelPenaltyReason('');
      setCancelEvidenceFile(null);
      setCancelEvidencePreview(null);
      
      setCancelPendingWillRefund(null);
      setCancelIngresoAccountId('');
      setCancelIngresoOpNumber(reserva.pagoNroOperacion || '');
      // Pre-fill from pago_fecha_efectiva if available, otherwise today
      const pagoFechaEfectiva = (reserva as any).pago_fecha_efectiva;
      const ingresoDate = pagoFechaEfectiva
        ? (typeof pagoFechaEfectiva.toDate === 'function'
            ? pagoFechaEfectiva.toDate()
            : new Date(pagoFechaEfectiva.seconds * 1000))
        : new Date();
      setCancelIngresoPaymentDate(ingresoDate.toISOString().split('T')[0]);
      setCancelRefundDate(new Date().toISOString().split('T')[0]);
      setIsCancelPendingValidationDialogOpen(true);
    } else if (hasPaid) {
      setCancelSourceAccountId('');
      setCancelOpNumber('');
      setCancelConstanciaFile(null);
      setCancelConstanciaPreview(null);
      setCancelNotes('');
      setCancelUploadProgress(null);
      setIsCancelUploading(false);
      
      // Initialize custom cancel refund states
      setCancelDefineCustomRefund(false);
      const rentalCost = reserva.montoAlquiler ?? ((reserva.costoReserva ?? 0) - (reserva.montoGarantia || 0));
      const isGarantiaDevuelta = reserva.garantia_estado === 'devuelto';
      const expectedAmount = isGarantiaDevuelta ? rentalCost : (reserva.costoReserva ?? 0);
      setCancelCustomRefundAmount(expectedAmount.toString());
      setCancelPenaltyReason('');
      setCancelEvidenceFile(null);
      setCancelEvidencePreview(null);

      setCancelRefundDate(new Date().toISOString().split('T')[0]);
      setIsCancelRefundDialogOpen(true);
    } else {
      setIsCancelDialogOpen(true);
    }
  };

  const handleCancelFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setCancelConstanciaFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setCancelConstanciaPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleConfirmCancelWithoutRefund = async () => {
    if (!reservationForCancel || !authUser) return;

    try {
      const reservaRef = doc(db, 'condominios', condominioId, 'espacios_comunes', reservationForCancel.espacioComunId, 'reservas', reservationForCancel.id!);
      await updateDoc(reservaRef, {
        estado: 'CANCELADO_ADMIN',
        fechaModificacion: serverTimestamp(),
        usuarioModificacion: authUser.uid,
        ...(reservationForCancel.montoGarantia && reservationForCancel.montoGarantia > 0 ? { garantia_estado: 'cancelado' } : {})
      });

      // Audit Log
      await logAuditAction({
        condominioId,
        action: 'Cancelación Reserva',
        module: 'Espacios Comunes',
        type: 'update',
        details: `Cancelación de reserva (sin reembolso) para ${reservationForCancel.espacioComunNombre}.`,
        user: { uid: authUser.uid, email: authUser.email || '', displayName: authUser.displayName || undefined }
      });

      // Notification
      await notificationService.sendNotification({
        userId: reservationForCancel.userEmail || reservationForCancel.usuarioId,
        title: "Reserva Cancelada",
        message: `Tu reserva de ${reservationForCancel.espacioComunNombre} para el ${formatDateRange(reservationForCancel.fechaHoraInicio, reservationForCancel.fechaHoraFin).split(' - ')[0]} ha sido cancelada por el administrador.`,
        type: 'reservation',
        condominioId,
        link: `/condominios/${condominioId}/espacios-comunes-usuario/mis-reservas`,
        metadata: { category: 'reservations' }
      });

      toast({ title: "Reserva cancelada exitosamente" });
      setIsCancelDialogOpen(false);
      setReservationForCancel(null);
      
      // Update detail popup if open
      if (detailReserva?.id === reservationForCancel.id) {
        setDetailReserva(prev => prev ? { 
          ...prev, 
          estado: 'CANCELADO_ADMIN',
          garantia_estado: (prev.montoGarantia && prev.montoGarantia > 0) ? 'cancelado' : prev.garantia_estado
        } : null);
      }
    } catch (err: any) {
      console.error("Error cancelling reservation:", err);
      toast({ title: "Error al cancelar reserva", description: err.message, variant: "destructive" });
    }
  };

  const handleConfirmCancelWithRefund = async () => {
    if (!reservationForCancel || !authUser || !cancelSourceAccountId || !cancelOpNumber.trim()) {
      toast({ title: "Información requerida faltante", variant: "destructive" });
      return;
    }

    const rentalCost = reservationForCancel.montoAlquiler ?? ((reservationForCancel.costoReserva ?? 0) - (reservationForCancel.montoGarantia || 0));
    const isGarantiaDevuelta = reservationForCancel.garantia_estado === 'devuelto';
    const expectedAmount = isGarantiaDevuelta ? rentalCost : (reservationForCancel.costoReserva ?? 0);
    const refundAmount = cancelDefineCustomRefund ? parseFloat(cancelCustomRefundAmount) : expectedAmount;

    if (isNaN(refundAmount) || refundAmount < 0) {
      toast({ title: "Monto inválido", description: "El monto a devolver debe ser un número mayor o igual a cero.", variant: "destructive" });
      return;
    }

    const maxRefundLimit = isGarantiaDevuelta ? rentalCost : (rentalCost + (reservationForCancel.montoGarantia || 0));
    if (refundAmount > maxRefundLimit) {
      toast({ title: "Monto excede límite", description: `El monto no puede ser mayor al límite máximo de ${formatCurrency(maxRefundLimit, reservationForCancel.monedaCosto ?? undefined)}.`, variant: "destructive" });
      return;
    }

    const isPartialRefund = refundAmount < expectedAmount;
    if (isPartialRefund) {
      if (!cancelPenaltyReason.trim()) {
        toast({ title: "Motivo requerido", description: "Debes indicar el motivo por el cual estás devolviendo un monto menor.", variant: "destructive" });
        return;
      }
      if (!cancelEvidenceFile) {
        toast({ title: "Evidencia requerida", description: "Debes adjuntar una imagen como evidencia del descuento.", variant: "destructive" });
        return;
      }
    }

    setIsCancelUploading(true);
    setCancelUploadProgress(0);

    let receiptUrl = "";
    if (cancelConstanciaFile) {
      const storagePath = `condominio_reservas_devoluciones_alquiler/${condominioId}/${reservationForCancel.espacioComunId}/${Date.now()}_${cancelConstanciaFile.name}`;
      const storageRef = ref(storage, storagePath);
      const uploadTask = uploadBytesResumable(storageRef, cancelConstanciaFile);

      try {
        await new Promise<void>((resolve, reject) => {
          uploadTask.on('state_changed',
            (snapshot) => setCancelUploadProgress((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
            (error) => {
              console.error("Refund upload failed:", error);
              toast({ title: "Error al subir constancia de reembolso", description: error.message, variant: "destructive" });
              reject(error);
            },
            async () => {
              receiptUrl = await getDownloadURL(uploadTask.snapshot.ref);
              resolve();
            }
          );
        });
      } catch (uploadError) {
        setIsCancelUploading(false);
        setCancelUploadProgress(null);
        return;
      }
    }

    let evidenceUrl = "";
    if (isPartialRefund && cancelEvidenceFile) {
      const storagePath = `condominio_reservas_cancelacion_evidencias/${condominioId}/${reservationForCancel.espacioComunId}/${Date.now()}_${cancelEvidenceFile.name}`;
      const storageRef = ref(storage, storagePath);
      const uploadTask = uploadBytesResumable(storageRef, cancelEvidenceFile);

      try {
        await new Promise<void>((resolve, reject) => {
          uploadTask.on('state_changed',
            (snapshot) => {
              // Evidence upload is secondary progress, we just wait for it.
            },
            (error) => {
              console.error("Evidence upload failed:", error);
              toast({ title: "Error al subir evidencia de multa/daño", description: error.message, variant: "destructive" });
              reject(error);
            },
            async () => {
              evidenceUrl = await getDownloadURL(uploadTask.snapshot.ref);
              resolve();
            }
          );
        });
      } catch (uploadError) {
        setIsCancelUploading(false);
        setCancelUploadProgress(null);
        return;
      }
    }

    const batch = writeBatch(db);
    try {
      const dateParts = cancelRefundDate.split('-');
      const refundDateObj = new Date(Number(dateParts[0]), Number(dateParts[1]) - 1, Number(dateParts[2]), 12, 0, 0);
      const periodId = `${dateParts[0]}-${dateParts[1]}`;
      
      // 1. Transaction in selected own bank account
      const transRefLocal = doc(collection(db, 'condominios', condominioId, 'cuentas', cancelSourceAccountId, 'transacciones'));
      const transactionData = {
        monto: refundAmount,
        tipo_operacion: 'egreso',
        categoria: 'Devolución Alquiler/Reserva',
        subcategoria: 'Cancelación Reserva por Admin',
        descripcion: isPartialRefund
          ? `Reembolso de alquiler de reserva Dpto: ${reservationForCancel.departamentoId || 'EC'} | Reserva: ${reservationForCancel.id}. Op Reembolso: ${cancelOpNumber}. Descuento por: ${cancelPenaltyReason}`
          : `Reembolso de alquiler de reserva Dpto: ${reservationForCancel.departamentoId || 'EC'} | Reserva: ${reservationForCancel.id}. Op Reembolso: ${cancelOpNumber}`,
        fecha_transaccion: Timestamp.fromDate(refundDateObj),
        fecha_creacion: serverTimestamp(),
        usuario_registro: authUser.uid,
        metodo_pago: 'transferencia',
        nro_operacion: cancelOpNumber,
        pago_id: reservationForCancel.id,
        voucher_url: receiptUrl || null,
        multa_motivo: isPartialRefund ? cancelPenaltyReason : null,
        multa_evidencia_url: isPartialRefund ? evidenceUrl : null,
        monto_original_reembolso: expectedAmount,
        monto_descuento_reembolso: expectedAmount - refundAmount,
        period_id: periodId
      };
      batch.set(transRefLocal, transactionData);

      // 2. Decrement bank account balance
      const accountRef = doc(db, 'condominios', condominioId, 'cuentas', cancelSourceAccountId);
      batch.update(accountRef, {
        saldo_actual: increment(-refundAmount),
        fecha_ultima_transaccion: Timestamp.fromDate(refundDateObj)
      });

      // 3. Update reservation document
      const reservaRef = doc(db, 'condominios', condominioId, 'espacios_comunes', reservationForCancel.espacioComunId, 'reservas', reservationForCancel.id!);
      batch.update(reservaRef, {
        estado: 'CANCELADO_ADMIN',
        pago_devolucion_monto: refundAmount,
        pago_devolucion_original: expectedAmount,
        pago_devolucion_diferencia: expectedAmount - refundAmount,
        pago_devolucion_fecha: Timestamp.fromDate(refundDateObj),
        pago_devolucion_constancia_url: receiptUrl || null,
        pago_devolucion_usuario: authUser.uid,
        pago_devolucion_nro_operacion: cancelOpNumber,
        pago_devolucion_cuenta_id: cancelSourceAccountId,
        pago_devolucion_transaccion_id: transRefLocal.id,
        pago_devolucion_notas: cancelNotes.trim() || null,
        pago_devolucion_descuento_motivo: isPartialRefund ? cancelPenaltyReason : null,
        pago_devolucion_descuento_evidencia_url: isPartialRefund ? evidenceUrl : null,
        fechaModificacion: serverTimestamp(),
        usuarioModificacion: authUser.uid,
        ...(reservationForCancel.montoGarantia && reservationForCancel.montoGarantia > 0 ? { garantia_estado: 'cancelado' } : {})
      });

      await batch.commit();

      // 4. Audit Log
      await logAuditAction({
        condominioId,
        action: 'Cancelación Reserva con Reembolso',
        module: 'Espacios Comunes',
        type: 'update',
        details: isPartialRefund
          ? `Cancelación y reembolso de reserva para ${reservationForCancel.espacioComunNombre}. Monto devuelto: ${formatCurrency(refundAmount, reservationForCancel.monedaCosto ?? undefined)} (Esperado: ${formatCurrency(expectedAmount, reservationForCancel.monedaCosto ?? undefined)}). Descuento: ${formatCurrency(expectedAmount - refundAmount, reservationForCancel.monedaCosto ?? undefined)}. Motivo: ${cancelPenaltyReason}. Op: ${cancelOpNumber}. Cuenta: ${cancelSourceAccountId}`
          : `Cancelación y reembolso de reserva para ${reservationForCancel.espacioComunNombre}. Monto devuelto: ${formatCurrency(refundAmount, reservationForCancel.monedaCosto ?? undefined)}. Op: ${cancelOpNumber}. Cuenta debitada: ${cancelSourceAccountId}`,
        user: { uid: authUser.uid, email: authUser.email || '', displayName: authUser.displayName || undefined }
      });

      // 5. Send notification to resident
      const notificationMessage = isPartialRefund
        ? `Se ha realizado la cancelación de tu reserva de ${reservationForCancel.espacioComunNombre} con un reembolso parcial de S/ ${refundAmount.toFixed(2)} (Monto esperado: S/ ${expectedAmount.toFixed(2)}). Se descontó por: ${cancelPenaltyReason}. Op de Reembolso: ${cancelOpNumber}`
        : `Se ha cancelado tu reserva de ${reservationForCancel.espacioComunNombre} y reembolsado S/ ${refundAmount.toFixed(2)}. Op de Reembolso: ${cancelOpNumber}`;

      await notificationService.sendNotification({
        userId: reservationForCancel.userEmail || reservationForCancel.usuarioId,
        title: isPartialRefund ? "Reserva Cancelada y Reembolsada Parcialmente" : "Reserva Cancelada y Reembolsada",
        message: notificationMessage,
        type: isPartialRefund ? 'warning' : 'info',
        condominioId,
        link: `/condominios/${condominioId}/espacios-comunes-usuario/mis-reservas`,
      });

      toast({ title: isPartialRefund ? "Reserva cancelada con reembolso parcial" : "Reserva cancelada y reembolsada exitosamente" });
      setIsCancelRefundDialogOpen(false);
      setReservationForCancel(null);

      // Update detail popup if open
      if (detailReserva?.id === reservationForCancel.id) {
        setDetailReserva(prev => prev ? { 
          ...prev, 
          estado: 'CANCELADO_ADMIN',
          pago_devolucion_monto: refundAmount,
          pago_devolucion_original: expectedAmount,
          pago_devolucion_diferencia: expectedAmount - refundAmount,
          pago_devolucion_cuenta_id: cancelSourceAccountId,
          pago_devolucion_nro_operacion: cancelOpNumber,
          pago_devolucion_constancia_url: receiptUrl || null,
          pago_devolucion_descuento_motivo: isPartialRefund ? cancelPenaltyReason : null,
          pago_devolucion_descuento_evidencia_url: isPartialRefund ? evidenceUrl : null,
          garantia_estado: (prev.montoGarantia && prev.montoGarantia > 0) ? 'cancelado' : prev.garantia_estado
        } : null);
      }
    } catch (err: any) {
      console.error("Error cancelling reservation with refund:", err);
      toast({ title: "Error al cancelar y reembolsar", description: err.message, variant: "destructive" });
    } finally {
      setIsCancelUploading(false);
      setCancelUploadProgress(null);
    }
  };

  const handleConfirmCancelPendingRefund = async () => {
    if (
      !reservationForCancel || 
      !authUser || 
      !cancelIngresoAccountId || 
      !cancelIngresoOpNumber.trim() || 
      !cancelIngresoPaymentDate ||
      !cancelSourceAccountId || 
      !cancelRefundDate || 
      !cancelOpNumber.trim()
    ) {
      toast({ title: "Información requerida faltante", description: "Por favor, completa todas las cuentas, fechas y números de operación.", variant: "destructive" });
      return;
    }

    const rentalCost = reservationForCancel.montoAlquiler ?? ((reservationForCancel.costoReserva ?? 0) - (reservationForCancel.montoGarantia || 0));
    const isGarantiaDevuelta = reservationForCancel.garantia_estado === 'devuelto';
    const expectedAmount = isGarantiaDevuelta ? rentalCost : (reservationForCancel.costoReserva ?? 0);
    const refundAmount = cancelDefineCustomRefund ? parseFloat(cancelCustomRefundAmount) : expectedAmount;

    if (isNaN(refundAmount) || refundAmount < 0) {
      toast({ title: "Monto inválido", description: "El monto a devolver debe ser un número mayor o igual a cero.", variant: "destructive" });
      return;
    }

    const maxRefundLimit = isGarantiaDevuelta ? rentalCost : (rentalCost + (reservationForCancel.montoGarantia || 0));
    if (refundAmount > maxRefundLimit) {
      toast({ title: "Monto excede límite", description: `El monto no puede ser mayor al límite máximo de ${formatCurrency(maxRefundLimit, reservationForCancel.monedaCosto ?? undefined)}.`, variant: "destructive" });
      return;
    }

    const isPartialRefund = refundAmount < expectedAmount;
    if (isPartialRefund) {
      if (!cancelPenaltyReason.trim()) {
        toast({ title: "Motivo requerido", description: "Debes indicar el motivo por el cual estás devolviendo un monto menor.", variant: "destructive" });
        return;
      }
      if (!cancelEvidenceFile) {
        toast({ title: "Evidencia requerida", description: "Debes adjuntar una imagen como evidencia del descuento.", variant: "destructive" });
        return;
      }
    }

    setIsCancelUploading(true);
    setCancelUploadProgress(0);

    let receiptUrl = "";
    if (cancelConstanciaFile) {
      const storagePath = `condominio_reservas_devoluciones_alquiler/${condominioId}/${reservationForCancel.espacioComunId}/${Date.now()}_${cancelConstanciaFile.name}`;
      const storageRef = ref(storage, storagePath);
      const uploadTask = uploadBytesResumable(storageRef, cancelConstanciaFile);

      try {
        await new Promise<void>((resolve, reject) => {
          uploadTask.on('state_changed',
            (snapshot) => setCancelUploadProgress((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
            (error) => {
              console.error("Refund upload failed:", error);
              toast({ title: "Error al subir constancia de reembolso", description: error.message, variant: "destructive" });
              reject(error);
            },
            async () => {
              receiptUrl = await getDownloadURL(uploadTask.snapshot.ref);
              resolve();
            }
          );
        });
      } catch (uploadError) {
        setIsCancelUploading(false);
        setCancelUploadProgress(null);
        return;
      }
    }

    let evidenceUrl = "";
    if (isPartialRefund && cancelEvidenceFile) {
      const storagePath = `condominio_reservas_cancelacion_evidencias/${condominioId}/${reservationForCancel.espacioComunId}/${Date.now()}_${cancelEvidenceFile.name}`;
      const storageRef = ref(storage, storagePath);
      const uploadTask = uploadBytesResumable(storageRef, cancelEvidenceFile);

      try {
        await new Promise<void>((resolve, reject) => {
          uploadTask.on('state_changed',
            (snapshot) => {},
            (error) => {
              console.error("Evidence upload failed:", error);
              toast({ title: "Error al subir evidencia de multa/daño", description: error.message, variant: "destructive" });
              reject(error);
            },
            async () => {
              evidenceUrl = await getDownloadURL(uploadTask.snapshot.ref);
              resolve();
            }
          );
        });
      } catch (uploadError) {
        setIsCancelUploading(false);
        setCancelUploadProgress(null);
        return;
      }
    }

    const batch = writeBatch(db);
    try {
      // Parse Ingreso Date
      const ingresoDateParts = cancelIngresoPaymentDate.split('-');
      const ingresoDateObj = new Date(Number(ingresoDateParts[0]), Number(ingresoDateParts[1]) - 1, Number(ingresoDateParts[2]), 12, 0, 0);
      const ingresoPeriodId = `${ingresoDateParts[0]}-${ingresoDateParts[1]}`;

      // Parse Egreso Date
      const refundDateParts = cancelRefundDate.split('-');
      const refundDateObj = new Date(Number(refundDateParts[0]), Number(refundDateParts[1]) - 1, Number(refundDateParts[2]), 12, 0, 0);
      const refundPeriodId = `${refundDateParts[0]}-${refundDateParts[1]}`;

      // 1. Transaction 1: Ingreso (original payment entry)
      const transRefLocalIngreso = doc(collection(db, 'condominios', condominioId, 'cuentas', cancelIngresoAccountId, 'transacciones'));
      const originalPaymentAmount = reservationForCancel.costoReserva || 0;
      const ingresoDescription = `Validación automática al cancelar Dpto: ${reservationForCancel.departamentoId || 'EC'} | Reserva: ${reservationForCancel.id}. Op Pago: ${cancelIngresoOpNumber}`;
      
      const ingresoData = {
        monto: originalPaymentAmount,
        tipo_operacion: 'ingreso',
        categoria: 'Alquiler Espacio Común',
        subcategoria: 'Validación de Pago',
        descripcion: ingresoDescription,
        fecha_transaccion: Timestamp.fromDate(ingresoDateObj),
        fecha_creacion: serverTimestamp(),
        usuario_registro: authUser.uid,
        metodo_pago: 'transferencia',
        nro_operacion: cancelIngresoOpNumber,
        pago_id: reservationForCancel.id,
        voucher_url: reservationForCancel.pagoConstanciaUrl || null,
        period_id: ingresoPeriodId
      };
      batch.set(transRefLocalIngreso, ingresoData);

      // 2. Transaction 2: Egreso (refund)
      const transRefLocalEgreso = doc(collection(db, 'condominios', condominioId, 'cuentas', cancelSourceAccountId, 'transacciones'));
      const egresoData = {
        monto: refundAmount,
        tipo_operacion: 'egreso',
        categoria: 'Devolución Alquiler/Reserva',
        subcategoria: 'Cancelación Reserva por Admin',
        descripcion: isPartialRefund
          ? `Reembolso de alquiler de reserva Dpto: ${reservationForCancel.departamentoId || 'EC'} | Reserva: ${reservationForCancel.id}. Op Reembolso: ${cancelOpNumber}. Descuento por: ${cancelPenaltyReason}`
          : `Reembolso de alquiler de reserva Dpto: ${reservationForCancel.departamentoId || 'EC'} | Reserva: ${reservationForCancel.id}. Op Reembolso: ${cancelOpNumber}`,
        fecha_transaccion: Timestamp.fromDate(refundDateObj),
        fecha_creacion: serverTimestamp(),
        usuario_registro: authUser.uid,
        metodo_pago: 'transferencia',
        nro_operacion: cancelOpNumber,
        pago_id: reservationForCancel.id,
        voucher_url: receiptUrl || null,
        multa_motivo: isPartialRefund ? cancelPenaltyReason : null,
        multa_evidencia_url: isPartialRefund ? evidenceUrl : null,
        monto_original_reembolso: expectedAmount,
        monto_descuento_reembolso: expectedAmount - refundAmount,
        period_id: refundPeriodId
      };
      batch.set(transRefLocalEgreso, egresoData);

      // 3. Update Bank balances
      const ingresoAccountRef = doc(db, 'condominios', condominioId, 'cuentas', cancelIngresoAccountId);
      const sourceAccountRef = doc(db, 'condominios', condominioId, 'cuentas', cancelSourceAccountId);

      if (cancelIngresoAccountId === cancelSourceAccountId) {
        batch.update(ingresoAccountRef, {
          saldo_actual: increment(originalPaymentAmount - refundAmount),
          fecha_ultima_transaccion: Timestamp.fromDate(refundDateObj)
        });
      } else {
        batch.update(ingresoAccountRef, {
          saldo_actual: increment(originalPaymentAmount),
          fecha_ultima_transaccion: Timestamp.fromDate(ingresoDateObj)
        });
        batch.update(sourceAccountRef, {
          saldo_actual: increment(-refundAmount),
          fecha_ultima_transaccion: Timestamp.fromDate(refundDateObj)
        });
      }

      // 4. Update reservation document
      const reservaRef = doc(db, 'condominios', condominioId, 'espacios_comunes', reservationForCancel.espacioComunId, 'reservas', reservationForCancel.id!);
      batch.update(reservaRef, {
        estado: 'CANCELADO_ADMIN',
        pago_estado_validacion: 'validado',
        pago_devolucion_monto: refundAmount,
        pago_devolucion_original: expectedAmount,
        pago_devolucion_diferencia: expectedAmount - refundAmount,
        pago_devolucion_fecha: Timestamp.fromDate(refundDateObj),
        pago_devolucion_constancia_url: receiptUrl || null,
        pago_devolucion_usuario: authUser.uid,
        pago_devolucion_nro_operacion: cancelOpNumber,
        pago_devolucion_cuenta_id: cancelSourceAccountId,
        pago_devolucion_transaccion_id: transRefLocalEgreso.id,
        pago_devolucion_notas: cancelNotes.trim() || null,
        pago_devolucion_descuento_motivo: isPartialRefund ? cancelPenaltyReason : null,
        pago_devolucion_descuento_evidencia_url: isPartialRefund ? evidenceUrl : null,
        
        // Vínculo contable del ingreso de reserva
        transaccion_id: transRefLocalIngreso.id,
        cuenta_id: cancelIngresoAccountId,
        periodo_ingreso_balance: ingresoPeriodId,
        pago_fecha_efectiva: Timestamp.fromDate(ingresoDateObj),
        pagoNroOperacion: cancelIngresoOpNumber,

        fechaModificacion: serverTimestamp(),
        usuarioModificacion: authUser.uid,
        ...(reservationForCancel.montoGarantia && reservationForCancel.montoGarantia > 0 ? { garantia_estado: 'cancelado' } : {})
      });

      await batch.commit();

      // 5. Audit Log
      await logAuditAction({
        condominioId,
        action: 'Cancelación Reserva con Reembolso',
        module: 'Espacios Comunes',
        type: 'update',
        details: `Cancelación de reserva (pago originalmente pendiente) para ${reservationForCancel.espacioComunNombre}. Pago de entrada de ${formatCurrency(originalPaymentAmount, reservationForCancel.monedaCosto ?? undefined)} registrado. Reembolso realizado: ${formatCurrency(refundAmount, reservationForCancel.monedaCosto ?? undefined)} (Esperado: ${formatCurrency(expectedAmount, reservationForCancel.monedaCosto ?? undefined)}). Op Pago: ${reservationForCancel.pagoNroOperacion || 'N/A'}. Op Reembolso: ${cancelOpNumber}. Cuenta: ${cancelSourceAccountId}`,
        user: { uid: authUser.uid, email: authUser.email || '', displayName: authUser.displayName || undefined }
      });

      // 6. Send notification to resident
      const notificationMessage = isPartialRefund
        ? `Se ha realizado la cancelación de tu reserva de ${reservationForCancel.espacioComunNombre} con un reembolso parcial de S/ ${refundAmount.toFixed(2)} (Monto esperado: S/ ${expectedAmount.toFixed(2)}). Se descontó por: ${cancelPenaltyReason}. Op de Reembolso: ${cancelOpNumber}`
        : `Se ha cancelado tu reserva de ${reservationForCancel.espacioComunNombre} y reembolsado S/ ${refundAmount.toFixed(2)}. Op de Reembolso: ${cancelOpNumber}`;

      await notificationService.sendNotification({
        userId: reservationForCancel.userEmail || reservationForCancel.usuarioId,
        title: isPartialRefund ? "Reserva Cancelada y Reembolsada Parcialmente" : "Reserva Cancelada y Reembolsada",
        message: notificationMessage,
        type: isPartialRefund ? 'warning' : 'info',
        condominioId,
        link: `/condominios/${condominioId}/espacios-comunes-usuario/mis-reservas`,
      });

      toast({ title: isPartialRefund ? "Reserva cancelada con reembolso parcial" : "Reserva cancelada y reembolsada exitosamente" });
      setIsCancelPendingValidationDialogOpen(false);
      setReservationForCancel(null);

      // Update detail popup if open
      if (detailReserva?.id === reservationForCancel.id) {
        setDetailReserva(prev => prev ? { 
          ...prev, 
          estado: 'CANCELADO_ADMIN',
          pago_estado_validacion: 'validado',
          pago_devolucion_monto: refundAmount,
          pago_devolucion_original: expectedAmount,
          pago_devolucion_diferencia: expectedAmount - refundAmount,
          pago_devolucion_cuenta_id: cancelSourceAccountId,
          pago_devolucion_nro_operacion: cancelOpNumber,
          pago_devolucion_constancia_url: receiptUrl || null,
          pago_devolucion_descuento_motivo: isPartialRefund ? cancelPenaltyReason : null,
          pago_devolucion_descuento_evidencia_url: isPartialRefund ? evidenceUrl : null,
          
          // Vínculo contable del ingreso en estado local
          transaccion_id: transRefLocalIngreso.id,
          cuenta_id: cancelIngresoAccountId,
          periodo_ingreso_balance: ingresoPeriodId,
          pago_fecha_efectiva: Timestamp.fromDate(ingresoDateObj),
          pagoNroOperacion: cancelIngresoOpNumber,

          garantia_estado: (prev.montoGarantia && prev.montoGarantia > 0) ? 'cancelado' : prev.garantia_estado
        } : null);
      }
    } catch (err: any) {
      console.error("Error cancelling pending reservation with refund:", err);
      toast({ title: "Error al cancelar y reembolsar", description: err.message, variant: "destructive" });
    } finally {
      setIsCancelUploading(false);
      setCancelUploadProgress(null);
    }
  };

  const handleConfirmCancelPendingReject = async () => {
    if (!reservationForCancel || !authUser) return;

    setIsCancelUploading(true);
    try {
      const reservaRef = doc(db, 'condominios', condominioId, 'espacios_comunes', reservationForCancel.espacioComunId, 'reservas', reservationForCancel.id!);
      await updateDoc(reservaRef, {
        estado: 'CANCELADO_ADMIN',
        pago_estado_validacion: 'rechazado',
        fechaModificacion: serverTimestamp(),
        usuarioModificacion: authUser.uid,
        ...(reservationForCancel.montoGarantia && reservationForCancel.montoGarantia > 0 ? { garantia_estado: 'cancelado' } : {})
      });

      // Audit Log
      await logAuditAction({
        condominioId,
        action: 'Cancelación Reserva y Rechazo Pago',
        module: 'Espacios Comunes',
        type: 'update',
        details: `Cancelación de reserva y rechazo de comprobante de pago para ${reservationForCancel.espacioComunNombre} sin realizar reembolso.`,
        user: { uid: authUser.uid, email: authUser.email || '', displayName: authUser.displayName || undefined }
      });

      // Send notification to resident
      await notificationService.sendNotification({
        userId: reservationForCancel.userEmail || reservationForCancel.usuarioId,
        title: "Reserva Cancelada y Pago Rechazado",
        message: `Tu solicitud de reserva para ${reservationForCancel.espacioComunNombre} ha sido cancelada y el comprobante de pago ha sido rechazado por el administrador. No se realizará ningún reembolso.`,
        type: 'error',
        condominioId,
        link: `/condominios/${condominioId}/espacios-comunes-usuario/mis-reservas`,
      });

      toast({ title: "Reserva cancelada y pago rechazado exitosamente" });
      setIsCancelPendingValidationDialogOpen(false);
      setReservationForCancel(null);

      // Update detail popup if open
      if (detailReserva?.id === reservationForCancel.id) {
        setDetailReserva(prev => prev ? { 
          ...prev, 
          estado: 'CANCELADO_ADMIN',
          pago_estado_validacion: 'rechazado',
          garantia_estado: (prev.montoGarantia && prev.montoGarantia > 0) ? 'cancelado' : prev.garantia_estado
        } : null);
      }
    } catch (err: any) {
      console.error("Error cancelling reservation and rejecting payment:", err);
      toast({ title: "Error al cancelar reserva", description: err.message, variant: "destructive" });
    } finally {
      setIsCancelUploading(false);
    }
  };

  const handleOpenRefundDialog = (reserva: ReservaParaValidacionView) => {
    setReservationForRefund(reserva);
    setRefundOpNumber('');
    setRefundSourceAccountId('');
    setRefundConstanciaFile(null);
    setRefundConstanciaPreview(null);
    setRefundNotes('');
    setRefundUploadProgress(null);
    setIsRefundUploading(false);
    
    // Reset custom refund states
    setDefineCustomRefund(false);
    setCustomRefundAmount((reserva.montoGarantia || 0).toString());
    setRefundPenaltyReason('');
    setRefundEvidenceFile(null);
    setRefundEvidencePreview(null);
    setRefundGuaranteeDate(new Date().toISOString().split('T')[0]);
    
    setIsRefundDialogOpen(true);
  };

  const handleRefundFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setRefundConstanciaFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setRefundConstanciaPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleEvidenceFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setRefundEvidenceFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setRefundEvidencePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleConfirmRefund = async () => {
    if (!reservationForRefund || !authUser || !refundSourceAccountId || !refundOpNumber.trim()) {
      toast({ title: "Información requerida faltante", variant: "destructive" });
      return;
    }

    const originalGarantia = reservationForRefund.montoGarantia || 0;
    const amount = defineCustomRefund ? parseFloat(customRefundAmount) : originalGarantia;

    if (isNaN(amount) || amount < 0) {
      toast({ title: "Monto inválido", description: "El monto a devolver debe ser un número mayor o igual a cero.", variant: "destructive" });
      return;
    }

    if (amount > originalGarantia) {
      toast({ title: "Monto excede garantía", description: `El monto no puede ser mayor al de la garantía original (${formatCurrency(originalGarantia, reservationForRefund.monedaCosto ?? undefined)}).`, variant: "destructive" });
      return;
    }

    const isPartialRefund = amount < originalGarantia;
    if (isPartialRefund) {
      if (!refundPenaltyReason.trim()) {
        toast({ title: "Motivo requerido", description: "Debes indicar el motivo por el cual estás devolviendo un monto menor (multas o daños).", variant: "destructive" });
        return;
      }
      if (!refundEvidenceFile) {
        toast({ title: "Evidencia requerida", description: "Debes adjuntar una imagen como evidencia de la falta o daño.", variant: "destructive" });
        return;
      }
    }

    setIsRefundUploading(true);
    setRefundUploadProgress(0);

    let receiptUrl = "";
    if (refundConstanciaFile) {
      const storagePath = `condominio_reservas_devoluciones/${condominioId}/${reservationForRefund.espacioComunId}/${Date.now()}_${refundConstanciaFile.name}`;
      const storageRef = ref(storage, storagePath);
      const uploadTask = uploadBytesResumable(storageRef, refundConstanciaFile);

      try {
        await new Promise<void>((resolve, reject) => {
          uploadTask.on('state_changed',
            (snapshot) => setRefundUploadProgress((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
            (error) => {
              console.error("Refund upload failed:", error);
              toast({ title: t('errorUploadingReceipt') || "Error al subir constancia", description: error.message, variant: "destructive" });
              reject(error);
            },
            async () => {
              receiptUrl = await getDownloadURL(uploadTask.snapshot.ref);
              resolve();
            }
          );
        });
      } catch (uploadError) {
        setIsRefundUploading(false);
        setRefundUploadProgress(null);
        return;
      }
    }

    let evidenceUrl = "";
    if (isPartialRefund && refundEvidenceFile) {
      const storagePath = `condominio_reservas_evidencias_multas/${condominioId}/${reservationForRefund.espacioComunId}/${Date.now()}_${refundEvidenceFile.name}`;
      const storageRef = ref(storage, storagePath);
      const uploadTask = uploadBytesResumable(storageRef, refundEvidenceFile);

      try {
        await new Promise<void>((resolve, reject) => {
          uploadTask.on('state_changed',
            (snapshot) => {
              // Evidence upload is secondary progress, we just wait for it.
            },
            (error) => {
              console.error("Evidence upload failed:", error);
              toast({ title: "Error al subir evidencia de multa", description: error.message, variant: "destructive" });
              reject(error);
            },
            async () => {
              evidenceUrl = await getDownloadURL(uploadTask.snapshot.ref);
              resolve();
            }
          );
        });
      } catch (uploadError) {
        setIsRefundUploading(false);
        setRefundUploadProgress(null);
        return;
      }
    }

    // 0. Fetch the active period of the condominio
    let activePeriodId: string | null = null;
    try {
      const balancesRef = collection(db, 'condominios', condominioId, 'balances');
      const qOpen = query(balancesRef, where('esta_cerrado', '==', false), limit(1));
      const openSnap = await getDocs(qOpen);
      if (!openSnap.empty) {
        activePeriodId = openSnap.docs[0].id;
      }
    } catch (err) {
      console.error("Error fetching active period:", err);
    }

    const batch = writeBatch(db);
    try {
      const dateParts = refundGuaranteeDate.split('-');
      const guaranteeDateObj = new Date(Number(dateParts[0]), Number(dateParts[1]) - 1, Number(dateParts[2]), 12, 0, 0);
      const periodId = `${dateParts[0]}-${dateParts[1]}`;

      // 1. Local transaction inside selected bank account
      const transRefLocal = doc(collection(db, 'condominios', condominioId, 'cuentas', refundSourceAccountId, 'transacciones'));
      const transactionData = {
        monto: amount,
        tipo_operacion: 'egreso',
        categoria: 'Devolución Garantía',
        subcategoria: isPartialRefund ? 'Devolución Parcial de Garantía' : 'Devolución de Garantía',
        descripcion: isPartialRefund 
          ? `Devolución parcial de garantía de reserva Dpto: ${reservationForRefund.departamentoId || 'EC'} | Reserva: ${reservationForRefund.id}. Op Devolución: ${refundOpNumber}. Motivo: ${refundPenaltyReason}`
          : `Devolución de garantía de reserva Dpto: ${reservationForRefund.departamentoId || 'EC'} | Reserva: ${reservationForRefund.id}. Op Devolución: ${refundOpNumber}`,
        fecha_transaccion: Timestamp.fromDate(guaranteeDateObj),
        fecha_creacion: serverTimestamp(),
        usuario_registro: authUser.uid,
        metodo_pago: 'transferencia',
        nro_operacion: refundOpNumber,
        pago_id: reservationForRefund.id,
        voucher_url: receiptUrl || null,
        multa_motivo: isPartialRefund ? refundPenaltyReason : null,
        multa_evidencia_url: isPartialRefund ? evidenceUrl : null,
        monto_garantia_original: originalGarantia,
        monto_descuento_garantia: originalGarantia - amount,
        period_id: periodId
      };
      batch.set(transRefLocal, transactionData);

      // 2. Decrement bank account balance
      const accountRef = doc(db, 'condominios', condominioId, 'cuentas', refundSourceAccountId);
      batch.update(accountRef, {
        saldo_actual: increment(-amount),
        fecha_ultima_transaccion: Timestamp.fromDate(guaranteeDateObj)
      });

      // 3. Update reservation document
      const reservaRef = doc(db, 'condominios', condominioId, 'espacios_comunes', reservationForRefund.espacioComunId, 'reservas', reservationForRefund.id!);
      batch.update(reservaRef, {
        garantia_estado: 'devuelto',
        garantia_devolucion_monto: amount,
        garantia_devolucion_original: originalGarantia,
        garantia_devolucion_diferencia: originalGarantia - amount,
        garantia_devolucion_fecha: Timestamp.fromDate(guaranteeDateObj),
        garantia_devolucion_periodo: periodId,
        garantia_devolucion_constancia_url: receiptUrl || null,
        garantia_devolucion_usuario: authUser.uid,
        garantia_devolucion_nro_operacion: refundOpNumber,
        garantia_devolucion_cuenta_id: refundSourceAccountId,
        garantia_devolucion_transaccion_id: transRefLocal.id,
        garantia_devolucion_notas: refundNotes.trim() || null,
        garantia_devolucion_diferencia_motivo: isPartialRefund ? refundPenaltyReason : null,
        garantia_devolucion_diferencia_evidencia_url: isPartialRefund ? evidenceUrl : null,
        fechaModificacion: serverTimestamp(),
        usuarioModificacion: authUser.uid,
      });

      await batch.commit();

      // 4. Audit Log
      await logAuditAction({
        condominioId,
        action: 'Devolución Garantía',
        module: 'Espacios Comunes',
        type: 'update',
        details: isPartialRefund
          ? `Devolución parcial de garantía para reserva de ${reservationForRefund.espacioComunNombre}. Monto devuelto: ${formatCurrency(amount, reservationForRefund.monedaCosto ?? undefined)} (Original: ${formatCurrency(originalGarantia, reservationForRefund.monedaCosto ?? undefined)}). Descuento: ${formatCurrency(originalGarantia - amount, reservationForRefund.monedaCosto ?? undefined)}. Motivo: ${refundPenaltyReason}. Op: ${refundOpNumber}. Cuenta debitada: ${refundSourceAccountId}`
          : `Devolución de garantía para reserva de ${reservationForRefund.espacioComunNombre}. Monto devuelto: ${formatCurrency(amount, reservationForRefund.monedaCosto ?? undefined)}. Op: ${refundOpNumber}. Cuenta debitada: ${refundSourceAccountId}`,
        user: { uid: authUser.uid, email: authUser.email || '', displayName: authUser.displayName || undefined }
      });

      // 5. Send notification to resident
      const notificationMessage = isPartialRefund 
        ? `Se ha realizado el reembolso parcial de garantía por S/ ${amount.toFixed(2)} (Garantía original: S/ ${originalGarantia.toFixed(2)}). Se descontó la diferencia por: ${refundPenaltyReason}. Op de Devolución: ${refundOpNumber}`
        : `Se ha realizado con éxito el reembolso de garantía por S/ ${amount.toFixed(2)} por tu reserva de ${reservationForRefund.espacioComunNombre}. Op de Devolución: ${refundOpNumber}`;

      await notificationService.sendNotification({
        userId: reservationForRefund.userEmail || reservationForRefund.usuarioId,
        title: isPartialRefund ? "Garantía Devuelta Parcialmente" : "Garantía Devuelta",
        message: notificationMessage,
        type: isPartialRefund ? 'warning' : 'success',
        condominioId,
        link: `/condominios/${condominioId}/espacios-comunes-usuario/mis-reservas`,
      });

      toast({ title: isPartialRefund ? "Garantía devuelta parcialmente" : "Garantía devuelta exitosamente" });
      setIsRefundDialogOpen(false);
      setReservationForRefund(null);
    } catch (err: any) {
      console.error("Error refunding guarantee:", err);
      toast({ title: "Error al devolver garantía", description: err.message, variant: "destructive" });
    } finally {
      setIsRefundUploading(false);
      setRefundUploadProgress(null);
    }
  };

  const getStatusBadgeVariant = (status: ReservaParaValidacionView['estado']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'CONFIRMADO': return "default";
      case 'SOLICITADO': return "secondary";
      case 'RECHAZADO': return "destructive";
      case 'CANCELADO_USUARIO':
      case 'CANCELADO_ADMIN':
        return "outline";
      default: return "outline";
    }
  };

  const getPaymentValidationBadgeVariant = (status?: 'pendiente' | 'validado' | 'rechazado'): "default" | "secondary" | "destructive" | "outline" => {
    if (!status) return "outline";
    switch (status) {
      case 'validado': return "default";
      case 'pendiente': return "secondary";
      case 'rechazado': return "destructive";
      default: return "outline";
    }
  };

  const renderEventStatusBadge = (reserva: ReservaParaValidacionView) => {
    const now = new Date();
    const start = reserva.fechaHoraInicio.toDate();
    const end = reserva.fechaHoraFin.toDate();

    if (now < start) {
      return <Badge className="bg-blue-500 hover:bg-blue-600 text-white font-bold text-[10px] uppercase">Próximo</Badge>;
    } else if (now >= start && now <= end) {
      return <Badge className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-[10px] uppercase">En Progreso</Badge>;
    } else {
      return <Badge className="bg-rose-500 hover:bg-rose-600 text-white font-bold text-[10px] uppercase">Finalizado</Badge>;
    }
  };

  const handleViewReceipt = (url: string | undefined) => {
    if (!url) {
      toast({ title: t('noReceipts'), description: "No receipt URL found for this payment.", variant: "default" });
      return;
    }
    setSelectedReceiptUrl(url);
    setReceiptModalOpen(true);
  };


  const renderReservationsTable = (reservas: ReservaParaValidacionView[], currentTab: typeof activeTab) => {
    if (reservas.length === 0) {
      return <p className="text-muted-foreground text-center py-8">{t('noReservationsToValidate')}</p>;
    }
    return (
      <>
        {/* Desktop: Tabla tradicional */}
        <div className="hidden md:block overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('commonAreaNameLabel')}</TableHead>
                <TableHead>{t('userWhoReserved')}</TableHead>
                <TableHead>{t('reservationDates')}</TableHead>
                <TableHead className="hidden lg:table-cell text-center">{t('recurrenceType')}</TableHead>
                <TableHead className="hidden lg:table-cell">{t('reasonForBooking')}</TableHead>
                {currentTab === 'rechazadas-canceladas' && <TableHead className="hidden xl:table-cell">{t('adminNotes')}</TableHead>}
                {currentTab === 'garantias' && garantiaSubTab === 'devueltas' && <TableHead className="hidden xl:table-cell">Detalle Devolución</TableHead>}
                <TableHead className="text-center">{currentTab === 'garantias' ? 'Estado Evento' : t('status')}</TableHead>
                <TableHead className="text-right">{currentTab === 'garantias' ? 'Costo / Garantía' : t('cost')}</TableHead>
                <TableHead className="text-center">{t('paymentInfo')}</TableHead>
                <TableHead className="text-right">{t('actions')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reservas.map((reserva) => (
                <TableRow key={reserva.id}>
                  <TableCell>{reserva.espacioComunNombre}</TableCell>
                  <TableCell className="text-xs">
                    <div className="flex flex-col">
                      <span>{reserva.userDisplayName || reserva.userEmail}</span>
                      {reserva.departamentoId && <span className="text-[10px] font-mono text-muted-foreground">Dpto: {reserva.departamentoId}</span>}
                    </div>
                  </TableCell>
                  <TableCell className="text-xs">{formatDateRange(reserva.fechaHoraInicio, reserva.fechaHoraFin)}</TableCell>
                  <TableCell className="hidden lg:table-cell text-center">
                    <Badge variant="outline" className="text-[10px] uppercase font-bold">
                      {reserva.esExclusivo ? t('useTypeExclusive') : t('useTypeShared')}
                    </Badge>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell text-xs max-w-xs truncate">{reserva.motivoReserva || 'N/A'}</TableCell>
                  {currentTab === 'rechazadas-canceladas' && <TableCell className="hidden xl:table-cell text-xs max-w-xs truncate">{reserva.notasAdmin || 'N/A'}</TableCell>}
                  {currentTab === 'garantias' && garantiaSubTab === 'devueltas' && (
                    <TableCell className="hidden xl:table-cell text-xs max-w-xs">
                      <div className="flex flex-col gap-0.5 text-[10px] text-muted-foreground leading-tight">
                        <span>Cta: {cuentas.find(c => c.id === reserva.garantia_devolucion_cuenta_id)?.nombre || reserva.garantia_devolucion_cuenta_id || 'N/A'}</span>
                        {reserva.garantia_devolucion_fecha && <span>Fecha: {formatDate(reserva.garantia_devolucion_fecha)}</span>}
                      </div>
                    </TableCell>
                  )}
                  <TableCell className="text-center">
                    {currentTab === 'garantias' ? (
                      <div className="flex flex-col items-center gap-1">
                        {renderEventStatusBadge(reserva)}
                        <Badge variant="outline" className="text-[9px] uppercase font-bold px-1.5 h-4">
                          {reserva.garantia_estado === 'pendiente' ? 'Pendiente' : 'Devuelto'}
                        </Badge>
                      </div>
                    ) : (
                      <Badge variant={getStatusBadgeVariant(reserva.estado)}>{t(`reservationStatus_${reserva.estado}` as any) || reserva.estado}</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    {currentTab === 'garantias' ? (
                      <div className="flex flex-col items-end gap-0.5 leading-tight text-xs">
                        <span className="font-medium text-slate-500">Alq: {formatCurrency(reserva.montoAlquiler ?? reserva.costoReserva, reserva.monedaCosto ?? undefined)}</span>
                        <span className="font-bold text-amber-700 bg-amber-50 px-1 rounded-[4px] text-[10px]">Gar: {formatCurrency(reserva.montoGarantia, reserva.monedaCosto ?? undefined)}</span>
                      </div>
                    ) : (
                      Boolean(reserva.costoReserva && reserva.costoReserva > 0) ? formatCurrency(reserva.costoReserva, reserva.monedaCosto ?? undefined) : <span className="text-muted-foreground italic text-xs">{t('no')}</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center text-xs">
                    {currentTab === 'garantias' && garantiaSubTab === 'devueltas' ? (
                      <div className="flex flex-col items-center gap-0.5">
                        {reserva.garantia_devolucion_nro_operacion && <span className="font-mono text-[9px] font-bold">Op Dev: {reserva.garantia_devolucion_nro_operacion}</span>}
                        {reserva.garantia_devolucion_constancia_url && (
                          <Button variant="link" size="sm" className="p-0 h-auto text-[10px] text-teal-600 font-semibold" onClick={() => handleViewReceipt(reserva.garantia_devolucion_constancia_url ?? undefined)}>
                            Ver Voucher Dev.
                          </Button>
                        )}
                      </div>
                    ) : (
                      Boolean(reserva.costoReserva && reserva.costoReserva > 0) ? (
                        <div className="flex flex-col items-center gap-0.5">
                          {reserva.pagoNroOperacion && <span>{reserva.pagoNroOperacion}</span>}
                          {reserva.pagoConstanciaUrl && (
                            <Button variant="link" size="sm" className="p-0 h-auto text-xs" onClick={() => handleViewReceipt(reserva.pagoConstanciaUrl ?? undefined)}>
                              {t('viewReceipt')}
                            </Button>
                          )}
                          {reserva.pago_estado_validacion && <Badge variant={getPaymentValidationBadgeVariant(reserva.pago_estado_validacion)} className="text-[10px] px-1.5 py-0.5">{t(`paymentValidationStatusShort_${reserva.pago_estado_validacion}` as any) || reserva.pago_estado_validacion}</Badge>}
                        </div>
                      ) : (
                        <span className="text-muted-foreground italic">{t('no')}</span>
                      )
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 rounded-full"
                        title="Ver detalle"
                        onClick={() => { setDetailReserva(reserva); setIsDetailOpen(true); }}
                      >
                        <Icons.Eye className="h-4 w-4" />
                      </Button>
                      {(currentTab === 'solicitadas' || currentTab === 'confirmadas') && canValidate && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 rounded-full text-red-500 hover:text-red-600 hover:bg-red-50"
                          title="Cancelar Reserva"
                          onClick={() => handleOpenCancelReservaDialog(reserva)}
                        >
                          <Icons.XCircle className="h-4 w-4" />
                        </Button>
                      )}
                      {currentTab === 'solicitadas' && canValidate && reserva.requiere_aprobacion !== false && (
                        <>
                          <Button variant="outline" size="sm" onClick={() => handleOpenApproveDialog(reserva)} disabled={isPast(reserva.fechaHoraInicio.toDate())}>
                            <Icons.CheckCircle2 className="mr-1 h-4 w-4" /> {t('approveReservation')}
                          </Button>
                          <Button variant="destructive" size="sm" onClick={() => handleOpenRejectDialog(reserva)} disabled={isPast(reserva.fechaHoraInicio.toDate())}>
                            <Icons.XCircle className="mr-1 h-4 w-4" /> {t('rejectReservation')}
                          </Button>
                        </>
                      )}
                      {currentTab === 'garantias' && garantiaSubTab === 'pendientes' && canValidate && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => handleOpenRefundDialog(reserva)}
                          className="bg-amber-50 hover:bg-amber-100 text-amber-700 border-amber-200 text-xs h-8 rounded-lg"
                        >
                          <Icons.HandCoins className="mr-1.5 h-4 w-4 text-amber-600" /> Devolver
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Móvil: Vista de tarjetas con Dropdown/Popup Mimic */}
        <div className="grid grid-cols-1 gap-2.5 md:hidden relative pb-8">
          {reservas.map((reserva, index) => (
            <Card
              key={`mobile-${reserva.id}`}
              className={cn(
                "shadow-sm transition-all duration-500 relative overflow-hidden",
                selectedMobileReserva?.id === reserva.id
                  ? "border-primary/60 ring-2 ring-primary/20 scale-[0.98] opacity-100 z-10"
                  : (highlightFirstMobileReserva && index === 0 && !selectedMobileReserva)
                    ? "border-primary ring-2 ring-primary/60 shadow-lg shadow-primary/20 animate-pulse bg-primary/5"
                    : "border-border/60 hover:border-primary/40 active:scale-[0.99]"
              )}
              onClick={() => setSelectedMobileReserva(reserva)}
              role="button"
              tabIndex={0}
            >
              <CardHeader className={cn(
                "pb-1.5 border-b px-4 pt-2 rounded-t-xl transition-colors",
                selectedMobileReserva?.id === reserva.id ? "bg-primary/10" : "bg-muted/20"
              )}>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Icons.Calendar className={cn("h-5 w-5", selectedMobileReserva?.id === reserva.id ? "text-primary" : "text-primary/70")} />
                    <span className="text-base font-headline font-bold text-foreground">
                      {reserva.espacioComunNombre}
                    </span>
                  </div>
                  <div className="flex flex-row flex-wrap items-center justify-end gap-1.5">
                    {currentTab === 'garantias' ? (
                      <>
                        {renderEventStatusBadge(reserva)}
                        <Badge variant="outline" className="text-[10px] uppercase shrink-0">
                          Gar: {reserva.garantia_estado === 'pendiente' ? 'Pend.' : 'Dev.'}
                        </Badge>
                      </>
                    ) : (
                      <>
                        <Badge variant={getStatusBadgeVariant(reserva.estado)} className="text-[10px] uppercase shrink-0">{t(`reservationStatus_${reserva.estado}` as any) || reserva.estado}</Badge>
                        {reserva.pago_estado_validacion && (
                          <Badge variant={getPaymentValidationBadgeVariant(reserva.pago_estado_validacion)} className="text-[10px] uppercase shrink-0">{t(`paymentValidationStatusShort_${reserva.pago_estado_validacion}` as any) || reserva.pago_estado_validacion}</Badge>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="px-4 py-3 space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <div className="text-muted-foreground truncate">{reserva.userDisplayName || reserva.userEmail}</div>
                  <div className="font-medium text-xs sm:text-sm">{formatDateRange(reserva.fechaHoraInicio, reserva.fechaHoraFin).split(' - ')[0]}</div>
                </div>
                {currentTab === 'garantias' && (
                  <div className="flex justify-between items-center text-xs pt-1 border-t border-dashed">
                    <span className="text-muted-foreground">Depósito de Garantía:</span>
                    <span className="font-bold text-amber-700">{formatCurrency(reserva.montoGarantia, reserva.monedaCosto ?? undefined)}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Modal/Overlay View for Mobile */}
        {selectedMobileReserva && (
          <div
            className="fixed inset-0 z-[100] bg-black/60 flex flex-col justify-end lg:justify-center items-center py-10 gap-8 backdrop-blur-[2px] animate-in fade-in duration-200 md:hidden"
            onClick={() => setSelectedMobileReserva(null)}
          >
            <div className="flex-1 flex items-center w-full px-[25px]" onClick={(e) => e.stopPropagation()}>
              <Card className="shadow-2xl border-border/20 bg-background overflow-hidden w-full rounded-[24px]">
                <CardHeader className="pb-3 border-b bg-muted/10 px-5 pt-5 rounded-t-[24px]">
                  <div className="flex justify-between items-center gap-2">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <Icons.Calendar className="h-6 w-6 text-primary shrink-0" />
                      <span className="text-xl font-headline font-bold text-foreground leading-tight truncate">{selectedMobileReserva.espacioComunNombre}</span>
                    </div>
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      {currentTab === 'garantias' ? (
                        <div className="flex flex-col items-end gap-1">
                          {renderEventStatusBadge(selectedMobileReserva)}
                          <Badge variant="outline" className="text-[10px]">
                            Garantía: {selectedMobileReserva.garantia_estado === 'pendiente' ? 'Pendiente' : selectedMobileReserva.garantia_estado === 'devuelto' ? 'Devuelta' : selectedMobileReserva.garantia_estado === 'cancelado' ? 'No Requerida' : 'No Aplica'}
                          </Badge>
                        </div>
                      ) : (
                        <Badge variant={getStatusBadgeVariant(selectedMobileReserva.estado)}>{t(`reservationStatus_${selectedMobileReserva.estado}` as any) || selectedMobileReserva.estado}</Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="px-5 py-5 space-y-5">
                  <div className="grid grid-cols-2 gap-y-5 gap-x-2 text-sm">
                    <div className="col-span-2">
                      <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1.5">{t('reservingUserLabel') || 'Usuario'}</span>
                      <span className="font-medium text-foreground text-[15px]">{selectedMobileReserva.userDisplayName || selectedMobileReserva.userEmail}</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1.5">{t('reservationDates')}</span>
                      <span className="font-medium text-foreground text-[14px]">{formatDateRange(selectedMobileReserva.fechaHoraInicio, selectedMobileReserva.fechaHoraFin)}</span>
                    </div>
                    <div>
                      <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1.5">{t('recurrenceType')}</span>
                      <Badge variant="outline" className="text-[10px] uppercase font-bold">
                        {selectedMobileReserva.esExclusivo ? t('useTypeExclusive') : t('useTypeShared')}
                      </Badge>
                    </div>
                    <div>
                      <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1.5">
                        {currentTab === 'garantias' ? 'Depósito Garantía' : t('cost')}
                      </span>
                      <span className="font-bold text-foreground text-[14px]">
                        {currentTab === 'garantias' ? (
                          <span className="text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded">{formatCurrency(selectedMobileReserva.montoGarantia, selectedMobileReserva.monedaCosto ?? undefined)}</span>
                        ) : (
                          Boolean(selectedMobileReserva.costoReserva && selectedMobileReserva.costoReserva > 0) ? formatCurrency(selectedMobileReserva.costoReserva, selectedMobileReserva.monedaCosto ?? undefined) : <span className="text-muted-foreground italic text-xs font-normal">{t('no')}</span>
                        )}
                      </span>
                    </div>
                    {currentTab === 'garantias' && (
                      <div>
                        <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1.5">Costo Alquiler</span>
                        <span className="font-medium text-foreground text-[14px]">
                          {formatCurrency(selectedMobileReserva.montoAlquiler ?? selectedMobileReserva.costoReserva, selectedMobileReserva.monedaCosto ?? undefined)}
                        </span>
                      </div>
                    )}
                    {selectedMobileReserva.motivoReserva && (
                      <div className="col-span-2">
                        <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1.5">{t('reasonForBooking')}</span>
                        <span className="font-medium text-foreground text-[14px]">{selectedMobileReserva.motivoReserva}</span>
                      </div>
                    )}
                    {currentTab === 'rechazadas-canceladas' && selectedMobileReserva.notasAdmin && (
                      <div className="col-span-2">
                        <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1.5">{t('adminNotes')}</span>
                        <span className="font-medium text-foreground text-[14px]">{selectedMobileReserva.notasAdmin}</span>
                      </div>
                    )}
                    {currentTab === 'garantias' && (
                      <div className="col-span-2 border-t pt-3 mt-1 space-y-2">
                        <span className="text-[11px] font-bold text-[#2D4F5E] uppercase block">Detalle de Garantía</span>
                        <div className="grid grid-cols-2 gap-y-2 text-xs leading-tight text-muted-foreground">
                          <div>
                            <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Garantía Original</span>
                            <span className="text-amber-700 font-mono font-bold text-[13px]">{formatCurrency(selectedMobileReserva.montoGarantia, selectedMobileReserva.monedaCosto ?? undefined)}</span>
                          </div>
                          <div>
                            <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Estado Garantía</span>
                            <Badge variant="outline" className="text-[9px] uppercase font-bold">
                              {selectedMobileReserva.garantia_estado === 'pendiente' 
                                ? 'Pendiente' 
                                : selectedMobileReserva.garantia_estado === 'devuelto' 
                                  ? 'Devuelto' 
                                  : selectedMobileReserva.garantia_estado === 'cancelado' 
                                    ? 'No Requerido' 
                                    : 'No Aplica'}
                            </Badge>
                          </div>
                          {selectedMobileReserva.garantia_estado === 'devuelto' && (
                            <>
                              <div>
                                <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Monto Devuelto</span>
                                <span className="text-emerald-600 font-mono font-bold text-[13px]">{formatCurrency(selectedMobileReserva.garantia_devolucion_monto ?? selectedMobileReserva.montoGarantia, selectedMobileReserva.monedaCosto ?? undefined)}</span>
                              </div>
                              {selectedMobileReserva.garantia_devolucion_diferencia !== undefined && selectedMobileReserva.garantia_devolucion_diferencia > 0 && (
                                <div>
                                  <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Retención / Multa</span>
                                  <span className="text-red-600 font-mono font-bold text-[13px]">-{formatCurrency(selectedMobileReserva.garantia_devolucion_diferencia, selectedMobileReserva.monedaCosto ?? undefined)}</span>
                                </div>
                              )}
                              <div>
                                <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Cuenta Origen</span>
                                 <span className="text-foreground text-[13px]">{cuentas.find(c => c.id === selectedMobileReserva.garantia_devolucion_cuenta_id)?.nombre || selectedMobileReserva.garantia_devolucion_cuenta_id || 'N/A'}</span>
                              </div>
                              <div>
                                <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Nro. Op Dev</span>
                                <span className="text-foreground text-[13px] font-mono font-bold">{selectedMobileReserva.garantia_devolucion_nro_operacion || 'N/A'}</span>
                              </div>
                              {selectedMobileReserva.garantia_devolucion_fecha && (
                                <div className="col-span-2">
                                  <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Fecha Reembolso</span>
                                  <span className="text-foreground text-[13px]">{formatDate(selectedMobileReserva.garantia_devolucion_fecha)}</span>
                                </div>
                              )}
                              {selectedMobileReserva.garantia_devolucion_constancia_url && (
                                <div className="col-span-2 mt-1">
                                  <Button variant="outline" size="sm" className="w-full text-xs h-8" onClick={() => handleViewReceipt(selectedMobileReserva.garantia_devolucion_constancia_url ?? undefined)}>
                                    <Icons.Eye className="mr-2 h-3.5 w-3.5" /> Ver Constancia Dev
                                  </Button>
                                </div>
                              )}
                              {selectedMobileReserva.garantia_devolucion_diferencia_evidencia_url && (
                                <div className="col-span-2 mt-1">
                                  <Button variant="outline" size="sm" className="w-full text-xs h-8 text-red-500 hover:text-red-600 hover:bg-red-50/20 border-red-200" onClick={() => handleViewReceipt(selectedMobileReserva.garantia_devolucion_diferencia_evidencia_url ?? undefined)}>
                                    <Icons.Eye className="mr-2 h-3.5 w-3.5 text-red-500" /> Ver Evidencia Multa / Daño
                                  </Button>
                                </div>
                              )}
                              {selectedMobileReserva.garantia_devolucion_diferencia_motivo && (
                                <div className="col-span-2 mt-1 p-2 bg-red-50/50 rounded-lg border border-red-100 text-red-900 leading-normal">
                                  <span className="font-semibold block text-[9px] text-red-700 uppercase">Motivo del descuento</span>
                                  <span className="text-[12px]">{selectedMobileReserva.garantia_devolucion_diferencia_motivo}</span>
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      </div>
                    )}
                    {currentTab !== 'garantias' && Boolean(selectedMobileReserva.costoReserva && selectedMobileReserva.costoReserva > 0) && (
                      <div className="col-span-2">
                        <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1.5">{t('paymentInfo')}</span>
                        <div className="flex flex-col gap-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[13px]">{selectedMobileReserva.pagoNroOperacion ? `Op: ${selectedMobileReserva.pagoNroOperacion}` : 'Sin Nro. Op'}</span>
                            {selectedMobileReserva.pago_estado_validacion && <Badge variant={getPaymentValidationBadgeVariant(selectedMobileReserva.pago_estado_validacion)} className="text-[10px] sm:text-xs">{t(`paymentValidationStatusShort_${selectedMobileReserva.pago_estado_validacion}` as any) || selectedMobileReserva.pago_estado_validacion}</Badge>}
                          </div>
                          {selectedMobileReserva.pagoConstanciaUrl && (
                            <Button variant="outline" size="sm" className="w-full text-xs h-8" onClick={() => handleViewReceipt(selectedMobileReserva.pagoConstanciaUrl ?? undefined)}>
                              <Icons.FileText className="mr-2 h-3.5 w-3.5" /> {t('viewReceipt')}
                            </Button>
                          )}
                        </div>
                      </div>
                    )}
                    {currentTab === 'garantias' && selectedMobileReserva.garantia_devolucion_constancia_url && (
                      <div className="col-span-2 pt-2">
                        <Button variant="outline" size="sm" className="w-full text-xs h-8 text-teal-700 border-teal-200" onClick={() => handleViewReceipt(selectedMobileReserva.garantia_devolucion_constancia_url ?? undefined)}>
                          <Icons.FileText className="mr-2 h-3.5 w-3.5" /> Ver Constancia de Devolución
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Actions Panel - bottom area */}
            <div className="relative w-full px-[10px] animate-in slide-in-from-bottom-8 duration-300" onClick={(e) => e.stopPropagation()}>
              <div className="grid grid-cols-2 gap-x-[112px] gap-y-8">
                {currentTab === 'solicitadas' && canValidate && selectedMobileReserva.requiere_aprobacion !== false ? (
                  <>
                    <Button
                      variant="ghost"
                      className="flex items-center justify-center h-[64px] px-5 gap-3 bg-[#f0f3f5] hover:bg-[#e2e6e9] text-teal-700 transition-all rounded-2xl shadow-sm w-full"
                      onClick={() => { handleOpenApproveDialog(selectedMobileReserva); setSelectedMobileReserva(null); }}
                      disabled={isPast(selectedMobileReserva.fechaHoraInicio.toDate())}
                    >
                      <Icons.CheckCircle2 className="h-5 w-5 shrink-0" />
                      <span className="text-[12px] sm:text-[14px] font-semibold text-center leading-tight">Aprobar<br />Reserva</span>
                    </Button>

                    <Button
                      variant="ghost"
                      className="flex items-center justify-center h-[64px] px-5 gap-3 bg-[#f0f3f5] hover:bg-[#e2e6e9] text-red-600 transition-all rounded-2xl shadow-sm w-full"
                      onClick={() => { handleOpenRejectDialog(selectedMobileReserva); setSelectedMobileReserva(null); }}
                      disabled={isPast(selectedMobileReserva.fechaHoraInicio.toDate())}
                    >
                      <Icons.XCircle className="h-5 w-5 shrink-0" />
                      <span className="text-[12px] sm:text-[14px] font-semibold text-center leading-tight">Rechazar<br />Reserva</span>
                    </Button>
                  </>
                ) : currentTab === 'garantias' && garantiaSubTab === 'pendientes' && canValidate ? (
                  <>
                    <Button
                      variant="ghost"
                      className="flex items-center justify-center h-[64px] px-5 gap-3 bg-amber-50 hover:bg-amber-100 text-amber-700 transition-all rounded-2xl shadow-sm w-full border border-amber-200 col-span-2"
                      onClick={() => { handleOpenRefundDialog(selectedMobileReserva); setSelectedMobileReserva(null); }}
                    >
                      <Icons.HandCoins className="h-5 w-5 shrink-0 text-amber-600" />
                      <span className="text-[13px] font-semibold text-center leading-tight">Registrar Devolución de Garantía</span>
                    </Button>
                  </>
                ) : (currentTab === 'solicitadas' || currentTab === 'confirmadas') && canValidate ? (
                  <>
                    <Button
                      variant="ghost"
                      className="flex items-center justify-center h-[64px] px-5 gap-3 bg-red-50 hover:bg-red-100 text-red-700 transition-all rounded-2xl shadow-sm w-full border border-red-200 col-span-2"
                      onClick={() => { handleOpenCancelReservaDialog(selectedMobileReserva); setSelectedMobileReserva(null); }}
                    >
                      <Icons.XCircle className="h-5 w-5 shrink-0 text-red-600" />
                      <span className="text-[13px] font-semibold text-center leading-tight">Cancelar Reserva</span>
                    </Button>
                  </>
                ) : (
                  <>
                    <div />
                    <div />
                  </>
                )}
              </div>

              {/* Central Close Button */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 flex items-center justify-center pointer-events-none">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-[52px] w-[52px] rounded-full bg-white border border-slate-200 shadow-md pointer-events-auto"
                  onClick={() => setSelectedMobileReserva(null)}
                >
                  <Icons.X className="h-6 w-6 text-slate-500 hover:text-slate-800 transition-colors" />
                </Button>
              </div>
            </div>
          </div>
        )}
      </>
    );
  };

  const pageTitleText = condominio
    ? `${t('validateReservations' as any)} - ${condominio.nombre}`
    : t('validateReservations' as any);

  const isLoading = isLoadingData || isLoadingPermissions;

  if (isLoading) {
    return (
      <AppShell>
        <PageTitle title={pageTitleText} />
        <div className="flex items-center justify-center h-64">
          <Icons.ClipboardCheck className="h-12 w-12 animate-spin text-primary" />
        </div>
      </AppShell>
    );
  }

  if (error) {
    return (
      <AppShell>
        <PageTitle title={pageTitleText} />
        <Card><CardContent className="pt-6 text-center text-destructive">{error}</CardContent></Card>
      </AppShell>
    );
  }

  if (!condominio && !isLoadingData) {
    return (
      <AppShell>
        <PageTitle title={t('condominioNotFound')} />
      </AppShell>
    );
  }

  if (!canValidate && !isLoading) {
    return (
      <AppShell>
        <PageTitle title={pageTitleText} />
        <Card>
          <CardHeader>
            <CardTitle className="text-destructive flex items-center">
              <Icons.Lock className="mr-2 h-6 w-6" />
              {t('accessDenied')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>{t('accessDenied')}</p>
          </CardContent>
        </Card>
      </AppShell>
    );
  }

  const getFilterSummary = () => {
    const parts = [];
    if (dateFilterType === 'recent') parts.push('Recientes (7-30d)');
    else if (dateFilterType === 'current_month') parts.push('Mes actual');
    else if (dateFilterType === 'previous_month') parts.push('Mes pasado');
    else parts.push('Fechas mixtas');

    if (filterEspacioComunNombre) parts.push(`Área: ${filterEspacioComunNombre}`);
    if (filterUsuario) parts.push(`Usr: ${filterUsuario}`);

    return parts.join(' • ');
  };

  return (
    <AppShell>
      <PageTitle title={pageTitleText} />
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="font-headline">{t('validateReservationsPageTitle' as any)}</CardTitle>
          <CardDescription>{t('validateReservationsDescription' as any)}</CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible defaultValue="filters" className="mb-6 w-full bg-slate-50/50 dark:bg-slate-900/50 rounded-xl px-4 border border-border/60">
            <AccordionItem value="filters" className="border-none">
              <AccordionTrigger className="py-3 hover:no-underline text-sm font-medium">
                <div className="flex items-center text-left gap-2 w-full pr-4">
                  <Icons.Filter className="h-4 w-4 text-primary shrink-0" />
                  <span className="text-foreground truncate flex-1 block">Filtros: <span className="text-muted-foreground font-normal ml-1">{getFilterSummary()}</span></span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-2 pb-4">
                <div className="flex flex-col md:flex-row flex-wrap gap-4">
                  <div className="flex-1 flex flex-col gap-1.5 min-w-[220px]">
                    <label className="text-xs font-semibold text-muted-foreground uppercase">{t('filterByDate') || 'Fechas'}</label>
                    <Select value={dateFilterType} onValueChange={setDateFilterType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona rango" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="recent">Recientes y próximos (7-30 días)</SelectItem>
                        <SelectItem value="current_month">Mes actual</SelectItem>
                        <SelectItem value="previous_month">Mes anterior</SelectItem>
                        <SelectItem value="custom">Personalizado...</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {dateFilterType === 'custom' && (
                    <>
                      <div className="flex-1 flex flex-col gap-1.5 min-w-[140px]">
                        <label className="text-xs font-semibold text-muted-foreground uppercase">{t('startDate') || 'Desde'}</label>
                        <Input
                          type="date"
                          value={customDateStart}
                          onChange={(e) => setCustomDateStart(e.target.value)}
                          onKeyDown={(e) => e.stopPropagation()}
                        />
                      </div>
                      <div className="flex-1 flex flex-col gap-1.5 min-w-[140px]">
                        <label className="text-xs font-semibold text-muted-foreground uppercase">{t('endDate') || 'Hasta'}</label>
                        <Input
                          type="date"
                          value={customDateEnd}
                          onChange={(e) => setCustomDateEnd(e.target.value)}
                          onKeyDown={(e) => e.stopPropagation()}
                        />
                      </div>
                      <div className="flex flex-col justify-end gap-1.5">
                        <label className="text-xs font-semibold text-muted-foreground uppercase opacity-0 select-none">-</label>
                        <Button
                          type="button"
                          onClick={() => { setAppliedDateStart(customDateStart); setAppliedDateEnd(customDateEnd); }}
                          className="h-10 px-4 bg-[#008b8b] hover:bg-[#006f6f] text-white font-semibold rounded-lg text-sm gap-2 shadow-md shadow-teal-900/20 transition-all active:scale-95"
                        >
                          <Icons.Filter className="h-4 w-4" />
                          Aplicar
                        </Button>
                      </div>
                    </>
                  )}

                  <div className="flex-1 flex flex-col gap-1.5 min-w-[200px]">
                    <label className="text-xs font-semibold text-muted-foreground uppercase">{t('filterByCommonArea') || 'Área Común'}</label>
                    <Input placeholder={t('filterByCommonArea')} value={filterEspacioComunNombre} onChange={(e) => setFilterEspacioComunNombre(e.target.value)} />
                  </div>
                  <div className="flex-1 flex flex-col gap-1.5 min-w-[200px]">
                    <label className="text-xs font-semibold text-muted-foreground uppercase">{t('filterByUser') || 'Usuario'}</label>
                    <Input placeholder={t('filterByUser')} value={filterUsuario} onChange={(e) => setFilterUsuario(e.target.value)} />
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
          <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="w-full">
            <TabsList className="flex flex-wrap h-auto gap-1 w-full mb-4 sm:grid sm:grid-cols-4">
              <TabsTrigger value="solicitadas" className="flex-1 min-w-[100px] text-xs sm:text-sm">{t('tabRequested')}</TabsTrigger>
              <TabsTrigger value="confirmadas" className="flex-1 min-w-[100px] text-xs sm:text-sm">{t('tabConfirmed')}</TabsTrigger>
              <TabsTrigger value="rechazadas-canceladas" className="flex-1 min-w-[100px] text-xs sm:text-sm">{t('tabRejectedCancelled')}</TabsTrigger>
              <TabsTrigger value="garantias" className="flex-1 min-w-[100px] text-xs sm:text-sm">Garantías</TabsTrigger>
            </TabsList>
            <TabsContent value="solicitadas">{renderReservationsTable(getReservationsByStatus('solicitadas'), 'solicitadas')}</TabsContent>
            <TabsContent value="confirmadas">{renderReservationsTable(getReservationsByStatus('confirmadas'), 'confirmadas')}</TabsContent>
            <TabsContent value="rechazadas-canceladas">{renderReservationsTable(getReservationsByStatus('rechazadas-canceladas'), 'rechazadas-canceladas')}</TabsContent>
            <TabsContent value="garantias">
              <div className="space-y-4">
                <div className="flex justify-start border-b border-muted">
                  <button 
                    onClick={() => setGarantiaSubTab('pendientes')} 
                    className={cn(
                      "px-4 py-2 text-sm font-bold border-b-2 transition-all",
                      garantiaSubTab === 'pendientes' 
                        ? "border-[#008b8b] text-[#008b8b]" 
                        : "border-transparent text-muted-foreground hover:text-foreground"
                    )}
                  >
                    Pendientes de Devolución
                  </button>
                  <button 
                    onClick={() => setGarantiaSubTab('devueltas')} 
                    className={cn(
                      "px-4 py-2 text-sm font-bold border-b-2 transition-all",
                      garantiaSubTab === 'devueltas' 
                        ? "border-[#008b8b] text-[#008b8b]" 
                        : "border-transparent text-muted-foreground hover:text-foreground"
                    )}
                  >
                    Historial de Devueltas
                  </button>
                </div>
                {renderReservationsTable(getReservationsByStatus('garantias'), 'garantias')}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {selectedReservationForAction && (
        <AlertDialog open={isApproveConfirmOpen} onOpenChange={setIsApproveConfirmOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>{t('confirmApproveReservationTitle')}</AlertDialogTitle>
              <AlertDialogDescription>
                {t('confirmApproveReservationMessage', {
                  commonAreaName: selectedReservationForAction.espacioComunNombre,
                  userEmail: selectedReservationForAction.userEmail || selectedReservationForAction.usuarioId,
                  dateTimeRange: formatDateRange(selectedReservationForAction.fechaHoraInicio, selectedReservationForAction.fechaHoraFin)
                })}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setIsApproveConfirmOpen(false)}>{t('cancel')}</AlertDialogCancel>
              <AlertDialogAction onClick={handleConfirmApproveReservation}>{t('approveReservation')}</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      {selectedReservationForAction && (
        <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{t('confirmRejectReservationTitle')}</DialogTitle>
              <DialogDescription>
                {t('confirmRejectReservationMessage', {
                  commonAreaName: selectedReservationForAction.espacioComunNombre,
                  userEmail: selectedReservationForAction.userEmail || selectedReservationForAction.usuarioId,
                  dateTimeRange: formatDateRange(selectedReservationForAction.fechaHoraInicio, selectedReservationForAction.fechaHoraFin)
                })}
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <Textarea
                placeholder={t('rejectionReason')}
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={3}
              />
              {!rejectionReason.trim() && (
                <p className="text-xs text-destructive mt-1">{t('rejectionReasonRequired')}</p>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>{t('cancel')}</Button>
              <Button variant="destructive" onClick={handleConfirmRejectReservation} disabled={!rejectionReason.trim()}>{t('rejectReservation')}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      {/* Receipt Viewer Dialog */}
      <Dialog open={receiptModalOpen} onOpenChange={setReceiptModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{t('paymentReceiptLabel')}</DialogTitle>
          </DialogHeader>
          {selectedReceiptUrl && (
            <div className="relative aspect-square w-full my-4">
              <Image src={selectedReceiptUrl} alt={t('paymentReceiptLabel')} layout="fill" objectFit="contain" data-ai-hint="receipt document" />
            </div>
          )}
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline">{t('cancel')}</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reservation Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl font-headline">
              <Icons.CalendarDays className="h-5 w-5 text-primary" />
              {detailReserva?.espacioComunNombre}
            </DialogTitle>
            <DialogDescription>
              Detalle completo de la reserva
            </DialogDescription>
          </DialogHeader>
          {detailReserva && (
            <div className="grid grid-cols-2 gap-y-4 gap-x-6 py-4 text-sm">
              <div className="col-span-2">
                <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1">Usuario</span>
                <span className="font-medium">{detailReserva.userDisplayName || detailReserva.userEmail}</span>
              </div>
              <div className="col-span-2">
                <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1">Fechas</span>
                <span className="font-medium">{formatDateRange(detailReserva.fechaHoraInicio, detailReserva.fechaHoraFin)}</span>
              </div>
              <div>
                <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1">Estado</span>
                <Badge variant={getStatusBadgeVariant(detailReserva.estado)}>{t(`reservationStatus_${detailReserva.estado}` as any) || detailReserva.estado}</Badge>
              </div>
              <div>
                <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1">Tipo de Uso</span>
                <Badge variant="outline" className="text-[10px] uppercase font-bold">{detailReserva.esExclusivo ? t('useTypeExclusive') : t('useTypeShared')}</Badge>
              </div>
              <div>
                <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1">Costo</span>
                <span className="font-semibold">{detailReserva.costoReserva && detailReserva.costoReserva > 0 ? formatCurrency(detailReserva.costoReserva, detailReserva.monedaCosto ?? undefined) : 'Sin costo'}</span>
              </div>
              <div>
                <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1">Requiere Aprobación</span>
                <Badge variant={detailReserva.requiere_aprobacion !== false ? 'secondary' : 'outline'} className="text-[10px]">
                  {detailReserva.requiere_aprobacion !== false ? 'Sí' : 'No'}
                </Badge>
              </div>
              {detailReserva.motivoReserva && (
                <div className="col-span-2">
                  <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1">Motivo</span>
                  <span className="font-medium">{detailReserva.motivoReserva}</span>
                </div>
              )}
              {detailReserva.notasAdmin && (
                <div className="col-span-2">
                  <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1">Notas Admin</span>
                  <span className="font-medium text-destructive">{detailReserva.notasAdmin}</span>
                </div>
              )}
              {detailReserva.pago_estado_validacion && (
                <div className="col-span-2">
                  <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1">Estado de Pago</span>
                  <div className="flex items-center gap-3">
                    <Badge variant={getPaymentValidationBadgeVariant(detailReserva.pago_estado_validacion)}>
                      {detailReserva.pago_estado_validacion}
                    </Badge>
                    {detailReserva.pagoNroOperacion && <span className="text-xs font-mono">Op: {detailReserva.pagoNroOperacion}</span>}
                    {detailReserva.pagoConstanciaUrl && (
                      <Button variant="link" size="sm" className="p-0 h-auto text-xs" onClick={() => { setIsDetailOpen(false); handleViewReceipt(detailReserva.pagoConstanciaUrl ?? undefined); }}>
                        <Icons.Eye className="h-3 w-3 mr-1" /> Ver Voucher
                      </Button>
                    )}
                  </div>
                </div>
              )}
              {detailReserva.pago_devolucion_monto !== undefined && detailReserva.pago_devolucion_monto > 0 && (
                <div className="col-span-2 border-t pt-3 mt-1 space-y-2">
                  <span className="text-[11px] font-bold text-red-700 uppercase block">Reembolso por Cancelación</span>
                  <div className="grid grid-cols-2 gap-y-2 text-xs leading-tight">
                    <div>
                      <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Monto Reembolsado</span>
                      <span className="text-emerald-600 font-mono font-bold">{formatCurrency(detailReserva.pago_devolucion_monto, detailReserva.monedaCosto ?? undefined)}</span>
                    </div>
                    {detailReserva.pago_devolucion_original !== undefined && detailReserva.pago_devolucion_original > 0 && (
                      <div>
                        <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Monto Esperado</span>
                        <span className="text-slate-600 font-mono font-bold">{formatCurrency(detailReserva.pago_devolucion_original, detailReserva.monedaCosto ?? undefined)}</span>
                      </div>
                    )}
                    {detailReserva.pago_devolucion_diferencia !== undefined && detailReserva.pago_devolucion_diferencia > 0 && (
                      <div>
                        <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Retención / Descuento</span>
                        <span className="text-red-600 font-mono font-bold">-{formatCurrency(detailReserva.pago_devolucion_diferencia, detailReserva.monedaCosto ?? undefined)}</span>
                      </div>
                    )}
                    <div>
                      <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Cuenta Origen</span>
                      <span className="text-foreground">{cuentas.find(c => c.id === detailReserva.pago_devolucion_cuenta_id)?.nombre || detailReserva.pago_devolucion_cuenta_id || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Nro. Operación</span>
                      <span className="text-foreground font-mono font-bold">{detailReserva.pago_devolucion_nro_operacion || 'N/A'}</span>
                    </div>
                    {detailReserva.pago_devolucion_fecha && (
                      <div className="col-span-2">
                        <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Fecha Reembolso</span>
                        <span className="text-foreground">{formatDate(detailReserva.pago_devolucion_fecha)}</span>
                      </div>
                    )}
                    {detailReserva.pago_devolucion_constancia_url && (
                      <div className="col-span-2 mt-1">
                        <Button variant="outline" size="sm" className="w-full text-[11px] h-8" onClick={() => { setIsDetailOpen(false); handleViewReceipt(detailReserva.pago_devolucion_constancia_url ?? undefined); }}>
                          <Icons.Eye className="mr-1.5 h-3.5 w-3.5" /> Ver Constancia Reembolso
                        </Button>
                      </div>
                    )}
                    {detailReserva.pago_devolucion_descuento_evidencia_url && (
                      <div className="col-span-2 mt-1">
                        <Button variant="outline" size="sm" className="w-full text-[11px] h-8 text-red-500 hover:text-red-600 hover:bg-red-50/20 border-red-200" onClick={() => { setIsDetailOpen(false); handleViewReceipt(detailReserva.pago_devolucion_descuento_evidencia_url ?? undefined); }}>
                          <Icons.Eye className="mr-1.5 h-3.5 w-3.5 text-red-500" /> Ver Evidencia Descuento
                        </Button>
                      </div>
                    )}
                    {detailReserva.pago_devolucion_descuento_motivo && (
                      <div className="col-span-2 mt-1 p-2 bg-red-50/50 rounded-lg border border-red-100 text-red-900">
                        <span className="font-semibold block text-[9px] text-red-700 uppercase">Motivo del descuento</span>
                        <span className="text-xs leading-normal">{detailReserva.pago_devolucion_descuento_motivo}</span>
                      </div>
                    )}
                    {detailReserva.pago_devolucion_notas ? (
                      <div className="col-span-2 mt-1 p-2 bg-slate-50 rounded-lg border text-slate-700">
                        <span className="font-semibold block text-[9px] text-slate-500 uppercase">Notas</span>
                        <span className="text-xs leading-normal">{detailReserva.pago_devolucion_notas}</span>
                      </div>
                    ) : null}
                  </div>
                </div>
              )}
              {detailReserva.montoGarantia !== undefined && detailReserva.montoGarantia > 0 && (
                <div className="col-span-2 border-t pt-3 mt-1 space-y-2">
                  <span className="text-[11px] font-bold text-[#2D4F5E] uppercase block">Detalle de Garantía</span>
                  <div className="grid grid-cols-2 gap-y-2 text-xs leading-tight">
                    <div>
                      <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Garantía Original</span>
                      <span className="text-amber-700 font-mono font-bold">{formatCurrency(detailReserva.montoGarantia, detailReserva.monedaCosto ?? undefined)}</span>
                    </div>
                    <div>
                      <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Estado Devolución</span>
                      <Badge variant="outline" className="text-[9px] uppercase font-bold">
                        {detailReserva.garantia_estado === 'pendiente' 
                          ? 'Pendiente' 
                          : detailReserva.garantia_estado === 'devuelto' 
                            ? 'Devuelto' 
                            : detailReserva.garantia_estado === 'cancelado' 
                              ? 'No Requerido' 
                              : 'No Aplica'}
                      </Badge>
                    </div>
                    {detailReserva.garantia_estado === 'devuelto' && (
                      <>
                        <div>
                          <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Monto Devuelto</span>
                          <span className="text-emerald-600 font-mono font-bold">{formatCurrency(detailReserva.garantia_devolucion_monto ?? detailReserva.montoGarantia, detailReserva.monedaCosto ?? undefined)}</span>
                        </div>
                        {detailReserva.garantia_devolucion_diferencia !== undefined && detailReserva.garantia_devolucion_diferencia > 0 && (
                          <div>
                            <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Retención / Multa</span>
                            <span className="text-red-600 font-mono font-bold">-{formatCurrency(detailReserva.garantia_devolucion_diferencia, detailReserva.monedaCosto ?? undefined)}</span>
                          </div>
                        )}
                        <div>
                          <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Cuenta Origen</span>
                          <span className="text-foreground">{cuentas.find(c => c.id === detailReserva.garantia_devolucion_cuenta_id)?.nombre || detailReserva.garantia_devolucion_cuenta_id || 'N/A'}</span>
                        </div>
                        <div>
                          <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Nro. Operación</span>
                          <span className="text-foreground font-mono font-bold">{detailReserva.garantia_devolucion_nro_operacion || 'N/A'}</span>
                        </div>
                        {detailReserva.garantia_devolucion_fecha && (
                          <div className="col-span-2">
                            <span className="font-semibold block text-[10px] text-muted-foreground uppercase">Fecha Reembolso</span>
                            <span className="text-foreground">{formatDate(detailReserva.garantia_devolucion_fecha)}</span>
                          </div>
                        )}
                        {detailReserva.garantia_devolucion_constancia_url && (
                          <div className="col-span-2 mt-1">
                            <Button variant="outline" size="sm" className="w-full text-[11px] h-8" onClick={() => { setIsDetailOpen(false); handleViewReceipt(detailReserva.garantia_devolucion_constancia_url ?? undefined); }}>
                              <Icons.Eye className="mr-1.5 h-3.5 w-3.5" /> Ver Constancia Reembolso
                            </Button>
                          </div>
                        )}
                        {detailReserva.garantia_devolucion_diferencia_evidencia_url && (
                          <div className="col-span-2 mt-1">
                            <Button variant="outline" size="sm" className="w-full text-[11px] h-8 text-red-500 hover:text-red-600 hover:bg-red-50/20 border-red-200" onClick={() => { setIsDetailOpen(false); handleViewReceipt(detailReserva.garantia_devolucion_diferencia_evidencia_url ?? undefined); }}>
                              <Icons.Eye className="mr-1.5 h-3.5 w-3.5 text-red-500" /> Ver Evidencia Multa / Daño
                            </Button>
                          </div>
                        )}
                        {detailReserva.garantia_devolucion_diferencia_motivo && (
                          <div className="col-span-2 mt-1 p-2 bg-red-50/50 rounded-lg border border-red-100 text-red-900">
                            <span className="font-semibold block text-[9px] text-red-700 uppercase">Motivo del descuento</span>
                            <span className="text-xs leading-normal">{detailReserva.garantia_devolucion_diferencia_motivo}</span>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter className="flex flex-col sm:flex-row gap-2 justify-between w-full">
            <DialogClose asChild>
              <Button type="button" variant="outline">Cerrar</Button>
            </DialogClose>
            
            {detailReserva && (detailReserva.estado === 'SOLICITADO' || detailReserva.estado === 'CONFIRMADO') && canValidate && (
              <div className="flex gap-2">
                {detailReserva.estado === 'SOLICITADO' && detailReserva.requiere_aprobacion !== false && (
                  <>
                    <Button variant="outline" size="sm" onClick={() => { setIsDetailOpen(false); handleOpenApproveDialog(detailReserva); }} disabled={isPast(detailReserva.fechaHoraInicio.toDate())}>
                      <Icons.CheckCircle2 className="mr-1 h-4 w-4" /> Aprobar
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => { setIsDetailOpen(false); handleOpenRejectDialog(detailReserva); }} disabled={isPast(detailReserva.fechaHoraInicio.toDate())}>
                      <Icons.XCircle className="mr-1 h-4 w-4" /> Rechazar
                    </Button>
                  </>
                )}
                <Button 
                  variant="destructive" 
                  size="sm" 
                  onClick={() => { setIsDetailOpen(false); handleOpenCancelReservaDialog(detailReserva); }}
                  disabled={isPast(detailReserva.fechaHoraInicio.toDate()) && detailReserva.estado === 'SOLICITADO'}
                >
                  <Icons.XCircle className="mr-1 h-4 w-4" /> Cancelar Reserva
                </Button>
              </div>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Devolución de Garantía Dialog */}
      <Dialog open={isRefundDialogOpen} onOpenChange={(open) => { if (!open && !isRefundUploading) { setIsRefundDialogOpen(false); setReservationForRefund(null); } }}>
        <DialogContent className="max-w-md bg-background rounded-3xl p-0 flex flex-col max-h-[90vh]">
          <DialogHeader className="px-5 pt-5 pb-3 space-y-1 shrink-0">
            <DialogTitle className="text-lg font-headline font-black text-[#2D4F5E] flex items-center gap-2">
              <Icons.HandCoins className="h-5 w-5 text-[#008b8b]" />
              Devolver Garantía
            </DialogTitle>
            <DialogDescription className="text-xs">
              Registra el egreso de la devolución de garantía para este espacio común.
            </DialogDescription>
          </DialogHeader>

          {reservationForRefund && (
            <div className="overflow-y-auto flex-1 px-5 space-y-3 pb-2">
              {/* Info card - compact */}
              <div className="p-3 rounded-xl bg-amber-50/50 border border-amber-200 text-[11px] space-y-1 text-amber-900">
                <div className="flex justify-between"><span className="font-semibold">Residente:</span><span className="truncate ml-2 max-w-[55%] text-right">{reservationForRefund.userDisplayName || reservationForRefund.userEmail}</span></div>
                <div className="flex justify-between"><span className="font-semibold">Dpto / Espacio:</span><span className="font-mono">{reservationForRefund.departamentoId || 'N/A'} · {reservationForRefund.espacioComunNombre}</span></div>
                <div className="flex justify-between border-t border-amber-200 pt-1 text-sm font-black">
                  <span>Garantía:</span>
                  <span className="font-mono text-amber-700">{formatCurrency(reservationForRefund.montoGarantia, reservationForRefund.monedaCosto ?? undefined)}</span>
                </div>
              </div>

              {/* Toggle custom amount */}
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <div>
                  <label className="text-xs font-bold text-[#2D4F5E]">Definir otro monto a devolver</label>
                  <p className="text-[10px] text-muted-foreground">Descontar multa o daños</p>
                </div>
                <input 
                  type="checkbox"
                  checked={defineCustomRefund}
                  onChange={(e) => {
                    setDefineCustomRefund(e.target.checked);
                    if (!e.target.checked) {
                      setCustomRefundAmount((reservationForRefund.montoGarantia || 0).toString());
                      setRefundPenaltyReason('');
                      setRefundEvidenceFile(null);
                      setRefundEvidencePreview(null);
                    }
                  }}
                  className="w-4 h-4 text-[#008b8b] border-gray-300 rounded focus:ring-[#008b8b] cursor-pointer shrink-0"
                />
              </div>

              {defineCustomRefund && (
                <div className="space-y-2 p-3 rounded-xl border border-red-100 bg-red-50/10">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Monto a Devolver</label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="Ej: 100.00"
                      value={customRefundAmount}
                      onChange={(e) => setCustomRefundAmount(e.target.value)}
                      className="h-9 rounded-lg bg-white font-mono font-bold text-[#2D4F5E] text-sm"
                    />
                  </div>
                  {parseFloat(customRefundAmount) < (reservationForRefund.montoGarantia || 0) && (
                    <>
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-red-700">Motivo Multa/Daño (Requerido)</label>
                        <Textarea
                          placeholder="Indique el motivo..."
                          value={refundPenaltyReason}
                          onChange={(e) => setRefundPenaltyReason(e.target.value)}
                          className="rounded-lg border-red-200 focus-visible:ring-red-500 bg-white text-xs min-h-[48px]"
                          rows={1}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-red-700">Evidencia (Requerido)</label>
                        <div className="flex items-center gap-2">
                          <Input 
                            type="file" accept="image/*" 
                            onChange={handleEvidenceFileChange}
                            className="flex-1 rounded-lg border-red-200 bg-white text-xs h-9"
                            disabled={isRefundUploading}
                          />
                          {refundEvidencePreview && (
                            <Button type="button" variant="ghost" size="icon" className="h-8 w-8 shrink-0"
                              onClick={() => { setRefundEvidenceFile(null); setRefundEvidencePreview(null); }} disabled={isRefundUploading}>
                              <Icons.Trash2 className="h-3.5 w-3.5 text-red-500" />
                            </Button>
                          )}
                        </div>
                        {refundEvidencePreview && (
                          <div className="relative h-20 w-full rounded-lg border overflow-hidden bg-muted mt-1">
                            <Image src={refundEvidencePreview} alt="Evidencia" layout="fill" objectFit="contain" />
                          </div>
                        )}
                      </div>
                    </>
                  )}
                </div>
              )}

              {/* Bank account + Op number: 2-col grid */}
              <div className="grid grid-cols-2 gap-2">
                <div className="col-span-2 space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Cuenta Bancaria (Origen)</label>
                  <Select onValueChange={setRefundSourceAccountId} value={refundSourceAccountId}>
                    <SelectTrigger className="h-9 rounded-lg text-xs">
                      <SelectValue placeholder="Selecciona cuenta..." />
                    </SelectTrigger>
                    <SelectContent>
                      {cuentas.map(cta => (
                        <SelectItem key={cta.id} value={cta.id}>
                          {cta.nombre} ({formatCurrency(cta.saldo_actual, cta.moneda)})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1 col-span-2">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Fecha de Devolución</label>
                  <Input 
                    type="date"
                    value={refundGuaranteeDate}
                    onChange={(e) => setRefundGuaranteeDate(e.target.value)}
                    className="h-9 rounded-lg text-xs"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Nro. Operación</label>
                  <Input 
                    placeholder="Ej: 987654321" 
                    value={refundOpNumber}
                    onChange={(e) => setRefundOpNumber(e.target.value)}
                    className="h-9 rounded-lg text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Voucher Reembolso</label>
                  <div className="flex items-center gap-1">
                    <Input 
                      type="file" accept="image/*" 
                      onChange={handleRefundFileChange}
                      className="flex-1 rounded-lg text-xs h-9"
                      disabled={isRefundUploading}
                    />
                    {refundConstanciaPreview && (
                      <Button type="button" variant="ghost" size="icon" className="h-8 w-8 shrink-0"
                        onClick={() => { setRefundConstanciaFile(null); setRefundConstanciaPreview(null); }} disabled={isRefundUploading}>
                        <Icons.Trash2 className="h-3.5 w-3.5 text-red-500" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              {/* Voucher preview - compact */}
              {refundConstanciaPreview && (
                <div className="relative h-20 w-full rounded-lg border overflow-hidden bg-muted">
                  <Image src={refundConstanciaPreview} alt="Preview voucher" layout="fill" objectFit="contain" />
                </div>
              )}

              {/* Notes */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Notas (Opcional)</label>
                <Textarea 
                  placeholder="Observaciones adicionales..." 
                  value={refundNotes}
                  onChange={(e) => setRefundNotes(e.target.value)}
                  rows={1}
                  className="rounded-lg text-xs min-h-[36px]"
                />
              </div>

              {isRefundUploading && refundUploadProgress !== null && (
                <div className="space-y-1">
                  <p className="text-[10px] text-muted-foreground">Subiendo: {refundUploadProgress.toFixed(0)}%</p>
                  <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-[#008b8b] transition-all" style={{ width: `${refundUploadProgress}%` }} />
                  </div>
                </div>
              )}
            </div>
          )}

          <DialogFooter className="gap-2 px-5 py-3 border-t shrink-0">
            <Button 
              variant="outline" 
              onClick={() => { setIsRefundDialogOpen(false); setReservationForRefund(null); }}
              disabled={isRefundUploading}
              className="rounded-xl h-9 text-xs"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleConfirmRefund} 
              disabled={
                isRefundUploading || 
                !refundSourceAccountId || 
                !refundOpNumber.trim() || 
                (defineCustomRefund && isNaN(parseFloat(customRefundAmount))) ||
                (defineCustomRefund && parseFloat(customRefundAmount) < (reservationForRefund?.montoGarantia || 0) && (!refundPenaltyReason.trim() || !refundEvidenceFile))
              }
              className="bg-[#008b8b] hover:bg-[#007b7b] text-white rounded-xl h-9 text-xs font-semibold flex-1"
            >
              {isRefundUploading ? 'Procesando...' : 'Confirmar Devolución'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog Confirmar Cancelación sin Reembolso */}
      <AlertDialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
        <AlertDialogContent className="w-[92vw] rounded-[24px]">
          <AlertDialogHeader>
            <AlertDialogTitle>¿Confirmar cancelación de reserva?</AlertDialogTitle>
            <AlertDialogDescription>
              Se cancelará la reserva de <strong>{reservationForCancel?.espacioComunNombre}</strong> para el <strong>{reservationForCancel && formatDateRange(reservationForCancel.fechaHoraInicio, reservationForCancel.fechaHoraFin)}</strong>. El espacio quedará libre inmediatamente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex flex-col gap-2 pt-2">
            <AlertDialogCancel className="w-full h-12 rounded-xl mt-0" onClick={() => { setIsCancelDialogOpen(false); setReservationForCancel(null); }}>
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction className="w-full h-12 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold" onClick={handleConfirmCancelWithoutRefund}>
              Sí, Cancelar Reserva
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog Cancelación con Reembolso de Pago */}
      <Dialog open={isCancelRefundDialogOpen} onOpenChange={(open) => { if (!open && !isCancelUploading) { setIsCancelRefundDialogOpen(false); setReservationForCancel(null); } }}>
        <DialogContent className="sm:max-w-md rounded-[24px] p-0 overflow-hidden flex flex-col max-h-[85vh]">
          <DialogHeader className="p-4 pb-3 border-b bg-red-50 shrink-0">
            <DialogTitle className="font-headline text-base text-red-900 flex items-center gap-2">
              <Icons.XCircle className="h-5 w-5 text-red-600 shrink-0" />
              Cancelar Reserva con Reembolso
            </DialogTitle>
            <DialogDescription className="text-xs text-red-700">
              Esta reserva cuenta con un pago ya validado. Debes registrar el reembolso correspondiente.
            </DialogDescription>
          </DialogHeader>

          {reservationForCancel && (() => {
            const rentalCost = reservationForCancel.montoAlquiler ?? ((reservationForCancel.costoReserva ?? 0) - (reservationForCancel.montoGarantia || 0));
            const garantiaCost = reservationForCancel.montoGarantia || 0;
            const isGarantiaDevuelta = reservationForCancel.garantia_estado === 'devuelto';
            const expectedRefund = isGarantiaDevuelta ? rentalCost : (reservationForCancel.costoReserva ?? 0);
            const maxRefundLimit = isGarantiaDevuelta ? rentalCost : (rentalCost + garantiaCost);
            const currentRefundAmount = cancelDefineCustomRefund ? parseFloat(cancelCustomRefundAmount) : expectedRefund;

            return (
              <div className="p-4 space-y-4 overflow-y-auto flex-1">
                <div className="bg-slate-50 p-3.5 rounded-xl border space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Residente:</span>
                    <span className="font-semibold text-slate-800">{reservationForCancel.userDisplayName || reservationForCancel.userEmail}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Espacio:</span>
                    <span className="font-semibold text-slate-800">{reservationForCancel.espacioComunNombre}</span>
                  </div>
                  <div className="flex justify-between border-t pt-1.5 mt-1 text-slate-500">
                    <span>Costo de Alquiler:</span>
                    <span className="font-semibold text-slate-800">{formatCurrency(rentalCost, reservationForCancel.monedaCosto ?? undefined)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Costo de Garantía:</span>
                    <span className="font-semibold text-slate-800">{formatCurrency(garantiaCost, reservationForCancel.monedaCosto ?? undefined)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500 pb-1">
                    <span>Estado de Garantía:</span>
                    <Badge variant="outline" className="text-[9px] uppercase font-bold px-1.5 py-0 h-4 flex-shrink-0 bg-white">
                      {garantiaCost > 0 
                        ? (isGarantiaDevuelta 
                            ? `Devuelta (S/ ${reservationForCancel.garantia_devolucion_monto?.toFixed(2) || '0.00'})` 
                            : 'Pendiente de Devolución')
                        : 'No aplica'}
                    </Badge>
                  </div>
                  <div className="flex justify-between border-t border-dashed pt-2 mt-1.5 font-bold text-sm">
                    <span className="text-red-900">Monto a Reembolsar:</span>
                    <span className="text-red-600 font-mono">
                      {formatCurrency(isNaN(currentRefundAmount) ? 0 : currentRefundAmount, reservationForCancel.monedaCosto ?? undefined)}
                    </span>
                  </div>
                </div>

                {/* Toggle custom cancellation refund amount */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div>
                    <label className="text-xs font-bold text-[#2D4F5E]">Definir otro monto a reembolsar</label>
                    <p className="text-[10px] text-muted-foreground">Establecer deducción por daños o penalidad</p>
                  </div>
                  <input 
                    type="checkbox"
                    checked={cancelDefineCustomRefund}
                    onChange={(e) => {
                      setCancelDefineCustomRefund(e.target.checked);
                      if (!e.target.checked) {
                        setCancelCustomRefundAmount(expectedRefund.toString());
                        setCancelPenaltyReason('');
                        setCancelEvidenceFile(null);
                        setCancelEvidencePreview(null);
                      }
                    }}
                    className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500 cursor-pointer shrink-0"
                  />
                </div>

                {cancelDefineCustomRefund && (
                  <div className="space-y-2 p-3 rounded-xl border border-red-100 bg-red-50/10">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Importe del Reembolso</label>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder={`Ej: ${expectedRefund.toFixed(2)}`}
                        value={cancelCustomRefundAmount}
                        onChange={(e) => setCancelCustomRefundAmount(e.target.value)}
                        className="h-9 rounded-lg bg-white font-mono font-bold text-[#2D4F5E] text-sm"
                      />
                      <p className="text-[9px] text-slate-500">Monto máximo permitido: {formatCurrency(maxRefundLimit, reservationForCancel.monedaCosto ?? undefined)}</p>
                    </div>
                    {parseFloat(cancelCustomRefundAmount) < expectedRefund && (
                      <>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-red-700">Motivo del descuento / retención (Requerido)</label>
                          <Textarea
                            placeholder="Ej: Daños detectados en el espacio común..."
                            value={cancelPenaltyReason}
                            onChange={(e) => setCancelPenaltyReason(e.target.value)}
                            className="rounded-lg border-red-200 focus-visible:ring-red-500 bg-white text-xs min-h-[48px]"
                            rows={1}
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold uppercase tracking-wider text-red-700">Evidencia de la penalidad (Requerido)</label>
                          <div className="flex items-center gap-2">
                            <Input 
                              type="file" accept="image/*" 
                              onChange={handleCancelEvidenceFileChange}
                              className="flex-1 rounded-lg border-red-200 bg-white text-xs h-9"
                              disabled={isCancelUploading}
                            />
                            {cancelEvidencePreview && (
                              <Button type="button" variant="ghost" size="icon" className="h-8 w-8 shrink-0"
                                onClick={() => { setCancelEvidenceFile(null); setCancelEvidencePreview(null); }} disabled={isCancelUploading}>
                                <Icons.Trash2 className="h-3.5 w-3.5 text-red-500" />
                              </Button>
                            )}
                          </div>
                          {cancelEvidencePreview && (
                            <div className="relative h-20 w-full rounded-lg border overflow-hidden bg-muted mt-1">
                              <Image src={cancelEvidencePreview} alt="Evidencia penalidad" layout="fill" objectFit="contain" />
                            </div>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2 space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Cuenta de Salida (Origen)</label>
                    <Select onValueChange={setCancelSourceAccountId} value={cancelSourceAccountId}>
                      <SelectTrigger className="h-9 rounded-lg text-xs">
                        <SelectValue placeholder="Selecciona cuenta..." />
                      </SelectTrigger>
                      <SelectContent>
                        {cuentas.map(cta => (
                          <SelectItem key={cta.id} value={cta.id}>
                            {cta.nombre} ({formatCurrency(cta.saldo_actual, cta.moneda)})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-1 col-span-2">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Fecha de Ejecución del Reembolso</label>
                    <Input 
                      type="date"
                      value={cancelRefundDate}
                      onChange={(e) => setCancelRefundDate(e.target.value)}
                      className="h-9 rounded-lg text-xs"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Nro. Operación</label>
                    <Input 
                      placeholder="Ej: 123456" 
                      value={cancelOpNumber}
                      onChange={(e) => setCancelOpNumber(e.target.value)}
                      className="h-9 rounded-lg text-xs"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Constancia Reembolso</label>
                    <div className="flex items-center gap-1">
                      <Input 
                        type="file" accept="image/*" 
                        onChange={handleCancelFileChange}
                        className="flex-1 rounded-lg text-xs h-9"
                        disabled={isCancelUploading}
                      />
                      {cancelConstanciaPreview && (
                        <Button type="button" variant="ghost" size="icon" className="h-8 w-8 shrink-0"
                          onClick={() => { setCancelConstanciaFile(null); setCancelConstanciaPreview(null); }} disabled={isCancelUploading}>
                          <Icons.Trash2 className="h-3.5 w-3.5 text-red-500" />
                        </Button>
                      )}
                    </div>
                  </div>

                  {cancelConstanciaPreview && (
                    <div className="col-span-2 relative h-20 w-full rounded-lg border overflow-hidden bg-muted">
                      <Image src={cancelConstanciaPreview} alt="Preview voucher" layout="fill" objectFit="contain" />
                    </div>
                  )}

                  <div className="col-span-2 space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Notas de Devolución</label>
                    <Textarea 
                      placeholder="Observaciones..." 
                      value={cancelNotes}
                      onChange={(e) => setCancelNotes(e.target.value)}
                      rows={1}
                      className="rounded-lg text-xs min-h-[36px]"
                    />
                  </div>

                  {isCancelUploading && cancelUploadProgress !== null && (
                    <div className="col-span-2 space-y-1">
                      <p className="text-[10px] text-muted-foreground">Subiendo: {cancelUploadProgress.toFixed(0)}%</p>
                      <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-red-600 transition-all" style={{ width: `${cancelUploadProgress}%` }} />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })()}

          <DialogFooter className="gap-2 px-5 py-3 border-t shrink-0">
            <Button 
              variant="outline" 
              onClick={() => { setIsCancelRefundDialogOpen(false); setReservationForCancel(null); }}
              disabled={isCancelUploading}
              className="rounded-xl h-9 text-xs"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleConfirmCancelWithRefund} 
              disabled={
                isCancelUploading || 
                !cancelSourceAccountId || 
                !cancelOpNumber.trim() || 
                (cancelDefineCustomRefund && isNaN(parseFloat(cancelCustomRefundAmount))) ||
                (reservationForCancel ? (() => {
                  const rentalCost = reservationForCancel.montoAlquiler ?? ((reservationForCancel.costoReserva ?? 0) - (reservationForCancel.montoGarantia || 0));
                  const garantiaCost = reservationForCancel.montoGarantia || 0;
                  const isGarantiaDevuelta = reservationForCancel.garantia_estado === 'devuelto';
                  const expectedRefund = isGarantiaDevuelta ? rentalCost : (reservationForCancel.costoReserva ?? 0);
                  const maxRefundLimit = isGarantiaDevuelta ? rentalCost : (rentalCost + garantiaCost);
                  const val = parseFloat(cancelCustomRefundAmount);
                  return (
                    cancelDefineCustomRefund && (
                      val > maxRefundLimit ||
                      (val < expectedRefund && (!cancelPenaltyReason.trim() || !cancelEvidenceFile))
                    )
                  );
                })() : false)
              }
              className="bg-red-600 hover:bg-red-700 text-white rounded-xl h-9 text-xs font-semibold flex-1"
            >
              {isCancelUploading ? 'Procesando...' : 'Confirmar Reembolso y Cancelar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog Cancelación con Validación Pendiente (Resident Voucher check) */}
      <Dialog open={isCancelPendingValidationDialogOpen} onOpenChange={(open) => { if (!open && !isCancelUploading) { setIsCancelPendingValidationDialogOpen(false); setReservationForCancel(null); } }}>
        <DialogContent className="sm:max-w-md rounded-[24px] p-0 overflow-hidden flex flex-col max-h-[85vh]">
          <DialogHeader className="p-4 pb-3 border-b bg-amber-50 shrink-0">
            <DialogTitle className="font-headline text-base text-amber-900 flex items-center gap-2">
              <Icons.AlertTriangle className="h-5 w-5 text-amber-600 shrink-0" />
              Cancelar Reserva (Validación Pendiente)
            </DialogTitle>
            <DialogDescription className="text-xs text-amber-700">
              Esta reserva tiene un comprobante cargado por el residente pero su validación está pendiente.
            </DialogDescription>
          </DialogHeader>

          {reservationForCancel && (() => {
            const rentalCost = reservationForCancel.montoAlquiler ?? ((reservationForCancel.costoReserva ?? 0) - (reservationForCancel.montoGarantia || 0));
            const garantiaCost = reservationForCancel.montoGarantia || 0;
            const isGarantiaDevuelta = reservationForCancel.garantia_estado === 'devuelto';
            const expectedRefund = isGarantiaDevuelta ? rentalCost : (reservationForCancel.costoReserva ?? 0);
            const maxRefundLimit = isGarantiaDevuelta ? rentalCost : (rentalCost + garantiaCost);
            const currentRefundAmount = cancelDefineCustomRefund ? parseFloat(cancelCustomRefundAmount) : expectedRefund;

            return (
              <div className="p-4 space-y-4 overflow-y-auto flex-1">
                {/* Resident cost breakdown */}
                <div className="bg-slate-50 p-3.5 rounded-xl border space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Residente:</span>
                    <span className="font-semibold text-slate-800">{reservationForCancel.userDisplayName || reservationForCancel.userEmail}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Espacio:</span>
                    <span className="font-semibold text-slate-800">{reservationForCancel.espacioComunNombre}</span>
                  </div>
                  <div className="flex justify-between border-t pt-1.5 mt-1 text-slate-500">
                    <span>Costo de Alquiler:</span>
                    <span className="font-semibold text-slate-800">{formatCurrency(rentalCost, reservationForCancel.monedaCosto ?? undefined)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Costo de Garantía:</span>
                    <span className="font-semibold text-slate-800">{formatCurrency(garantiaCost, reservationForCancel.monedaCosto ?? undefined)}</span>
                  </div>
                  <div className="flex justify-between border-t border-dashed pt-2 mt-1 font-bold text-sm">
                    <span className="text-slate-800">Total Transferido por Residente:</span>
                    <span className="text-primary font-mono">{formatCurrency(reservationForCancel.costoReserva, reservationForCancel.monedaCosto ?? undefined)}</span>
                  </div>
                </div>

                {/* Resident's payment voucher check */}
                <div className="p-3 rounded-xl border border-slate-200 bg-[#f0f9fa]/50 space-y-2">
                  <span className="text-[11px] font-black uppercase text-[#0a9396] tracking-wider block">
                    Comprobante Cargado por Residente
                  </span>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Nro. Operación original:</span>
                    <span className="font-mono font-bold text-slate-800">{reservationForCancel.pagoNroOperacion || 'N/A'}</span>
                  </div>
                  {reservationForCancel.pagoConstanciaUrl && (
                    <div className="relative h-40 w-full rounded-lg border overflow-hidden bg-muted mt-1">
                      <Image 
                        src={reservationForCancel.pagoConstanciaUrl} 
                        alt="Voucher de pago del residente" 
                        layout="fill" 
                        objectFit="contain" 
                      />
                    </div>
                  )}
                </div>

                {/* Question: Will refund? */}
                <div className="space-y-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#2D4F5E] block">
                    ¿Deseas realizar el reembolso de este dinero?
                  </span>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setCancelPendingWillRefund(true)}
                      className={cn(
                        "h-12 rounded-xl border-2 font-bold text-sm transition-all flex flex-col items-center justify-center gap-0.5",
                        cancelPendingWillRefund === true 
                          ? "border-[#008b8b] bg-[#f0fcfc] text-[#008b8b] shadow-sm shadow-[#008b8b]/10" 
                          : "border-slate-200 hover:border-slate-300 text-slate-600 hover:bg-slate-50"
                      )}
                    >
                      <span>Sí, Devolver Dinero</span>
                      <span className="text-[10px] font-normal text-muted-foreground">Genera Ingreso + Egreso</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCancelPendingWillRefund(false);
                        setCancelSourceAccountId('');
                        setCancelOpNumber('');
                        setCancelConstanciaFile(null);
                        setCancelConstanciaPreview(null);
                        setCancelNotes('');
                      }}
                      className={cn(
                        "h-12 rounded-xl border-2 font-bold text-sm transition-all flex flex-col items-center justify-center gap-0.5",
                        cancelPendingWillRefund === false 
                          ? "border-red-500 bg-red-50/20 text-red-600 shadow-sm shadow-red-500/10" 
                          : "border-slate-200 hover:border-slate-300 text-slate-600 hover:bg-slate-50"
                      )}
                    >
                      <span>No Reembolsar</span>
                      <span className="text-[10px] font-normal text-muted-foreground">Rechazar pago y solicitud</span>
                    </button>
                  </div>
                </div>

                {/* Conditional Refund Form */}
                {cancelPendingWillRefund === true && (
                  <div className="space-y-3 pt-1 animate-in fade-in duration-200">
                    <hr />
                    
                    {/* Expected & Limit Info */}
                    <div className="text-[11px] text-[#008b8b] bg-[#f0fcfc] border border-[#d2f0f4] p-3.5 rounded-xl space-y-1 leading-normal">
                      <p className="font-bold">Información de Reembolso:</p>
                      <p>&bull; Al elegir Devolver se validará el voucher original como un **Ingreso** contable en tu cuenta y se generará una **Salida (Reembolso)**.</p>
                      <p>&bull; Monto esperado original a reembolsar: **{formatCurrency(expectedRefund, reservationForCancel.monedaCosto ?? undefined)}**.</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      {/* SECTION 1: INGRESO (PAGO ORIGINAL) */}
                      <div className="col-span-2 border-t pt-3 mt-1">
                        <span className="text-[10px] font-black uppercase tracking-wider text-[#0a9396] block mb-2">
                          1. Depósito del Residente (Ingreso a validar)
                        </span>
                      </div>

                      <div className="col-span-2 space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Cuenta de Destino (Ingreso)</label>
                        <Select onValueChange={setCancelIngresoAccountId} value={cancelIngresoAccountId}>
                          <SelectTrigger className="h-9 rounded-lg text-xs">
                            <SelectValue placeholder="Selecciona cuenta..." />
                          </SelectTrigger>
                          <SelectContent>
                            {cuentas.map(cta => (
                              <SelectItem key={cta.id} value={cta.id}>
                                {cta.nombre} ({formatCurrency(cta.saldo_actual, cta.moneda)})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Nro. Operación original</label>
                        <Input
                          placeholder="Ej: 987654"
                          value={cancelIngresoOpNumber}
                          onChange={(e) => setCancelIngresoOpNumber(e.target.value)}
                          className="h-9 rounded-lg text-xs"
                          required
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Fecha de Pago</label>
                        <Input
                          type="date"
                          value={cancelIngresoPaymentDate}
                          onChange={(e) => setCancelIngresoPaymentDate(e.target.value)}
                          className="h-9 rounded-lg text-xs"
                          required
                        />
                      </div>

                      {/* SECTION 2: EGRESO (REEMBOLSO) */}
                      <div className="col-span-2 border-t pt-3 mt-2">
                        <span className="text-[10px] font-black uppercase tracking-wider text-rose-600 block mb-2">
                          2. Reembolso (Egreso a realizar)
                        </span>
                      </div>

                      {/* Toggle custom refund amount — inside Section 2 since it only affects egreso */}
                      <div className="col-span-2 flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                        <div>
                          <label className="text-xs font-bold text-[#2D4F5E]">Definir otro monto a reembolsar</label>
                          <p className="text-[10px] text-muted-foreground">Establecer deducción por daños o penalidad</p>
                        </div>
                        <input
                          type="checkbox"
                          checked={cancelDefineCustomRefund}
                          onChange={(e) => {
                            setCancelDefineCustomRefund(e.target.checked);
                            if (!e.target.checked) {
                              setCancelCustomRefundAmount(expectedRefund.toString());
                              setCancelPenaltyReason('');
                              setCancelEvidenceFile(null);
                              setCancelEvidencePreview(null);
                            }
                          }}
                          className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500 cursor-pointer shrink-0"
                        />
                      </div>

                      {cancelDefineCustomRefund && (
                        <div className="col-span-2 space-y-2 p-3 rounded-xl border border-red-100 bg-red-50/10">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Importe del Reembolso</label>
                            <Input
                              type="number"
                              step="0.01"
                              placeholder={`Ej: ${expectedRefund.toFixed(2)}`}
                              value={cancelCustomRefundAmount}
                              onChange={(e) => setCancelCustomRefundAmount(e.target.value)}
                              className="h-9 rounded-lg bg-white font-mono font-bold text-[#2D4F5E] text-sm"
                            />
                            <p className="text-[9px] text-slate-500">Monto máximo permitido: {formatCurrency(maxRefundLimit, reservationForCancel.monedaCosto ?? undefined)}</p>
                          </div>
                          {parseFloat(cancelCustomRefundAmount) < expectedRefund && (
                            <>
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase tracking-wider text-red-700">Motivo del descuento / retención (Requerido)</label>
                                <Textarea
                                  placeholder="Ej: Daños detectados en el espacio común..."
                                  value={cancelPenaltyReason}
                                  onChange={(e) => setCancelPenaltyReason(e.target.value)}
                                  className="rounded-lg border-red-200 focus-visible:ring-red-500 bg-white text-xs min-h-[48px]"
                                  rows={1}
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase tracking-wider text-red-700">Evidencia de la penalidad (Requerido)</label>
                                <div className="flex items-center gap-2">
                                  <Input
                                    type="file" accept="image/*"
                                    onChange={handleCancelEvidenceFileChange}
                                    className="flex-1 rounded-lg border-red-200 bg-white text-xs h-9"
                                    disabled={isCancelUploading}
                                  />
                                  {cancelEvidencePreview && (
                                    <Button type="button" variant="ghost" size="icon" className="h-8 w-8 shrink-0"
                                      onClick={() => { setCancelEvidenceFile(null); setCancelEvidencePreview(null); }} disabled={isCancelUploading}>
                                      <Icons.Trash2 className="h-3.5 w-3.5 text-red-500" />
                                    </Button>
                                  )}
                                </div>
                                {cancelEvidencePreview && (
                                  <div className="relative h-20 w-full rounded-lg border overflow-hidden bg-muted mt-1">
                                    <Image src={cancelEvidencePreview} alt="Evidencia penalidad" layout="fill" objectFit="contain" />
                                  </div>
                                )}
                              </div>
                            </>
                          )}
                        </div>
                      )}

                      <div className="col-span-2 space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Cuenta de Salida (Origen)</label>
                        <Select onValueChange={setCancelSourceAccountId} value={cancelSourceAccountId}>
                          <SelectTrigger className="h-9 rounded-lg text-xs">
                            <SelectValue placeholder="Selecciona cuenta..." />
                          </SelectTrigger>
                          <SelectContent>
                            {cuentas.map(cta => (
                              <SelectItem key={cta.id} value={cta.id}>
                                {cta.nombre} ({formatCurrency(cta.saldo_actual, cta.moneda)})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Fecha del Reembolso</label>
                        <Input
                          type="date"
                          value={cancelRefundDate}
                          onChange={(e) => setCancelRefundDate(e.target.value)}
                          className="h-9 rounded-lg text-xs"
                          required
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Nro. Operación de Reembolso</label>
                        <Input
                          placeholder="Ej: 123456"
                          value={cancelOpNumber}
                          onChange={(e) => setCancelOpNumber(e.target.value)}
                          className="h-9 rounded-lg text-xs"
                        />
                      </div>

                      <div className="col-span-2 space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Constancia Reembolso</label>
                        <div className="flex items-center gap-1">
                          <Input 
                            type="file" accept="image/*" 
                            onChange={handleCancelFileChange}
                            className="flex-1 rounded-lg text-xs h-9"
                            disabled={isCancelUploading}
                          />
                          {cancelConstanciaPreview && (
                            <Button type="button" variant="ghost" size="icon" className="h-8 w-8 shrink-0"
                              onClick={() => { setCancelConstanciaFile(null); setCancelConstanciaPreview(null); }} disabled={isCancelUploading}>
                              <Icons.Trash2 className="h-3.5 w-3.5 text-red-500" />
                            </Button>
                          )}
                        </div>
                      </div>

                      {cancelConstanciaPreview && (
                        <div className="col-span-2 relative h-20 w-full rounded-lg border overflow-hidden bg-muted">
                          <Image src={cancelConstanciaPreview} alt="Preview voucher" layout="fill" objectFit="contain" />
                        </div>
                      )}

                      <div className="col-span-2 space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-wider text-[#2D4F5E]">Notas de Devolución</label>
                        <Textarea 
                          placeholder="Observaciones..." 
                          value={cancelNotes}
                          onChange={(e) => setCancelNotes(e.target.value)}
                          rows={1}
                          className="rounded-lg text-xs min-h-[36px]"
                        />
                      </div>

                      {isCancelUploading && cancelUploadProgress !== null && (
                        <div className="col-span-2 space-y-1">
                          <p className="text-[10px] text-muted-foreground">Subiendo: {cancelUploadProgress.toFixed(0)}%</p>
                          <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-red-600 transition-all" style={{ width: `${cancelUploadProgress}%` }} />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Conditional Reject Warn info */}
                {cancelPendingWillRefund === false && (
                  <div className="text-xs text-red-700 bg-red-50/50 border border-red-200 p-3.5 rounded-xl space-y-1 leading-normal animate-in fade-in duration-200">
                    <p className="font-bold flex items-center gap-1.5">
                      <Icons.AlertTriangle className="h-4 w-4 shrink-0 text-red-600" />
                      Advertencia de Rechazo:
                    </p>
                    <p>&bull; Al seleccionar "No Reembolsar", el comprobante cargado por el residente se marcará como **Rechazado**.</p>
                    <p>&bull; La reserva se anulará permanentemente y el espacio quedará libre.</p>
                    <p>&bull; **No se registrará ningún ingreso ni egreso contable** en las cuentas financieras del condominio.</p>
                  </div>
                )}
              </div>
            );
          })()}

          <DialogFooter className="gap-2 px-5 py-3 border-t shrink-0">
            <Button 
              variant="outline" 
              onClick={() => { setIsCancelPendingValidationDialogOpen(false); setReservationForCancel(null); }}
              disabled={isCancelUploading}
              className="rounded-xl h-9 text-xs"
            >
              Cancelar
            </Button>
            
            {cancelPendingWillRefund === true ? (
              <Button 
                onClick={handleConfirmCancelPendingRefund} 
                disabled={
                  isCancelUploading || 
                  !cancelIngresoAccountId ||
                  !cancelIngresoOpNumber.trim() ||
                  !cancelIngresoPaymentDate ||
                  !cancelRefundDate ||
                  !cancelSourceAccountId || 
                  !cancelOpNumber.trim() || 
                  (cancelDefineCustomRefund && isNaN(parseFloat(cancelCustomRefundAmount))) ||
                  (reservationForCancel ? (() => {
                    const rentalCost = reservationForCancel.montoAlquiler ?? ((reservationForCancel.costoReserva ?? 0) - (reservationForCancel.montoGarantia || 0));
                    const garantiaCost = reservationForCancel.montoGarantia || 0;
                    const isGarantiaDevuelta = reservationForCancel.garantia_estado === 'devuelto';
                    const expectedRefund = isGarantiaDevuelta ? rentalCost : (reservationForCancel.costoReserva ?? 0);
                    const maxRefundLimit = isGarantiaDevuelta ? rentalCost : (rentalCost + garantiaCost);
                    const val = parseFloat(cancelCustomRefundAmount);
                    return (
                      cancelDefineCustomRefund && (
                        val > maxRefundLimit ||
                        (val < expectedRefund && (!cancelPenaltyReason.trim() || !cancelEvidenceFile))
                      )
                    );
                  })() : false)
                }
                className="bg-red-600 hover:bg-red-700 text-white rounded-xl h-9 text-xs font-semibold flex-1"
              >
                {isCancelUploading ? 'Procesando...' : 'Confirmar Reembolso y Anular'}
              </Button>
            ) : (
              <Button 
                onClick={handleConfirmCancelPendingReject} 
                disabled={isCancelUploading || cancelPendingWillRefund !== false}
                className="bg-red-600 hover:bg-red-700 text-white rounded-xl h-9 text-xs font-semibold flex-1"
              >
                {isCancelUploading ? 'Procesando...' : 'Rechazar Pago y Anular'}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
