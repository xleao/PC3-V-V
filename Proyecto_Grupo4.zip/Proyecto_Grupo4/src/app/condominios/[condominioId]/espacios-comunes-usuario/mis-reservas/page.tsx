"use client";

import * as React from 'react';
const { useState, useEffect, useCallback, useMemo } = React;
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { AppShell } from '@/components/layout/app-shell';
import { PageTitle } from '@/components/shared/page-title';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Icons } from '@/components/icons';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/hooks/use-language';
import { useAuth } from '@/contexts/auth-context';
import { useCondominioContext } from '@/contexts/condominio-context';
import { useIsMobile } from '@/hooks/use-mobile';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { buttonVariants } from "@/components/ui/button";
import type { ReservaEspacioComun, EspacioComun, CondoUser } from '@/types';
import { db, storage } from '@/lib/firebase';
import { ref as storageRef, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { compressImage } from '@/lib/image-compress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import {
  collectionGroup,
  query,
  where,
  orderBy,
  onSnapshot,
  doc,
  getDoc,
  updateDoc,
  serverTimestamp,
  Timestamp,
} from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { MiReservaCard } from '@/components/condominios/espacios-comunes-usuario/mi-reserva-card';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  format,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameDay,
  addWeeks,
  subWeeks,
  isToday,
  startOfDay,
  endOfDay,
  isAfter,
  addDays
} from 'date-fns';
import { es as esLocale, enUS as enLocale } from 'date-fns/locale';
import {
  cn
} from '@/lib/utils';
import {
  startOfMonth,
  endOfMonth,
  parseISO,
  isValid
} from 'date-fns';

export default function MyReservationsPage() {
  const { t, language } = useLanguage();
  const params = useParams();
  const { user: authUser, authLoading } = useAuth();
  const { selectedCondominio, isLoading: condoContextLoading } = useCondominioContext();
  const { toast } = useToast();
  const router = useRouter();

  const condominioId = params.condominioId as string;
  const searchParams = useSearchParams();
  const isMobile = useIsMobile();

  const [viewMode, setViewMode] = useState<'weekly' | 'monthly'>('weekly');
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [currentWeekStart, setCurrentWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);
  const [reservations, setReservations] = useState<ReservaEspacioComun[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [userDepartments, setUserDepartments] = useState<string[] | null>(null);
  const [isLoadingUserDepts, setIsLoadingUserDepts] = useState(true);

  const [reservationToCancel, setReservationToCancel] = useState<ReservaEspacioComun | null>(null);
  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);
  const [selectedMobileReserva, setSelectedMobileReserva] = useState<ReservaEspacioComun | null>(null);
  const [espaciosComunesMap, setEspaciosComunesMap] = useState<Record<string, { dias_anticipacion_cancelacion: number, requiere_aprobacion: boolean }>>({});
  // Pending payment filters
  const [filterPendingPayment, setFilterPendingPayment] = useState(false);
  const [filterPendingValidation, setFilterPendingValidation] = useState(false);
  // Payment voucher upload
  const [voucherReserva, setVoucherReserva] = useState<ReservaEspacioComun | null>(null);
  const [voucherFile, setVoucherFile] = useState<File | null>(null);
  const [voucherPreview, setVoucherPreview] = useState<string | null>(null);
  const [voucherNroOperacion, setVoucherNroOperacion] = useState('');
  const [voucherFechaPago, setVoucherFechaPago] = useState('');
  const [voucherUploadProgress, setVoucherUploadProgress] = useState<number | null>(null);
  const [isUploadingVoucher, setIsUploadingVoucher] = useState(false);

  // Initial Date param handling
  useEffect(() => {
    const dateStr = searchParams.get('date');
    if (dateStr) {
      const parsed = parseISO(dateStr);
      if (isValid(parsed)) {
        setSelectedDay(parsed);
        const newWeekStart = startOfWeek(parsed, { weekStartsOn: 1 });
        setCurrentWeekStart(newWeekStart);
        setCurrentMonth(parsed);
      }
    }
  }, [searchParams]);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.innerWidth < 768) {
      setViewMode('weekly');
    }
  }, []);

  // Fetch user's assigned departments in this condo
  useEffect(() => {
    if (authLoading || condoContextLoading) return;
    if (!authUser || !condominioId) {
      setUserDepartments([]);
      setIsLoadingUserDepts(false);
      return;
    }

    let active = true;
    const fetchUserDepts = async () => {
      setIsLoadingUserDepts(true);
      try {
        if (authUser.email) {
          const normalizedEmail = authUser.email.toLowerCase().trim();
          const docRef = doc(db, 'condominios', condominioId, 'usuarios', normalizedEmail);
          const docSnap = await getDoc(docRef);
          if (active) {
            if (docSnap.exists()) {
              const data = docSnap.data() as CondoUser;
              setUserDepartments(data.departamentos_asignados || []);
            } else {
              setUserDepartments([]);
            }
          }
        } else {
          if (active) setUserDepartments([]);
        }
      } catch (err) {
        console.error("Error fetching user departments in mis-reservas:", err);
        if (active) setUserDepartments([]);
      } finally {
        if (active) setIsLoadingUserDepts(false);
      }
    };

    fetchUserDepts();
    return () => {
      active = false;
    };
  }, [authUser, authLoading, condominioId, condoContextLoading]);

  const formatDateRange = useCallback((start: Timestamp, end: Timestamp) => {
    const locale = language === 'es' ? esLocale : enLocale;
    const startDate = start.toDate();
    const endDate = end.toDate();
    return `${format(startDate, 'PPP p', { locale })} - ${format(endDate, 'p', { locale })}`;
  }, [language]);

  const weekDays = useMemo(() => {
    return eachDayOfInterval({
      start: currentWeekStart,
      end: endOfWeek(currentWeekStart, { weekStartsOn: 1 })
    });
  }, [currentWeekStart]);

  const fetchReservations = useCallback(() => {
    if (authLoading || condoContextLoading || !authUser || !condominioId || isLoadingUserDepts || userDepartments === null) {
      setIsLoadingData(true);
      return () => { };
    }

    if (userDepartments.length === 0) {
      setReservations([]);
      setIsLoadingData(false);
      return () => { };
    }

    setIsLoadingData(true);
    setError(null);

    let rangeStart: Date;
    let rangeEnd: Date;

    if (viewMode === 'weekly') {
      rangeStart = startOfDay(currentWeekStart);
      rangeEnd = endOfDay(endOfWeek(currentWeekStart, { weekStartsOn: 1 }));
    } else {
      // Fetch full calendar grid (including overflow days from prev/next month)
      rangeStart = startOfDay(startOfWeek(startOfMonth(currentMonth), { weekStartsOn: 1 }));
      rangeEnd = endOfDay(endOfWeek(endOfMonth(currentMonth), { weekStartsOn: 1 }));
    }

    const q = query(
      collectionGroup(db, 'reservas'),
      where('condominioId', '==', condominioId),
      where('departamentoId', 'in', userDepartments),
      where('fechaHoraInicio', '>=', Timestamp.fromDate(rangeStart)),
      where('fechaHoraInicio', '<=', Timestamp.fromDate(rangeEnd)),
      orderBy('fechaHoraInicio', 'asc')
    );

    const unsubscribe = onSnapshot(
      q,
      async (snapshot) => {
        const fetchedReservations = snapshot.docs.map(docSnap => ({
          id: docSnap.id,
          ...docSnap.data(),
        } as ReservaEspacioComun));
        setReservations(fetchedReservations);
        setIsLoadingData(false);

        // Fetch unique common areas to get live cancellation config
        const uniqueIds = [...new Set(fetchedReservations.map(r => r.espacioComunId))];
        const entries = await Promise.all(
          uniqueIds.map(async (id) => {
            try {
              const snap = await getDoc(doc(db, 'condominios', condominioId, 'espacios_comunes', id));
              if (snap.exists()) {
                const data = snap.data() as EspacioComun;
                return [id, {
                  dias_anticipacion_cancelacion: data.dias_anticipacion_cancelacion ?? 5,
                  requiere_aprobacion: data.requiere_aprobacion !== false
                }] as [string, { dias_anticipacion_cancelacion: number, requiere_aprobacion: boolean }];
              }
            } catch { /* ignore */ }
            return [id, { dias_anticipacion_cancelacion: 5, requiere_aprobacion: true }] as [string, { dias_anticipacion_cancelacion: number, requiere_aprobacion: boolean }];
          })
        );
        setEspaciosComunesMap(Object.fromEntries(entries));
      },
      (err) => {
        console.error("Error fetching user reservations: ", err);
        setError(t('errorOccurred'));
        toast({ title: t('errorOccurred'), description: "Failed to load your reservations.", variant: "destructive" });
        setIsLoadingData(false);
      }
    );
    return unsubscribe;
  }, [condominioId, authUser, authLoading, condoContextLoading, t, toast, currentWeekStart, currentMonth, viewMode, isLoadingUserDepts, userDepartments]);

  useEffect(() => {
    const unsubscribe = fetchReservations();
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [fetchReservations]);

  const handleOpenCancelDialog = (reserva: ReservaEspacioComun) => {
    setReservationToCancel(reserva);
    setIsCancelConfirmOpen(true);
  };

  const handleConfirmCancelReservation = async () => {
    if (!reservationToCancel || !authUser) {
      toast({ title: t('errorOccurred'), variant: "destructive" });
      return;
    }

    const hasVoucher = !!(reservationToCancel.pagoNroOperacion || reservationToCancel.pagoConstanciaUrl);
    if (hasVoucher) {
      toast({
        title: language === 'es' ? "Cancelación no permitida" : "Cancellation not allowed",
        description: language === 'es'
          ? "No puedes cancelar una reserva con pago registrado desde aquí. Contacta al administrador."
          : "You cannot cancel a reservation with a registered payment from here. Contact the administrator.",
        variant: "destructive"
      });
      return;
    }

    const reservaRef = doc(db, 'condominios', condominioId, 'espacios_comunes', reservationToCancel.espacioComunId, 'reservas', reservationToCancel.id!);

    try {
      await updateDoc(reservaRef, {
        estado: 'CANCELADO_USUARIO',
        fechaCancelacionUsuario: serverTimestamp(),
        usuarioCancelacion: authUser.uid,
        fechaModificacion: serverTimestamp(),
        usuarioModificacion: authUser.uid,
        ...(reservationToCancel.montoGarantia && reservationToCancel.montoGarantia > 0 ? { garantia_estado: 'cancelado' } : {}),
        // Clear pending payment status when user cancels (user can only cancel when no voucher is uploaded)
        ...(reservationToCancel.pago_diferido && reservationToCancel.pago_estado_validacion === 'pendiente'
          && !reservationToCancel.pagoNroOperacion && !reservationToCancel.pagoConstanciaUrl
          ? { pago_estado_validacion: 'cancelado' }
          : {})
      });
      toast({ title: t('reservationCancelledSuccess') });
      setSelectedMobileReserva(null);
    } catch (err: any) {
      console.error("Error cancelling reservation:", err);
      toast({ title: t('errorCancellingReservation'), description: err.message, variant: "destructive" });
    } finally {
      setIsCancelConfirmOpen(false);
      setReservationToCancel(null);
    }
  };

  const getReservationsForDay = (day: Date) => {
    return reservations.filter(res => isSameDay(res.fechaHoraInicio.toDate(), day));
  };

  const filteredReservations = useMemo(() => {
    let result = reservations;
    if (selectedDay) result = result.filter(res => isSameDay(res.fechaHoraInicio.toDate(), selectedDay));

    // If both are active, show both types. If only one, show that one.
    if (filterPendingPayment || filterPendingValidation) {
      result = result.filter(res => {
        const hasVoucher = !!(res.pagoNroOperacion || res.pagoConstanciaUrl);
        const isPendingPayment = res.pago_diferido && res.pago_estado_validacion === 'pendiente' && !hasVoucher;
        const isPendingValidation = res.pago_diferido && res.pago_estado_validacion === 'pendiente' && hasVoucher;

        if (filterPendingPayment && filterPendingValidation) return isPendingPayment || isPendingValidation;
        if (filterPendingPayment) return isPendingPayment;
        if (filterPendingValidation) return isPendingValidation;
        return false;
      });
    }

    return result;
  }, [reservations, selectedDay, filterPendingPayment, filterPendingValidation]);

  const pendingCounts = useMemo(() => {
    let pending = 0;
    let validating = 0;
    reservations.forEach(r => {
      if (r.pago_diferido && r.pago_estado_validacion === 'pendiente') {
        if (r.pagoNroOperacion || r.pagoConstanciaUrl) validating++;
        else pending++;
      }
    });
    return { pending, validating };
  }, [reservations]);

  const handleOpenVoucherUpload = (reserva: ReservaEspacioComun) => {
    setVoucherReserva(reserva);
    setVoucherFile(null);
    setVoucherPreview(null);
    setVoucherNroOperacion(reserva.pagoNroOperacion || '');
    setVoucherUploadProgress(null);
    
    // Prefill date with pago_fecha_efectiva if present, otherwise today's date
    const payDateVal = (reserva as any).pago_fecha_efectiva 
      ? ((reserva as any).pago_fecha_efectiva instanceof Timestamp 
          ? (reserva as any).pago_fecha_efectiva.toDate() 
          : new Date((reserva as any).pago_fecha_efectiva)) 
      : new Date();
    setVoucherFechaPago(isNaN(payDateVal.getTime()) ? new Date().toISOString().split('T')[0] : payDateVal.toISOString().split('T')[0]);
  };

  const handleVoucherFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVoucherFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setVoucherPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitVoucher = async () => {
    if (!voucherReserva || !authUser) return;
    if (!voucherFile && !voucherNroOperacion.trim()) {
      toast({ title: language === 'es' ? 'Ingresa el número de operación o adjunta el comprobante' : 'Enter operation number or attach receipt', variant: 'destructive' });
      return;
    }
    setIsUploadingVoucher(true);
    let constanciaUrl = voucherReserva.pagoConstanciaUrl || '';
    try {
      if (voucherFile) {
        const optimizedFile = await compressImage(voucherFile);
        const path = `condominio_reservas_pagos/${condominioId}/${voucherReserva.espacioComunId}/${Date.now()}_${optimizedFile.name}`;
        const ref = storageRef(storage, path);
        const task = uploadBytesResumable(ref, optimizedFile);
        await new Promise<void>((resolve, reject) => {
          task.on('state_changed',
            snap => setVoucherUploadProgress((snap.bytesTransferred / snap.totalBytes) * 100),
            err => { toast({ title: 'Error al subir archivo', description: err.message, variant: 'destructive' }); reject(err); },
            async () => { constanciaUrl = await getDownloadURL(task.snapshot.ref); resolve(); }
          );
        });
      }
      const reservaRef = doc(db, 'condominios', condominioId, 'espacios_comunes', voucherReserva.espacioComunId, 'reservas', voucherReserva.id!);
      
      let payDateVal = serverTimestamp();
      if (voucherFechaPago) {
        const parts = voucherFechaPago.split('-');
        const payDate = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]), 12, 0, 0);
        payDateVal = Timestamp.fromDate(payDate) as any;
      }

      await updateDoc(reservaRef, {
        pagoNroOperacion: voucherNroOperacion.trim() || null,
        pagoConstanciaUrl: constanciaUrl || null,
        pago_estado_validacion: 'pendiente',
        pago_fecha_efectiva: payDateVal,
        fechaModificacion: serverTimestamp(),
        usuarioModificacion: authUser.uid,
      });
      toast({ title: language === 'es' ? 'Comprobante registrado correctamente' : 'Payment receipt submitted successfully' });
      setVoucherReserva(null);
      setVoucherFile(null);
      setVoucherPreview(null);
    } catch (err: any) {
      console.error('Error uploading voucher:', err);
      toast({ title: 'Error al registrar comprobante', description: err.message, variant: 'destructive' });
    } finally {
      setIsUploadingVoucher(false);
      setVoucherUploadProgress(null);
    }
  };

  const handlePrevWeek = () => {
    setCurrentWeekStart(prev => subWeeks(prev, 1));
    setSelectedDay(null);
  }
  const handleNextWeek = () => {
    setCurrentWeekStart(prev => addWeeks(prev, 1));
    setSelectedDay(null);
  }
  const handleToday = () => {
    setCurrentWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }));
    setSelectedDay(null);
  }

  const handleToggleDayFilter = (day: Date) => {
    if (selectedDay && isSameDay(selectedDay, day)) {
      setSelectedDay(null);
    } else {
      setSelectedDay(day);
    }
  };

  const pageTitle = selectedCondominio
    ? t('myReservationsPageTitle', { condoName: selectedCondominio.nombre })
    : t('myReservations');

  if (authLoading || condoContextLoading) {
    return (
      <AppShell>
        <PageTitle title={pageTitle} />
        <div className="flex items-center justify-center h-64">
          <Icons.Spinner className="h-12 w-12 animate-spin text-primary" />
        </div>
      </AppShell>
    );
  }

  if (!selectedCondominio) {
    return (
      <AppShell>
        <PageTitle title={t('noCondoSelected')} />
        <Card><CardContent className="pt-6 text-center">{t('noCondoSelected')}</CardContent></Card>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
        <PageTitle title={pageTitle} />
        <Button
          className="rounded-full px-6 font-black uppercase tracking-widest hidden md:flex h-11 shadow-lg hover:shadow-xl transition-all"
          onClick={() => router.push(`/condominios/${condominioId}/espacios-comunes-usuario/ver-disponibilidad`)}
        >
          <Icons.Plus className="mr-2 h-5 w-5" />
          {language === 'es' ? 'Nueva Reserva' : 'New Reservation'}
        </Button>
      </div>

      <Tabs value={viewMode} onValueChange={(v: any) => setViewMode(v)} className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <TabsList className="bg-muted/50 rounded-full h-10 p-1">
            <TabsTrigger value="weekly" className="rounded-full px-4 text-xs font-black uppercase tracking-tighter">Semanal</TabsTrigger>
            <TabsTrigger value="monthly" className="rounded-full px-4 text-xs font-black uppercase tracking-tighter">Mensual</TabsTrigger>
          </TabsList>

          {viewMode === 'weekly' && (
            <div className="flex items-center gap-2">
              {selectedDay && (
                <Button variant="ghost" size="sm" onClick={() => setSelectedDay(null)} className="text-[10px] uppercase font-black text-rose-500 h-8 hidden sm:flex">
                  <Icons.X className="h-3 w-3 mr-1" /> {language === 'es' ? 'Limpiar Filtro' : 'Clear Filter'}
                </Button>
              )}
              <Button variant="outline" size="sm" onClick={handleToday} className="text-[10px] uppercase font-black text-primary h-8 px-4 rounded-full border-primary/20 hover:bg-primary/5">
                {t('today' as any) || "Hoy"}
              </Button>
            </div>
          )}
        </div>

        {/* Filters Container */}
        <div className="flex flex-col gap-2 mb-4">
          {/* Missing Voucher Filter */}
          {pendingCounts.pending > 0 && (
            <button
              onClick={() => setFilterPendingPayment(p => !p)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 text-left transition-all",
                filterPendingPayment
                  ? "border-orange-400 bg-orange-50 shadow-sm"
                  : "border-orange-200 bg-orange-50/40 hover:border-orange-300"
              )}
            >
              <div className={cn(
                "h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0",
                filterPendingPayment ? "bg-orange-500" : "bg-orange-100"
              )}>
                <Icons.AlertTriangle className={cn("h-4 w-4", filterPendingPayment ? "text-white" : "text-orange-500")} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-bold text-orange-800">
                  {pendingCounts.pending} {language === 'es' ? `reserva${pendingCounts.pending > 1 ? 's' : ''} pendiente${pendingCounts.pending > 1 ? 's' : ''} de pago` : `reservation${pendingCounts.pending > 1 ? 's' : ''} pending payment`}
                </p>
                <p className="text-[11px] text-orange-600">
                  {filterPendingPayment
                    ? (language === 'es' ? 'Mostrando solo sin comprobante — clic para ver todas' : 'Showing missing voucher only — click to show all')
                    : (language === 'es' ? 'Filtra las reservas que aún no tienen comprobante' : 'Filter reservations without a voucher')}
                </p>
              </div>
              <span className={cn(
                "text-[10px] font-black uppercase px-2 py-1 rounded-full",
                filterPendingPayment ? "bg-orange-500 text-white" : "bg-orange-200 text-orange-700"
              )}>
                {filterPendingPayment ? (language === 'es' ? 'Activo' : 'Active') : (language === 'es' ? 'Filtrar' : 'Filter')}
              </span>
            </button>
          )}

          {/* Pending Validation Filter */}
          {pendingCounts.validating > 0 && (
            <button
              onClick={() => setFilterPendingValidation(p => !p)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 text-left transition-all",
                filterPendingValidation
                  ? "border-indigo-400 bg-indigo-50 shadow-sm"
                  : "border-indigo-200 bg-indigo-50/40 hover:border-indigo-300"
              )}
            >
              <div className={cn(
                "h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0",
                filterPendingValidation ? "bg-indigo-500" : "bg-indigo-100"
              )}>
                <Icons.Eye className={cn("h-4 w-4", filterPendingValidation ? "text-white" : "text-indigo-500")} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-bold text-indigo-800">
                  {pendingCounts.validating} {language === 'es' ? `reserva${pendingCounts.validating > 1 ? 's' : ''} pendiente${pendingCounts.validating > 1 ? 's' : ''} de validar` : `reservation${pendingCounts.validating > 1 ? 's' : ''} pending validation`}
                </p>
                <p className="text-[11px] text-indigo-600">
                  {filterPendingValidation
                    ? (language === 'es' ? 'Mostrando solo por validar — clic para ver todas' : 'Showing pending validation only — click to show all')
                    : (language === 'es' ? 'Filtra las reservas con comprobante pendiente de revisión' : 'Filter reservations with vouchers pending review')}
                </p>
              </div>
              <span className={cn(
                "text-[10px] font-black uppercase px-2 py-1 rounded-full",
                filterPendingValidation ? "bg-indigo-500 text-white" : "bg-indigo-200 text-indigo-700"
              )}>
                {filterPendingValidation ? (language === 'es' ? 'Activo' : 'Active') : (language === 'es' ? 'Filtrar' : 'Filter')}
              </span>
            </button>
          )}
        </div>

        <TabsContent value="weekly" className="mt-0">
          <Card className="shadow-sm border-primary/10 overflow-hidden">
            <div className="p-4 bg-muted/5 border-b flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" className="h-8 w-8 rounded-full" onClick={handlePrevWeek}>
                  <Icons.ChevronLeft className="h-4 w-4" />
                </Button>
                <div className="text-sm font-bold text-[#008b8b] min-w-[140px] text-center uppercase tracking-tighter">
                  {format(currentWeekStart, 'MMMM yyyy', { locale: language === 'es' ? esLocale : enLocale })}
                </div>
                <Button variant="outline" size="icon" className="h-8 w-8 rounded-full" onClick={handleNextWeek}>
                  <Icons.ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-7 divide-x border-b">
              {weekDays.map((day) => {
                const dayReservas = getReservationsForDay(day);
                const isDayToday = isToday(day);
                const isDaySelected = selectedDay && isSameDay(selectedDay, day);
                return (
                  <div
                    key={day.toISOString()}
                    className={cn(
                      "flex flex-col items-center py-4 px-1 gap-1 transition-all cursor-pointer relative overflow-hidden",
                      isDaySelected ? "bg-primary/5" : "bg-background active:bg-muted/50"
                    )}
                    onClick={() => handleToggleDayFilter(day)}
                  >
                    <span className={cn(
                      "text-[9px] uppercase font-black tracking-widest",
                      isDaySelected || isDayToday ? "text-primary" : "text-muted-foreground"
                    )}>
                      {format(day, 'EEE', { locale: language === 'es' ? esLocale : enLocale })}
                    </span>
                    <span className={cn(
                      "h-8 w-8 flex items-center justify-center rounded-2xl text-sm font-black transition-all",
                      isDaySelected ? "bg-primary text-white shadow-lg scale-110" : isDayToday ? "bg-primary/20 text-primary" : "text-[#2D4F5E]"
                    )}>
                      {format(day, 'd')}
                    </span>
                    {dayReservas.length > 0 && (
                      <div className={cn(
                        "h-1 w-1 rounded-full absolute bottom-2",
                        isDaySelected ? "bg-white" : "bg-teal-500"
                      )} />
                    )}
                  </div>
                )
              })}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="monthly" className="mt-0 space-y-4">
          <Card className="p-4 shadow-sm border-primary/10 bg-background overflow-hidden">
            <Calendar
              mode="single"
              selected={selectedDay || undefined}
              onSelect={(d) => { if (d) setSelectedDay(d); else setSelectedDay(null); }}
              onMonthChange={setCurrentMonth}
              locale={language === 'es' ? esLocale : enLocale}
              className="w-full flex justify-center"
              classNames={{
                months: "w-full",
                month: "w-full space-y-4",
                caption: "flex justify-center pt-1 relative items-center mb-4",
                caption_label: "text-base font-black text-[#2D4F5E] uppercase tracking-wide",
                nav_button: cn(
                  buttonVariants({ variant: "outline" }),
                  "h-8 w-8 bg-transparent p-0 opacity-50 hover:opacity-100 rounded-full"
                ),
                table: "w-full border-collapse space-y-1",
                head_row: "flex w-full mb-2",
                head_cell: "text-muted-foreground rounded-md flex-1 font-black text-[10px] uppercase tracking-widest text-center",
                row: "flex w-full mt-2",
                cell: "relative flex-1 p-0 text-center text-sm focus-within:relative focus-within:z-20",
                day: cn(
                  buttonVariants({ variant: "ghost" }),
                  "h-10 w-10 p-0 font-bold aria-selected:opacity-100 rounded-2xl text-sm"
                ),
                day_selected: "bg-[#008b8b] text-white hover:bg-[#008b8b] hover:text-white focus:bg-[#008b8b] focus:text-white shadow-md !opacity-100",
                day_today: "bg-[#008b8b]/10 text-[#008b8b] border-2 border-[#008b8b]/20",
              }}
              components={{
                Day: (props) => {
                  const { date } = props;
                  const hasReservations = reservations.some(r => isSameDay(r.fechaHoraInicio.toDate(), date));
                  const isSelected = selectedDay && isSameDay(date, selectedDay);

                  return (
                    <div className="relative w-full h-full flex items-center justify-center p-0.5">
                      <Button
                        variant="ghost"
                        className={cn(
                          "h-10 w-10 p-0 font-bold rounded-2xl relative transition-all",
                          isSelected ? "bg-[#008b8b] text-white hover:bg-[#008b8b] shadow-md z-10" :
                            isToday(date) ? "bg-[#008b8b]/10 text-[#008b8b]" : "hover:bg-muted",
                        )}
                        onClick={() => handleToggleDayFilter(date)}
                      >
                        {format(date, 'd')}
                        {hasReservations && (
                          <div className={cn(
                            "absolute bottom-1 w-1 h-1 rounded-full",
                            isSelected ? "bg-white" : "bg-teal-500"
                          )} />
                        )}
                      </Button>
                    </div>
                  );
                }
              }}
            />
          </Card>
        </TabsContent>
      </Tabs>

      <div className="space-y-6">
        {isLoadingData ? (
          <div className="flex flex-col items-center justify-center py-20 animate-pulse">
            <Icons.CalendarCheck className="h-12 w-12 text-muted-foreground/30 mb-4" />
            <p className="text-sm text-muted-foreground font-medium">{t('loadingReservations')}</p>
          </div>
        ) : error ? (
          <Card><CardContent className="pt-6 text-center text-destructive">{error}</CardContent></Card>
        ) : reservations.length === 0 ? (
          <Card className="border-dashed border-2 bg-muted/20">
            <CardContent className="pt-12 pb-12 text-center text-muted-foreground">
              <Icons.CalendarDays className="mx-auto h-16 w-16 mb-4 text-muted-foreground/20" />
              <p className="text-lg font-headline font-semibold">{t('noReservationsFound')}</p>
              <p className="text-sm mt-1">{language === 'es' ? 'No tienes reservas registradas para esta semana.' : 'No reservations registered for this week.'}</p>
              <Button variant="outline" className="mt-6 border-primary/20 text-primary" onClick={() => router.push(`/condominios/${condominioId}/espacios-comunes-usuario/ver-disponibilidad`)}>
                <Icons.Plus className="mr-2 h-4 w-4" /> {language === 'es' ? 'Nueva Reserva' : 'New Reservation'}
              </Button>
            </CardContent>
          </Card>
        ) : filteredReservations.length === 0 ? (
          <div className="text-center py-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="h-16 w-16 bg-muted/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icons.Calendar className="h-8 w-8 text-muted-foreground/40" />
            </div>
            <h4 className="text-base font-headline font-bold text-foreground">{language === 'es' ? 'Sin reservas para este día' : 'No reservations for this day'}</h4>
            <p className="text-xs text-muted-foreground mt-1 mb-6">{language === 'es' ? 'Prueba seleccionando otro día o borra el filtro.' : 'Try selecting another day or clear the filter.'}</p>
            <Button variant="ghost" size="sm" onClick={() => setSelectedDay(null)} className="text-xs font-black uppercase text-primary">
              {language === 'es' ? 'Ver toda la semana' : 'View full week'}
            </Button>
          </div>
        ) : (
          <>
            {/* Desktop View (Table List) */}
            <div className="hidden md:block overflow-hidden rounded-xl border border-border/60 bg-background shadow-sm animate-in fade-in duration-500">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/30">
                    <TableHead className="font-headline font-bold text-xs uppercase tracking-wider">{t('commonArea' as any) || 'Espacio'}</TableHead>
                    <TableHead className="font-headline font-bold text-xs uppercase tracking-wider">{t('date' as any) || 'Fecha'}</TableHead>
                    <TableHead className="font-headline font-bold text-xs uppercase tracking-wider">{t('status' as any) || 'Estado'}</TableHead>
                    <TableHead className="font-headline font-bold text-xs uppercase tracking-wider text-right">{t('cost' as any) || 'Costo'}</TableHead>
                    <TableHead className="font-headline font-bold text-xs uppercase tracking-wider text-center">{t('actions' as any) || 'Acciones'}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReservations.map((reserva) => {
                    // Prefer live config from Firestore, fall back to denormalized field, then default 5
                    const cancelDays = espaciosComunesMap[reserva.espacioComunId]?.dias_anticipacion_cancelacion
                      ?? reserva.dias_anticipacion_cancelacion
                      ?? 5;
                    const hasVoucher = !!(reserva.pagoNroOperacion || reserva.pagoConstanciaUrl);
                    const canCancel =
                      (reserva.estado === 'SOLICITADO' || reserva.estado === 'CONFIRMADO') &&
                      isAfter(reserva.fechaHoraInicio.toDate(), addDays(new Date(), cancelDays)) &&
                      !hasVoucher;
                    const canReuploadPayment =
                      (reserva.estado === 'SOLICITADO' || reserva.estado === 'CONFIRMADO') &&
                      reserva.pago_estado_validacion === 'rechazado';

                    // Build a specific reason for why the cancel button is disabled
                    let cancelDisabledReason = '';
                    if (!canCancel) {
                      if (reserva.estado !== 'SOLICITADO' && reserva.estado !== 'CONFIRMADO') {
                        cancelDisabledReason = language === 'es'
                          ? 'Esta reserva ya no se encuentra activa y no puede ser cancelada.'
                          : 'This reservation is no longer active and cannot be cancelled.';
                      } else if (hasVoucher) {
                        cancelDisabledReason = language === 'es'
                          ? 'No puedes cancelar una reserva con pago registrado. Contacta al administrador para gestionar la cancelación.'
                          : 'You cannot cancel a reservation with a registered payment. Contact the administrator to manage cancellation.';
                      } else {
                        cancelDisabledReason = language === 'es'
                          ? `Solo puedes cancelar con más de ${cancelDays} días de anticipación a la fecha de la reserva.`
                          : `Cancellation requires more than ${cancelDays} days before the reservation date.`;
                      }
                    }

                    return (
                      <TableRow key={reserva.id} className="hover:bg-muted/5 transition-colors">
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <Icons.Home className="h-4 w-4 text-primary" />
                            </div>
                            <span className="font-bold text-foreground">{reserva.espacioComunNombre}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-medium text-sm text-foreground">
                              {format(reserva.fechaHoraInicio.toDate(), 'PPP', { locale: language === 'es' ? esLocale : enLocale })}
                            </span>
                            <span className="text-[11px] text-muted-foreground font-mono">
                              {format(reserva.fechaHoraInicio.toDate(), 'p')} - {format(reserva.fechaHoraFin.toDate(), 'p')}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col gap-1">
                            <Badge
                              className={cn(
                                "text-[10px] uppercase font-black px-2 py-0.5 w-fit",
                                reserva.estado === 'CONFIRMADO' ? "bg-green-100 text-green-700 hover:bg-green-100" : reserva.estado === 'SOLICITADO' ? "bg-amber-100 text-amber-700 hover:bg-amber-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"
                              )}
                              variant="outline"
                            >
                              {t(`reservationStatus_${reserva.estado}` as any) || reserva.estado}
                            </Badge>
                            {reserva.pago_diferido && reserva.pago_estado_validacion === 'pendiente' && (
                              <>
                                {!(reserva.pagoNroOperacion || reserva.pagoConstanciaUrl) ? (
                                  <span className="inline-flex items-center gap-1 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-full bg-orange-100 text-orange-700 w-fit">
                                    <Icons.Clock className="h-2.5 w-2.5" /> Pago Pendiente
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-700 w-fit">
                                    <Icons.Eye className="h-2.5 w-2.5" /> Pago por Validar
                                  </span>
                                )}
                              </>
                            )}
                            {reserva.pago_estado_validacion === 'rechazado' && (
                              <span className="inline-flex items-center gap-1 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-full bg-red-100 text-red-700 w-fit">
                                <Icons.XCircle className="h-2.5 w-2.5" /> Pago Rechazado
                              </span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          {reserva.costoReserva && reserva.costoReserva > 0 ? (
                            <div className="flex flex-col items-end gap-0.5">
                              <span className="font-black text-sm text-primary">
                                {(reserva.monedaCosto || 'S/') + ' ' + reserva.costoReserva.toFixed(2)}
                              </span>
                              {((reserva.montoAlquiler != null && reserva.montoAlquiler > 0) || (reserva.montoGarantia != null && reserva.montoGarantia > 0)) && (
                                <div className="text-[10px] text-muted-foreground leading-tight">
                                  {reserva.montoAlquiler != null && reserva.montoAlquiler > 0 && (
                                    <span className="block">Alquiler: {(reserva.monedaCosto || 'S/') + ' ' + reserva.montoAlquiler.toFixed(2)}</span>
                                  )}
                                  {reserva.montoGarantia != null && reserva.montoGarantia > 0 && (
                                    <span className="block">Garantía: {(reserva.monedaCosto || 'S/') + ' ' + reserva.montoGarantia.toFixed(2)}</span>
                                  )}
                                </div>
                              )}
                            </div>
                          ) : (
                            <span className="font-black text-sm text-green-600">{language === 'es' ? 'Gratis' : 'Free'}</span>
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0"
                              onClick={() => setSelectedMobileReserva(reserva)}
                              title={language === 'es' ? 'Ver detalle' : 'View detail'}
                            >
                              <Icons.Eye className="h-4 w-4 text-muted-foreground" />
                            </Button>
                            {(reserva.pago_diferido && reserva.pago_estado_validacion === 'pendiente') || canReuploadPayment ? (
                              <Button
                                variant="ghost"
                                size="sm"
                                className={cn(
                                  "h-8 w-8 p-0",
                                  canReuploadPayment
                                    ? "text-red-500 hover:text-red-600 hover:bg-red-50"
                                    : "text-orange-500 hover:text-orange-600 hover:bg-orange-50"
                                )}
                                onClick={() => handleOpenVoucherUpload(reserva)}
                                title={canReuploadPayment ? (language === 'es' ? 'Volver a registrar comprobante' : 'Re-upload payment receipt') : (language === 'es' ? 'Subir comprobante de pago' : 'Upload payment receipt')}
                              >
                                <Icons.Upload className="h-4 w-4" />
                              </Button>
                            ) : null}
                            <TooltipProvider delayDuration={200}>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <span className="inline-flex">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-8 w-8 p-0 text-red-500 hover:text-red-600 hover:bg-red-50"
                                      disabled={!canCancel}
                                      onClick={() => handleOpenCancelDialog(reserva)}
                                    >
                                      <Icons.Trash2 className="h-4 w-4" />
                                    </Button>
                                  </span>
                                </TooltipTrigger>
                                <TooltipContent side="top" className="max-w-[260px] text-center text-xs">
                                  {canCancel
                                    ? (language === 'es' ? 'Cancelar reserva' : 'Cancel reservation')
                                    : cancelDisabledReason}
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {/* Mobile View (Interactive List + Overlays) */}
            <div className="grid grid-cols-1 gap-3 md:hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
              {filteredReservations.map((reserva) => (
                <Card
                  key={`mobile-${reserva.id}`}
                  className={cn(
                    "shadow-sm transition-all overflow-hidden border-l-4",
                    reserva.pago_diferido && reserva.pago_estado_validacion === 'pendiente'
                      ? "border-l-orange-400"
                      : reserva.estado === 'CONFIRMADO' ? "border-l-green-500"
                        : reserva.estado === 'SOLICITADO' ? "border-l-amber-500"
                          : "border-l-slate-400"
                  )}
                  onClick={() => setSelectedMobileReserva(reserva)}
                >
                  <CardHeader className="p-4 pb-2 flex flex-row items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Icons.Home className="h-4 w-4 text-primary" />
                      <span className="font-bold text-sm tracking-tight">{reserva.espacioComunNombre}</span>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <Badge className="text-[9px] uppercase h-5 px-1.5 font-bold" variant={reserva.estado === 'CONFIRMADO' ? 'default' : 'outline'}>
                        {t(`reservationStatus_${reserva.estado}` as any) || reserva.estado}
                      </Badge>
                      {reserva.pago_diferido && reserva.pago_estado_validacion === 'pendiente' && (
                        <div className="flex flex-col items-end gap-1">
                          {!(reserva.pagoNroOperacion || reserva.pagoConstanciaUrl) ? (
                            <span className="inline-flex items-center gap-1 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-full bg-orange-100 text-orange-600">
                              <Icons.Clock className="h-2.5 w-2.5" /> Pago Pendiente
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-600">
                              <Icons.Eye className="h-2.5 w-2.5" /> Pago por Validar
                            </span>
                          )}
                        </div>
                      )}
                      {reserva.pago_estado_validacion === 'rechazado' && (
                        <span className="inline-flex items-center gap-1 text-[9px] font-black uppercase px-1.5 py-0.5 rounded-full bg-red-100 text-red-600">
                          <Icons.XCircle className="h-2.5 w-2.5" /> Pago Rechazado
                        </span>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <div className="flex justify-between items-end">
                      <div className="space-y-0.5">
                        <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                          <Icons.Calendar className="h-3 w-3" /> {format(reserva.fechaHoraInicio.toDate(), 'eee d MMM', { locale: language === 'es' ? esLocale : enLocale })}
                        </span>
                        <span className="text-xs font-semibold text-foreground">
                          {format(reserva.fechaHoraInicio.toDate(), 'p')} - {format(reserva.fechaHoraFin.toDate(), 'p')}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-black text-teal-600 block">
                          {reserva.costoReserva && reserva.costoReserva > 0 ? (reserva.monedaCosto || 'S/') + ' ' + reserva.costoReserva.toFixed(2) : 'Gratis'}
                        </span>
                        <Icons.ChevronRight className="h-4 w-4 ml-auto text-muted-foreground/30" />
                      </div>
                    </div>
                    {(reserva.pago_diferido && reserva.pago_estado_validacion === 'pendiente') && (
                      <button
                        className="mt-3 w-full flex items-center justify-center gap-2 py-2 rounded-xl bg-orange-50 border border-orange-200 text-[11px] font-bold text-orange-700 active:bg-orange-100"
                        onClick={(e) => { e.stopPropagation(); handleOpenVoucherUpload(reserva); }}
                      >
                        <Icons.Upload className="h-3.5 w-3.5" />
                        {language === 'es' ? 'Subir Comprobante de Pago' : 'Upload Payment Receipt'}
                      </button>
                    )}
                    {(reserva.estado === 'SOLICITADO' || reserva.estado === 'CONFIRMADO') && reserva.pago_estado_validacion === 'rechazado' && (
                      <button
                        className="mt-3 w-full flex items-center justify-center gap-2 py-2 rounded-xl bg-red-50 border border-red-200 text-[11px] font-bold text-red-700 active:bg-red-100"
                        onClick={(e) => { e.stopPropagation(); handleOpenVoucherUpload(reserva); }}
                      >
                        <Icons.Upload className="h-3.5 w-3.5" />
                        {language === 'es' ? 'Volver a registrar comprobante' : 'Re-upload Payment Receipt'}
                      </button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Desktop Detail Dialog */}
      <Dialog open={!!selectedMobileReserva} onOpenChange={(open) => { if (!open) setSelectedMobileReserva(null); }}>
        <DialogContent className="hidden md:flex flex-col sm:max-w-lg rounded-[24px] p-0 overflow-hidden gap-0">
          <DialogHeader className="p-4 pb-2 border-b">
            <DialogTitle className="font-headline text-base text-[#2D4F5E]">Detalle de Reserva</DialogTitle>
            <DialogDescription className="sr-only">
              {selectedMobileReserva?.espacioComunNombre}
            </DialogDescription>
          </DialogHeader>
          {selectedMobileReserva && (
            <div className="overflow-y-auto">
              <MiReservaCard
                reserva={{
                  ...selectedMobileReserva,
                  userDisplayName: authUser?.displayName || authUser?.email || selectedMobileReserva.usuarioId,
                  userEmail: authUser?.email || undefined,
                  requiere_aprobacion: selectedMobileReserva.requiere_aprobacion ?? espaciosComunesMap[selectedMobileReserva.espacioComunId]?.requiere_aprobacion ?? true,
                  dias_anticipacion_cancelacion: espaciosComunesMap[selectedMobileReserva.espacioComunId]?.dias_anticipacion_cancelacion
                    ?? selectedMobileReserva.dias_anticipacion_cancelacion
                    ?? 5,
                }}
                onCancel={() => handleOpenCancelDialog(selectedMobileReserva)}
                onUploadVoucher={() => handleOpenVoucherUpload(selectedMobileReserva)}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Mobile Overlay */}
      {selectedMobileReserva && (
        <div className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-sm flex flex-col justify-end items-center p-6 gap-6 md:hidden animate-in fade-in duration-200" onClick={() => setSelectedMobileReserva(null)}>
          <div className="w-full flex-1 flex items-center" onClick={(e) => e.stopPropagation()}>
            <MiReservaCard
              reserva={{
                ...selectedMobileReserva,
                userDisplayName: authUser?.displayName || authUser?.email || selectedMobileReserva.usuarioId,
                userEmail: authUser?.email || undefined,
                requiere_aprobacion: selectedMobileReserva.requiere_aprobacion ?? espaciosComunesMap[selectedMobileReserva.espacioComunId]?.requiere_aprobacion ?? true,
                dias_anticipacion_cancelacion: espaciosComunesMap[selectedMobileReserva.espacioComunId]?.dias_anticipacion_cancelacion
                  ?? selectedMobileReserva.dias_anticipacion_cancelacion
                  ?? 5,
              }}
              onCancel={() => handleOpenCancelDialog(selectedMobileReserva)}
              onUploadVoucher={() => handleOpenVoucherUpload(selectedMobileReserva)}
            />
          </div>
          <div className="w-full" onClick={(e) => e.stopPropagation()}>
            <Button
              className="h-14 w-14 rounded-full bg-white shadow-lg mx-auto flex items-center justify-center p-0"
              variant="outline"
              onClick={() => setSelectedMobileReserva(null)}
            >
              <Icons.X className="h-6 w-6 text-slate-500" />
            </Button>
          </div>
        </div>
      )}

      {/* Payment Voucher Upload Dialog */}
      <Dialog open={!!voucherReserva} onOpenChange={(open) => { if (!open) { setVoucherReserva(null); setVoucherFile(null); setVoucherPreview(null); } }}>
        <DialogContent className="sm:max-w-md rounded-[24px] p-0 overflow-hidden">
          <DialogHeader className="p-5 pb-3 border-b bg-orange-50">
            <DialogTitle className="font-headline text-base text-orange-900 flex items-center gap-2">
              <Icons.Upload className="h-5 w-5 text-orange-500" />
              {language === 'es' ? 'Registrar Comprobante de Pago' : 'Register Payment Receipt'}
            </DialogTitle>
            <DialogDescription className="text-xs text-orange-700">
              {voucherReserva?.espacioComunNombre} &bull; {voucherReserva ? format(voucherReserva.fechaHoraInicio.toDate(), 'PPP p', { locale: language === 'es' ? esLocale : enLocale }) : ''}
            </DialogDescription>
          </DialogHeader>
          <div className="p-5 space-y-4">
            {voucherReserva && voucherReserva.costoReserva !== undefined && voucherReserva.costoReserva !== null && (
              <div className="p-3 bg-orange-500/10 border border-orange-500/20 rounded-xl flex items-center justify-between text-orange-950 dark:text-orange-300">
                <div className="flex items-center gap-2">
                  <Icons.CreditCard className="h-4 w-4 text-orange-600 shrink-0" />
                  <span className="text-xs font-bold">Monto a pagar por esta reserva:</span>
                </div>
                <span className="text-sm font-black tracking-tight bg-orange-600 text-white px-2.5 py-0.5 rounded-lg shadow-sm">
                  {voucherReserva.monedaCosto || 'PEN'} {voucherReserva.costoReserva.toFixed(2)}
                </span>
              </div>
            )}
            <div className="space-y-1.5">
              <Label htmlFor="voucher-fecha" className="text-xs font-bold uppercase tracking-wider text-slate-600">
                {language === 'es' ? 'Fecha de Pago' : 'Payment Date'}
              </Label>
              <Input
                id="voucher-fecha"
                type="date"
                value={voucherFechaPago}
                onChange={e => setVoucherFechaPago(e.target.value)}
                disabled={isUploadingVoucher}
                className="rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="voucher-nro" className="text-xs font-bold uppercase tracking-wider text-slate-600">
                {language === 'es' ? 'Número de Operación' : 'Operation Number'}
              </Label>
              <Input
                id="voucher-nro"
                placeholder="Ej: 123456789"
                value={voucherNroOperacion}
                onChange={e => setVoucherNroOperacion(e.target.value)}
                disabled={isUploadingVoucher}
                className="rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="voucher-file" className="text-xs font-bold uppercase tracking-wider text-slate-600">
                {language === 'es' ? 'Adjuntar Comprobante' : 'Attach Receipt'}
              </Label>
              <Input
                id="voucher-file"
                type="file"
                accept="image/*,application/pdf"
                onChange={handleVoucherFileChange}
                disabled={isUploadingVoucher}
                className="rounded-xl"
              />
            </div>
            {voucherPreview && (
              <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-slate-100 border">
                <img src={voucherPreview} alt="Preview" className="w-full h-full object-contain" />
              </div>
            )}
            {voucherUploadProgress !== null && (
              <div className="space-y-1">
                <p className="text-[11px] text-muted-foreground">Subiendo... {voucherUploadProgress.toFixed(0)}%</p>
                <Progress value={voucherUploadProgress} className="h-1.5 rounded-full" />
              </div>
            )}
            <div className="flex gap-2 pt-2">
              <Button
                variant="outline"
                className="flex-1 rounded-xl h-12"
                onClick={() => { setVoucherReserva(null); setVoucherFile(null); setVoucherPreview(null); }}
                disabled={isUploadingVoucher}
              >
                {t('cancel')}
              </Button>
              <Button
                className="flex-1 rounded-xl h-12 bg-orange-500 hover:bg-orange-600 text-white font-bold"
                onClick={handleSubmitVoucher}
                disabled={isUploadingVoucher || (!voucherFile && !voucherNroOperacion.trim())}
              >
                {isUploadingVoucher
                  ? (language === 'es' ? 'Subiendo...' : 'Uploading...')
                  : (language === 'es' ? 'Registrar Pago' : 'Register Payment')}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {reservationToCancel && (
        <AlertDialog open={isCancelConfirmOpen} onOpenChange={setIsCancelConfirmOpen}>
          <AlertDialogContent className="w-[92vw] rounded-[24px]">
            <AlertDialogHeader>
              <AlertDialogTitle>{t('confirmCancelReservationTitle')}</AlertDialogTitle>
              <AlertDialogDescription>
                {t('confirmCancelReservationMessage', {
                  commonAreaName: reservationToCancel.espacioComunNombre,
                  dateTimeRange: formatDateRange(reservationToCancel.fechaHoraInicio, reservationToCancel.fechaHoraFin),
                })}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="flex flex-col gap-2 pt-2">
              <AlertDialogCancel className="w-full h-12 rounded-xl mt-0" onClick={() => setIsCancelConfirmOpen(false)}>{t('cancel')}</AlertDialogCancel>
              <AlertDialogAction className="w-full h-12 rounded-xl" onClick={handleConfirmCancelReservation}>{t('cancelReservationButton')}</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      {/* Mobile Floating Action Button */}
      <div className="md:hidden fixed bottom-6 right-6 z-50">
        <Button
          className="h-14 w-14 rounded-full shadow-2xl p-0 flex items-center justify-center bg-primary text-primary-foreground hover:bg-primary/90 transition-all active:scale-95"
          onClick={() => router.push(`/condominios/${condominioId}/espacios-comunes-usuario/ver-disponibilidad`)}
          size="icon"
        >
          <Icons.Plus className="h-8 w-8" />
        </Button>
      </div>
    </AppShell>
  );
}

