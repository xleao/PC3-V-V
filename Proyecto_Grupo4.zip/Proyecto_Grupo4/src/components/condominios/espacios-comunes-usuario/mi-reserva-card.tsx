
"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Icons } from '@/components/icons';
import type { ReservaEspacioComun } from '@/types';
import { useLanguage } from '@/hooks/use-language';
import { format, isAfter, addDays } from 'date-fns';
import { es as esLocale, enUS as enLocale } from 'date-fns/locale';
import { Timestamp } from 'firebase/firestore';
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface MiReservaCardProps {
  reserva: ReservaEspacioComun;
  onCancel: () => void;
  onUploadVoucher?: () => void;
}

function formatCurrency(amount: number | undefined | null, currencySymbol: string = 'S/') {
  if (amount === undefined || amount === null || isNaN(amount)) return `${currencySymbol} 0.00`;
  return `${currencySymbol} ${amount.toFixed(2)}`;
}

export function MiReservaCard({ reserva, onCancel, onUploadVoucher }: MiReservaCardProps) {
  const { t, language } = useLanguage();
  const { toast } = useToast();
  const locale = language === 'es' ? esLocale : enLocale;

  const formatDate = (timestamp?: Timestamp | Date | null, dateFormat: string = 'PPP p') => {
    if (!timestamp) return 'N/A';
    const date = timestamp instanceof Timestamp ? timestamp.toDate() : timestamp;
    return format(date, dateFormat, { locale });
  };

  const getStatusBadgeVariant = (status: ReservaEspacioComun['estado']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'CONFIRMADO': return "default";
      case 'SOLICITADO': return "secondary";
      case 'RECHAZADO': return "destructive";
      case 'CANCELADO_USUARIO':
      case 'CANCELADO_ADMIN':
        return "outline";
      default: return "outline";
    }
  };

  const getPaymentValidationBadgeVariant = (status?: 'pendiente' | 'validado' | 'rechazado', hasVoucher?: boolean): "default" | "secondary" | "destructive" | "outline" | "indigo" => {
     if (!status) return "outline";
     switch (status) {
        case 'validado': return "default";
        case 'pendiente': return hasVoucher ? "indigo" : "secondary";
        case 'rechazado': return "destructive";
        default: return "outline";
     }
  };

  const hasVoucher = !!(reserva.pagoNroOperacion || reserva.pagoConstanciaUrl);

  const cancelDays = reserva.dias_anticipacion_cancelacion ?? 5;
  const canCancel = 
    (reserva.estado === 'SOLICITADO' || reserva.estado === 'CONFIRMADO') && 
    isAfter(reserva.fechaHoraInicio.toDate(), addDays(new Date(), cancelDays)) &&
    !hasVoucher;
  
  const handleCancelClick = () => {
    if (!canCancel) {
      let reason = t('cannotCancelReservationAdminProcessed');
      if (hasVoucher) {
        reason = language === 'es'
          ? "No puedes cancelar una reserva con pago registrado. Contacta al administrador para gestionar la cancelación."
          : "You cannot cancel a reservation with a registered payment. Contact the administrator to manage cancellation.";
      } else if (!isAfter(reserva.fechaHoraInicio.toDate(), addDays(new Date(), cancelDays))) {
        reason = language === 'es'
          ? `Solo puedes cancelar con más de ${cancelDays} días de anticipación.`
          : `Cancellation requires more than ${cancelDays} days in advance.`;
      }
      toast({
        title: t('cannotCancelReservationTitle'),
        description: reason,
        variant: "default"
      });
      return;
    }
    onCancel();
  };


  return (
    <Card className="shadow-sm border-2 border-slate-100/60 rounded-[1.5rem] w-full pb-1">
      <CardHeader className="p-4 md:p-5 pb-1">
        <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
            <div className="w-full">
                <CardTitle className="font-headline font-black text-lg md:text-xl text-[#2D4F5E] mb-0.5">{reserva.espacioComunNombre}</CardTitle>
                <CardDescription className="text-xs text-slate-500 font-medium flex flex-col gap-1.5 mt-0.5">
                  <span className="font-mono text-[11px] md:text-xs text-slate-400">{t('reservationDateTime')}: {formatDate(reserva.fechaHoraInicio)} - {formatDate(reserva.fechaHoraFin, 'p')}</span>
                </CardDescription>
            </div>
            <Badge variant={getStatusBadgeVariant(reserva.estado)} className="text-[9px] uppercase font-black px-3 py-1 flex-shrink-0 tracking-wider">
                {t(`reservationStatus_${reserva.estado}` as any) || reserva.estado}
            </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3.5 text-sm px-4 md:px-5 pb-1">
        <div className="grid grid-cols-2 gap-y-3.5 gap-x-6 py-1">
          <div className="col-span-2">
            <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-0.5">
              {language === 'es' ? 'Usuario' : 'User'}
            </span>
            <span className="font-medium text-foreground">{reserva.userDisplayName || reserva.userEmail}</span>
          </div>

          <div className="col-span-2">
            <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-0.5">
              {language === 'es' ? 'Fechas' : 'Dates'}
            </span>
            <span className="font-medium text-foreground">
              {formatDate(reserva.fechaHoraInicio)} - {formatDate(reserva.fechaHoraFin, 'p')}
            </span>
          </div>

          <div>
            <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-0.5">
              {language === 'es' ? 'Estado' : 'Status'}
            </span>
            <div>
              <Badge variant={getStatusBadgeVariant(reserva.estado)} className="text-[10px] uppercase font-bold">
                {t(`reservationStatus_${reserva.estado}` as any) || reserva.estado}
              </Badge>
            </div>
          </div>

          <div>
            <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-0.5">
              {language === 'es' ? 'Tipo de Uso' : 'Use Type'}
            </span>
            <div>
              <Badge variant="outline" className="text-[10px] uppercase font-bold">
                {reserva.esExclusivo ? t('useTypeExclusive') : t('useTypeShared')}
              </Badge>
            </div>
          </div>

          {/* Cost Block - Horizontal format */}
          <div className="col-span-2 bg-[#f0f9fa] border border-[#d2f0f4] p-3.5 rounded-2xl flex items-center justify-between shadow-sm">
            <div>
              <span className="text-[10px] font-black uppercase text-[#0a9396] tracking-wider block mb-0.5">
                {language === 'es' ? 'Costo Total' : 'Total Cost'}
              </span>
              <span className="font-black text-xl md:text-2xl text-[#2D4F5E]">
                {reserva.costoReserva && reserva.costoReserva > 0 
                  ? formatCurrency(reserva.costoReserva, reserva.monedaCosto || 'S/') 
                  : (language === 'es' ? 'Sin costo' : 'Free')}
              </span>
            </div>
            
            {((reserva.montoAlquiler != null && reserva.montoAlquiler > 0) || (reserva.montoGarantia != null && reserva.montoGarantia > 0)) && (
              <div className="text-[11px] font-medium text-slate-600 space-y-1 text-right border-l border-[#d2f0f4] pl-4">
                {reserva.montoAlquiler != null && reserva.montoAlquiler > 0 && (
                  <div className="flex items-center justify-end gap-2">
                    <span className="text-slate-400 font-bold uppercase text-[9px]">{language === 'es' ? 'Alquiler:' : 'Rental:'}</span>
                    <span className="font-semibold text-[#2D4F5E] font-mono">{formatCurrency(reserva.montoAlquiler, reserva.monedaCosto || 'S/')}</span>
                  </div>
                )}
                {reserva.montoGarantia != null && reserva.montoGarantia > 0 && (
                  <div className="flex items-center justify-end gap-2">
                    <span className="text-slate-400 font-bold uppercase text-[9px]">{language === 'es' ? 'Garantía:' : 'Warranty:'}</span>
                    <span className="font-semibold text-amber-700 font-mono">{formatCurrency(reserva.montoGarantia, reserva.monedaCosto || 'S/')}</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {reserva.motivoReserva && (
            <div className="col-span-2">
              <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-0.5">
                {language === 'es' ? 'Motivo' : 'Reason'}
              </span>
              <span className="font-medium text-foreground">{reserva.motivoReserva}</span>
            </div>
          )}

          {reserva.notasAdmin && (
            <div className="col-span-2">
              <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-0.5">
                {language === 'es' ? 'Notas Admin' : 'Admin Notes'}
              </span>
              <span className="font-medium text-destructive">{reserva.notasAdmin}</span>
            </div>
          )}

          {reserva.pago_estado_validacion && (
            <div className="col-span-2 border-t pt-3 mt-1">
              <span className="text-[11px] font-bold text-muted-foreground uppercase block mb-1">
                {language === 'es' ? 'Estado de Pago' : 'Payment Status'}
              </span>
              <div className="flex items-center gap-3">
                <Badge 
                  variant={getPaymentValidationBadgeVariant(reserva.pago_estado_validacion, hasVoucher) as any} 
                  className={cn(
                    "text-[10px] uppercase font-black px-2 py-0.5",
                    reserva.pago_estado_validacion === 'pendiente' && hasVoucher ? "bg-indigo-100 text-indigo-700 border-indigo-200" : ""
                  )}
                >
                  {reserva.pago_estado_validacion === 'pendiente' 
                    ? (hasVoucher 
                        ? (language === 'es' ? 'Pago por Validar' : 'Validation Pending') 
                        : (language === 'es' ? 'Pago Pendiente' : 'Payment Pending'))
                    : (t(`status${reserva.pago_estado_validacion.charAt(0).toUpperCase() + reserva.pago_estado_validacion.slice(1)}` as any) || reserva.pago_estado_validacion)}
                </Badge>
                {reserva.pagoNroOperacion && <span className="text-xs font-mono">Op: {reserva.pagoNroOperacion}</span>}
                {reserva.pagoConstanciaUrl && (
                  <Button variant="link" size="sm" className="p-0 h-auto text-xs text-[#0a9396] hover:text-[#2D4F5E]" asChild>
                    <a href={reserva.pagoConstanciaUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1">
                      <Icons.Eye className="h-3 w-3" /> {language === 'es' ? 'Ver Voucher' : 'View Voucher'}
                    </a>
                  </Button>
                )}
              </div>
            </div>
          )}

          {reserva.pago_devolucion_monto !== undefined && reserva.pago_devolucion_monto > 0 && (
            <div className="col-span-2 border-t pt-3 mt-1 space-y-2">
              <span className="text-[11px] font-bold text-red-600 uppercase block">
                {language === 'es' ? 'Reembolso por Cancelación' : 'Cancellation Refund'}
              </span>
              <div className="grid grid-cols-2 gap-y-2 text-xs leading-tight">
                <div>
                  <span className="font-semibold block text-[10px] text-muted-foreground uppercase">
                    {language === 'es' ? 'Monto Reembolsado' : 'Amount Refunded'}
                  </span>
                  <span className="text-emerald-600 font-mono font-bold">
                    {formatCurrency(reserva.pago_devolucion_monto, reserva.monedaCosto || 'S/')}
                  </span>
                </div>
                {reserva.pago_devolucion_original !== undefined && reserva.pago_devolucion_original > 0 && (
                  <div>
                    <span className="font-semibold block text-[10px] text-muted-foreground uppercase">
                      {language === 'es' ? 'Monto Esperado' : 'Expected Amount'}
                    </span>
                    <span className="text-slate-600 font-mono font-bold">
                      {formatCurrency(reserva.pago_devolucion_original, reserva.monedaCosto || 'S/')}
                    </span>
                  </div>
                )}
                {reserva.pago_devolucion_diferencia !== undefined && reserva.pago_devolucion_diferencia > 0 && (
                  <div>
                    <span className="font-semibold block text-[10px] text-muted-foreground uppercase">
                      {language === 'es' ? 'Retención / Descuento' : 'Retention / Discount'}
                    </span>
                    <span className="text-red-600 font-mono font-bold">
                      -{formatCurrency(reserva.pago_devolucion_diferencia, reserva.monedaCosto || 'S/')}
                    </span>
                  </div>
                )}
                <div>
                  <span className="font-semibold block text-[10px] text-muted-foreground uppercase">
                    {language === 'es' ? 'Nro. Operación' : 'Operation No.'}
                  </span>
                  <span className="text-foreground font-mono font-bold">{reserva.pago_devolucion_nro_operacion || 'N/A'}</span>
                </div>
                {reserva.pago_devolucion_fecha && (
                  <div className="col-span-2">
                    <span className="font-semibold block text-[10px] text-muted-foreground uppercase">
                      {language === 'es' ? 'Fecha Reembolso' : 'Refund Date'}
                    </span>
                    <span className="text-foreground">{formatDate(reserva.pago_devolucion_fecha)}</span>
                  </div>
                )}
                {reserva.pago_devolucion_constancia_url && (
                  <div className="col-span-2 mt-1">
                    <Button variant="outline" size="sm" className="w-full text-[11px] h-8 text-teal-700 border-teal-200" asChild>
                      <a href={reserva.pago_devolucion_constancia_url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-1.5">
                        <Icons.Eye className="h-3.5 w-3.5" /> {language === 'es' ? 'Ver Constancia Reembolso' : 'View Refund Receipt'}
                      </a>
                    </Button>
                  </div>
                )}
                {reserva.pago_devolucion_descuento_evidencia_url && (
                  <div className="col-span-2 mt-1">
                    <Button variant="outline" size="sm" className="w-full text-[11px] h-8 text-red-500 hover:text-red-600 hover:bg-red-50/20 border-red-200" asChild>
                      <a href={reserva.pago_devolucion_descuento_evidencia_url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-1.5">
                        <Icons.Eye className="h-3.5 w-3.5 text-red-500" /> {language === 'es' ? 'Ver Evidencia Descuento' : 'View Discount Evidence'}
                      </a>
                    </Button>
                  </div>
                )}
                {reserva.pago_devolucion_descuento_motivo && (
                  <div className="col-span-2 mt-1 p-2 bg-red-50/50 rounded-lg border border-red-100 text-red-900">
                    <span className="font-semibold block text-[9px] text-red-700 uppercase">
                      {language === 'es' ? 'Motivo del descuento' : 'Discount Reason'}
                    </span>
                    <span className="text-xs leading-normal">{reserva.pago_devolucion_descuento_motivo}</span>
                  </div>
                )}
                {reserva.pago_devolucion_notas && (
                  <div className="col-span-2 mt-1 p-2 bg-slate-50 rounded-lg border border-slate-200 text-slate-700">
                    <span className="font-semibold block text-[9px] text-slate-500 uppercase">
                      {language === 'es' ? 'Notas de Reembolso' : 'Refund Notes'}
                    </span>
                    <span className="text-xs leading-normal">{reserva.pago_devolucion_notas}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {reserva.montoGarantia !== undefined && reserva.montoGarantia > 0 && (
            <div className="col-span-2 border-t pt-3 mt-1 space-y-2">
              <span className="text-[11px] font-bold text-[#2D4F5E] uppercase block">
                {language === 'es' ? 'Detalle de Garantía' : 'Warranty Details'}
              </span>
              <div className="grid grid-cols-2 gap-y-2 text-xs leading-tight">
                <div>
                  <span className="font-semibold block text-[10px] text-muted-foreground uppercase">
                    {language === 'es' ? 'Garantía Original' : 'Original Warranty'}
                  </span>
                  <span className="text-amber-700 font-mono font-bold">
                    {formatCurrency(reserva.montoGarantia, reserva.monedaCosto || 'S/')}
                  </span>
                </div>
                <div>
                  <span className="font-semibold block text-[10px] text-muted-foreground uppercase">
                    {language === 'es' ? 'Estado Devolución' : 'Refund Status'}
                  </span>
                  <Badge variant="outline" className="text-[9px] uppercase font-bold">
                    {reserva.garantia_estado === 'pendiente' 
                      ? (language === 'es' ? 'Pendiente' : 'Pending') 
                      : reserva.garantia_estado === 'devuelto' 
                        ? (language === 'es' ? 'Devuelto' : 'Refunded') 
                        : reserva.garantia_estado === 'cancelado'
                          ? (language === 'es' ? 'No Requerido' : 'Not Required')
                          : (language === 'es' ? 'No Aplica' : 'N/A')}
                  </Badge>
                </div>
                {reserva.garantia_estado === 'devuelto' && (
                  <>
                    <div>
                      <span className="font-semibold block text-[10px] text-muted-foreground uppercase">
                        {language === 'es' ? 'Monto Devuelto' : 'Amount Refunded'}
                      </span>
                      <span className="text-emerald-600 font-mono font-bold">
                        {formatCurrency(reserva.garantia_devolucion_monto ?? reserva.montoGarantia, reserva.monedaCosto || 'S/')}
                      </span>
                    </div>
                    {reserva.garantia_devolucion_diferencia !== undefined && reserva.garantia_devolucion_diferencia > 0 && (
                      <div>
                        <span className="font-semibold block text-[10px] text-muted-foreground uppercase">
                          {language === 'es' ? 'Retención / Multa' : 'Retention / Fine'}
                        </span>
                        <span className="text-red-600 font-mono font-bold">
                          -{formatCurrency(reserva.garantia_devolucion_diferencia, reserva.monedaCosto || 'S/')}
                        </span>
                      </div>
                    )}
                    <div>
                      <span className="font-semibold block text-[10px] text-muted-foreground uppercase">
                        {language === 'es' ? 'Nro. Operación' : 'Operation No.'}
                      </span>
                      <span className="text-foreground font-mono font-bold">{reserva.garantia_devolucion_nro_operacion || 'N/A'}</span>
                    </div>
                    {reserva.garantia_devolucion_fecha && (
                      <div className="col-span-2">
                        <span className="font-semibold block text-[10px] text-muted-foreground uppercase">
                          {language === 'es' ? 'Fecha Reembolso' : 'Refund Date'}
                        </span>
                        <span className="text-foreground">{formatDate(reserva.garantia_devolucion_fecha)}</span>
                      </div>
                    )}
                    {reserva.garantia_devolucion_constancia_url && (
                      <div className="col-span-2 mt-1">
                        <Button variant="outline" size="sm" className="w-full text-[11px] h-8" asChild>
                          <a href={reserva.garantia_devolucion_constancia_url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-1.5">
                            <Icons.Eye className="h-3.5 w-3.5" /> {language === 'es' ? 'Ver Constancia Reembolso' : 'Ver Constancia Reembolso'}
                          </a>
                        </Button>
                      </div>
                    )}
                    {reserva.garantia_devolucion_diferencia_evidencia_url && (
                      <div className="col-span-2 mt-1">
                        <Button variant="outline" size="sm" className="w-full text-[11px] h-8 text-red-500 hover:text-red-600 hover:bg-red-50/20 border-red-200" asChild>
                          <a href={reserva.garantia_devolucion_diferencia_evidencia_url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-1.5">
                            <Icons.Eye className="h-3.5 w-3.5 text-red-500" /> {language === 'es' ? 'Ver Evidencia Multa / Daño' : 'Ver Evidencia Multa / Daño'}
                          </a>
                        </Button>
                      </div>
                    )}
                    {reserva.garantia_devolucion_diferencia_motivo && (
                      <div className="col-span-2 mt-1 p-2 bg-red-50/50 rounded-lg border border-red-100 text-red-900">
                        <span className="font-semibold block text-[9px] text-red-700 uppercase">
                          {language === 'es' ? 'Motivo del descuento' : 'Discount Reason'}
                        </span>
                        <span className="text-xs leading-normal">{reserva.garantia_devolucion_diferencia_motivo}</span>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="gap-2 pt-3 px-4 md:px-5 border-t border-slate-50 mt-1 flex-col">
        {!canCancel && (reserva.estado === 'SOLICITADO' || reserva.estado === 'CONFIRMADO') && (
          <div className="w-full flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 text-[11px] text-amber-700">
            <Icons.AlertTriangle className="h-3.5 w-3.5 mt-0.5 flex-shrink-0 text-amber-500" />
            <span>
              {hasVoucher 
                ? (language === 'es' 
                    ? "No puedes cancelar una reserva con pago registrado. Contacta al administrador." 
                    : "You cannot cancel a reservation with a registered payment. Contact the administrator.")
                : (language === 'es' 
                    ? `Cancelación disponible con más de ${cancelDays} días de anticipación.` 
                    : `Cancellation available with more than ${cancelDays} days in advance.`)}
            </span>
          </div>
        )}
        {onUploadVoucher && reserva.pago_diferido && reserva.pago_estado_validacion === 'pendiente' && (
          <Button 
            onClick={onUploadVoucher}
            className="w-full min-h-[48px] md:min-h-0 md:h-10 rounded-[1rem] md:rounded-xl bg-orange-500 text-white hover:bg-orange-600 border-none font-black uppercase text-[10px] md:text-xs tracking-wider mb-1 shadow-md hover:shadow-lg transition-all"
          >
            <Icons.Upload className="mr-2 h-4 w-4" /> {language === 'es' ? 'Subir Comprobante' : 'Upload Receipt'}
          </Button>
        )}
        <Button 
          variant="destructive" 
          onClick={handleCancelClick}
          className="w-full min-h-[48px] md:min-h-0 md:h-10 rounded-[1rem] md:rounded-xl bg-red-50 text-red-600 hover:bg-red-100 border-none font-black uppercase text-[10px] md:text-xs tracking-wider disabled:opacity-40"
          disabled={!canCancel}
        >
          <Icons.Trash2 className="mr-2 h-4 w-4" /> {t('cancelReservationButton')}
        </Button>
      </CardFooter>
    </Card>
  );
}
