import type { ReactNode } from 'react';
import { Button } from '@/components/ui/button';
import { Icons } from '@/components/icons';

interface PageTitleProps {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  onBack?: () => void;
}

export function PageTitle({ title, subtitle, actions, onBack }: PageTitleProps) {
  return (
    <div className="mb-1.5 md:mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div className="flex items-center gap-3 w-full sm:w-auto">
        {onBack && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="h-9 w-9 rounded-full border border-slate-200/60 dark:border-slate-800/60 bg-white/80 dark:bg-slate-900/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white shadow-sm shrink-0 transition-all duration-200 active:scale-95"
            aria-label="Volver"
          >
            <Icons.ChevronLeft className="h-5 w-5 stroke-[2.5]" />
          </Button>
        )}
        <div className="space-y-0.5">
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold font-headline text-foreground tracking-tight leading-tight">{title}</h1>
          {subtitle && <p className="text-sm text-muted-foreground font-medium">{subtitle}</p>}
        </div>
      </div>
      {actions && (
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto mt-2 sm:mt-0 [&>div]:flex-wrap [&>div]:justify-start sm:[&>div]:justify-end [&>div]:w-full sm:[&>div]:w-auto">
          {actions}
        </div>
      )}
    </div>
  );
}
