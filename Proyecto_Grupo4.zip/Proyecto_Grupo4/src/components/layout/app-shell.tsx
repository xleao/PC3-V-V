
"use client";

import type { ReactNode } from 'react';
import { Sidebar } from './sidebar';
import { Header } from './header';
import { useAuth } from '@/contexts/auth-context';
import { useCondominioContext } from '@/contexts/condominio-context';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import React, { useState, useEffect } from 'react';
import { LoadingState } from '@/components/shared/loading-state';
import { db } from '@/lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { Icons } from '@/components/icons';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { CriticalAnnouncementPopup } from '@/components/condominios/anuncios/critical-announcement-popup';
import { usePermissions } from '@/hooks/use-permissions';
import { getRequiredPermissionForPath } from '@/lib/route-permissions';
import { useFCM } from '@/hooks/use-fcm';
import { useUserActivityTracker } from '@/hooks/use-user-activity-tracker';
import { EditProfileDialog } from '@/components/profile/edit-profile-dialog';

interface AppShellProps {
  children: ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const { isAuthenticated, user, authLoading } = useAuth();
  const { selectedCondominio, isLoading: condoContextIsLoading, setSelectedCondominio } = useCondominioContext();
  const pathname = usePathname();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { hasPermission, isLoadingPermissions } = usePermissions();

  // Registrar dispositivo en FCM para notificaciones push
  useFCM();

  // Habilitar el rastreo de actividad de usuarios
  useUserActivityTracker();

  const [isVerifyingAccess, setIsVerifyingAccess] = useState(false);
  const [hasAccess, setHasAccess] = useState<boolean | null>(null);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);

  const publicPaths = ['/login', '/presentacion', '/demo'];
  const isPublicPath = publicPaths.includes(pathname) || pathname.startsWith('/__');
  const isGuestHome = pathname === '/' && !isAuthenticated;

  // Rutas que requieren privilegios de superadministrador global
  const systemAdminPaths = [
    '/roles',
    '/roles-plantilla',
    '/permissions',
    '/funcionalidades',
    '/usuarios-sistema',
    '/condominios',
    '/condominios/importar',
    '/admin',
    '/audit-log',
    '/debug',
  ];
  const isSystemAdminPath = systemAdminPaths.some(p => {
    if (p === '/condominios') {
      const pathSegments = pathname.split('/').filter(Boolean);
      // '/condominios' y '/condominios/importar' son de superadmin,
      // pero las subrutas específicas de condominio (e.g. '/condominios/v1-001...') no lo son.
      if (pathname === '/condominios' || (pathname.startsWith('/condominios/') && pathSegments[1] === 'importar')) {
        return true;
      }
      return false;
    }
    return pathname === p || pathname.startsWith(p + '/');
  });

  useEffect(() => {
    if (authLoading || condoContextIsLoading) return;

    // 1. Redirigir si no está autenticado
    if (!isAuthenticated && !isPublicPath && pathname !== '/') {
      router.push('/login');
      return;
    }

    // 1.1 Redirigir si intenta entrar a una ruta de superadmin sin privilegios
    if (isSystemAdminPath && isAuthenticated && !user?.isSystemAdmin) {
      router.push('/');
      return;
    }

    // 2. Lógica de validación de acceso a condominios y sincronización del contexto
    const checkCondoAccess = async () => {
      const pathSegments = pathname.split('/').filter(Boolean);
      const isCondoPath = pathSegments[0] === 'condominios' && pathSegments.length > 1 && pathSegments[1] !== 'importar';
      const condoIdFromUrl = isCondoPath ? pathSegments[1] : null;

      if (isAuthenticated && user && condoIdFromUrl) {
        // Si ya tenemos el mismo condominio verificado y cargado en el estado actual, evitamos re-verificar
        if (selectedCondominio?.id === condoIdFromUrl && hasAccess === true) {
          return;
        }

        setIsVerifyingAccess(true);
        try {
          let allowed = false;
          if (user.isSystemAdmin) {
            allowed = true;
          } else {
            const userInCondoRef = doc(db, 'condominios', condoIdFromUrl, 'usuarios', user.email!.toLowerCase());
            const userInCondoSnap = await getDoc(userInCondoRef);
            if (userInCondoSnap.exists()) {
              allowed = true;
            }
          }

          if (allowed) {
            // Sincronizar el contexto con el condominio correspondiente antes de permitir el paso
            if (!selectedCondominio || selectedCondominio.id !== condoIdFromUrl) {
              const condoRef = doc(db, 'condominios', condoIdFromUrl);
              const condoSnap = await getDoc(condoRef);
              if (condoSnap.exists()) {
                const condoData = condoSnap.data();
                setSelectedCondominio({
                  id: condoSnap.id,
                  nombre: condoData.nombre || '',
                  imageUrl: condoData.imageUrl || '',
                  moneda: condoData.moneda || 'S/',
                  chatbot_ia_activo: condoData.chatbot_ia_activo ?? condoData.chatbotIaActivo ?? false
                });
              } else {
                setHasAccess(false);
                setIsVerifyingAccess(false);
                return;
              }
            }
            setHasAccess(true);
          } else {
            setHasAccess(false);
          }
        } catch (error) {
          console.error("Error verifying condo access:", error);
          setHasAccess(false);
        } finally {
          setIsVerifyingAccess(false);
        }
      } else {
        setHasAccess(true); // No es una ruta de condominio, permitir paso
      }
    };

    checkCondoAccess();

    // 3. Sincronización de contexto (seleccionado vs URL) - Solo se evalúa si ya tenemos hasAccess verificado
    if (isAuthenticated && !isPublicPath && hasAccess === true) {
      const pathSegments = pathname.split('/').filter(Boolean);
      const isCondoSpecificPath = pathSegments[0] === 'condominios' && pathSegments.length > 1 && pathSegments[1] !== 'importar';

      // Si navegamos completamente fuera de la sección de condominios, reseteamos el contexto
      if (!isCondoSpecificPath && selectedCondominio) {
        setSelectedCondominio(null);
      }
    }

  }, [isAuthenticated, user, authLoading, selectedCondominio, condoContextIsLoading, pathname, router, setSelectedCondominio, isPublicPath, hasAccess]);

  useEffect(() => {
    if (authLoading || isPublicPath || !isAuthenticated || !user?.email || !user?.displayName) return;

    const emailPrefix = user.email.split('@')[0];
    const isDefaultName = user.displayName.toLowerCase().trim() === emailPrefix.toLowerCase().trim();

    if (isDefaultName) {
      setIsOnboardingOpen(true);
    } else {
      setIsOnboardingOpen(false);
    }
  }, [user, authLoading, isAuthenticated, isPublicPath]);

  // Pantalla de carga global
  const isNavigatingAfterLogin = isAuthenticated && pathname === '/login';

  // Route Permission Validation
  const requiredPermission = getRequiredPermissionForPath(pathname, searchParams);

  if (authLoading || (!isPublicPath && !isGuestHome && condoContextIsLoading) || isVerifyingAccess || isNavigatingAfterLogin) {
    return <LoadingState fullPage message="Verificando seguridad..." />;
  }

  // Si requiere un permiso específico pero los permisos aún están cargando, bloqueamos el render
  if (requiredPermission && isLoadingPermissions) {
    return <LoadingState fullPage message="Verificando permisos..." />;
  }

  // Bloquear renderizado de contenido protegido mientras se redirige
  if (isSystemAdminPath && isAuthenticated && !user?.isSystemAdmin) {
    return <LoadingState fullPage message="Redirigiendo..." />;
  }

  if (requiredPermission && hasAccess === true) {
    let hasAccessToRoute = false;
    if (Array.isArray(requiredPermission)) {
      hasAccessToRoute = requiredPermission.some(p => hasPermission(p));
    } else {
      hasAccessToRoute = hasPermission(requiredPermission);
    }

    if (!hasAccessToRoute) {
      return (
        <div className="flex h-screen items-center justify-center bg-background p-6">
          <Card className="max-w-md w-full shadow-2xl border-destructive/20">
            <CardHeader className="text-center">
              <div className="mx-auto bg-destructive/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Icons.ShieldAlert className="h-8 w-8 text-destructive" />
              </div>
              <CardTitle className="text-destructive font-headline text-2xl">Acceso Denegado</CardTitle>
              <CardDescription className="text-base mt-2">
                Privilegios insuficientes
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-muted-foreground mb-6 text-sm">
                Tu rol actual no tiene los permisos necesarios para ver o modificar esta sección.
              </p>
              <Button onClick={() => router.push(`/condominios/${selectedCondominio?.id || ''}`)} className="w-full font-bold">
                <Icons.ChevronLeft className="mr-2 h-4 w-4" />
                Volver al Inicio
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }
  }

  // Manejo de Landing Page y Login (sin Sidebar/Header)
  if (isPublicPath || isGuestHome) {
    if ((pathname === '/' && isAuthenticated) || pathname === '/presentacion') {
      // Continuar al layout estándar si está autenticado en la raíz o es la presentación
    } else {
      return <>{children}</>;
    }
  }

  // Si se denegó el acceso a un condominio específico
  if (hasAccess === false) {
    return (
      <div className="flex h-screen items-center justify-center bg-background p-6">
        <Card className="max-w-md w-full shadow-2xl border-destructive/20">
          <CardHeader className="text-center">
            <div className="mx-auto bg-destructive/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
              <Icons.Lock className="h-8 w-8 text-destructive" />
            </div>
            <CardTitle className="text-destructive font-headline text-2xl">Acceso Denegado</CardTitle>
            <CardDescription className="text-base mt-2">
              No estás registrado en este condominio.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-muted-foreground mb-6 text-sm">
              Tu cuenta no tiene permisos para ver la información de este edificio. Contacta al administrador si crees que es un error.
            </p>
            <Button onClick={() => router.push('/')} className="w-full font-bold">
              <Icons.ChevronLeft className="mr-2 h-4 w-4" />
              Volver al Inicio
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex flex-1 flex-col overflow-hidden relative">
        <Header />
        <main className="flex-1 overflow-y-auto scroll-pb-72 px-3 pt-3 pb-24 md:px-4 md:pt-6 md:pb-16 lg:px-12 lg:pt-8 lg:pb-16 bg-[#f2fcfb]">
          <div className="w-full h-full max-w-[1600px] mx-auto">
            {children}
          </div>
        </main>
      </div>

      {selectedCondominio && (
        <CriticalAnnouncementPopup condoId={selectedCondominio.id} />
      )}

      <EditProfileDialog
        isOpen={isOnboardingOpen}
        onOpenChange={setIsOnboardingOpen}
        isForceOnboarding={true}
      />
    </div>
  );
}
