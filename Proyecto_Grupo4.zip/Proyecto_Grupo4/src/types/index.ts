
import { Timestamp, FieldValue } from 'firebase/firestore';
export type { Timestamp, FieldValue };

export interface Role {
  id: string;
  name: string;
  description: string;
  permissions: string[]; // Array of permission keys
}

export interface Feature {
  id: string;
  name: string;
  description: string;
  grouperId: string | null;
  fecha_modificacion?: Timestamp;
  usuario_modificacion?: string;
}

export interface Condominio {
  id: string; // Firestore document ID
  nombre: string;
  description: string;
  moneda: string;
  imageUrl?: string;
  direccion?: string;
  detalles_bancarios?: string;
  comunicado_recibo?: string;
  logo_empresa?: string;
  firma_administradora?: string;
  nombre_administradora?: string;
  auditLogEnabled?: boolean; // New: Toggle for audit logging
  activityTrackingEnabled?: boolean;
  activityTrackingStart?: string;
  activityTrackingEnd?: string;
  chatbot_ia_activo?: boolean;
  chatbotIaActivo?: boolean;
  fecha_modificacion?: Timestamp;
  usuario_modificacion?: string;
}

export interface Departamento {
  id: string; // User-defined ID, e.g., "A1", "B102", which is the Firestore document ID
  torre: string;
  piso?: string;
  dueño_nombre: string;
  dueño_correo: string;
  dueño_celular?: string;
  dueño_telefono?: string;
  dueño_dni?: string;
  habitado: boolean;
  alquilado: boolean;
  area_m2?: number;
  porcentaje_participacion?: number;
  votantes_autorizados?: string[];
  correos_notificaciones?: string[];
  fecha_actualizacion?: Timestamp;
  usuario_modificacion?: string;
  saldo_actual?: number;
  grupo_escala_precios?: string;
}

export interface Estacionamiento {
  id: string; // Document ID (usually space name or auto-gen)
  departamento_id: string; // Associated department ID
  nro_sotano: string;
  nombre_espacio: string;
  area_m2: number;
  porcentaje_participacion?: number;
  fecha_actualizacion?: Timestamp;
  usuario_modificacion?: string;
}

export interface Deposito {
  id: string; // Document ID
  departamento_id: string; // Associated department ID
  nro_sotano: string;
  nombre_espacio: string;
  area_m2: number;
  porcentaje_participacion?: number;
  fecha_actualizacion?: Timestamp;
  usuario_modificacion?: string;
}

export interface EspacioComun {
  id: string; // Firestore auto-generated ID
  nombre: string;
  ubicacion: string;
  capacidad: number;
  aforo: number;
  costo_alquiler: number;
  moneda: string;
  se_puede_alquilar: boolean;
  requiere_aprobacion: boolean;
  modalidad_reserva?: 'DIA_COMPLETO' | 'POR_HORA';
  hora_apertura_general?: string; // e.g., "08:00"
  hora_cierre_general?: string; // e.g., "22:00"
  duracion_minima_reserva_minutos?: number; // e.g., 60 - relevante si modalidad_reserva es POR_HORA
  anticipacion_maxima_reserva_dias?: number; // e.g., 30
  permite_pago_pendiente?: boolean; // If true, users can reserve and pay later
  dias_espera_pago?: number; // Days allowed to complete payment before auto-release
  dias_anticipacion_cancelacion?: number; // Days in advance required to cancel (default: 5)
  requiere_garantia: boolean;
  importe_garantia: number | null;
  fecha_actualizacion?: Timestamp;
  usuario_modificacion?: string;
  tipo_tarifa?: 'FIJA' | 'ESCALONADA';
  tarifas_escalonadas?: {
    [escalaId: string]: {
      se_puede_alquilar: boolean;
      costo_alquiler: number;
      requiere_garantia: boolean;
      importe_garantia: number | null;
    }
  }
  grupoId?: string;
  grupoNombre?: string;
  politica_bloqueo?: 'INDEPENDIENTE' | 'BLOQUEO_MUTUO';
  isVirtualGroupCard?: boolean;
  ocultarReservasDia?: boolean;
  guiaPdfUrl?: string;
  guiaPdfName?: string;
  tieneMensajeGratuitoCustom?: boolean;
  mensajeGratuitoTitulo?: string;
  mensajeGratuitoDescripcion?: string;
}

export interface DisponibilidadEspacioComun {
  id?: string; // Firestore auto-generated ID for this availability rule
  espacioComunId: string; // FK to EspacioComun
  diasSemana: string[]; // e.g., ["LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES", "SABADO", "DOMINGO"]
  horaInicio: string; // e.g., "09:00"
  horaFin: string; // e.g., "11:00"
  tipoRecurrencia: 'UNICA_VEZ' | 'DIARIA' | 'SEMANAL';
  fechaInicio: Timestamp; // For UNICA_VEZ, it's the specific date. For DIARIA/SEMANAL, it's when the recurrence starts.
  fechaFin?: Timestamp | null; // For DIARIA/SEMANAL, when the recurrence ends (optional). Not used for UNICA_VEZ.
  permitirUsoCompartido: boolean; // Renamed from esCompartido: Admin sets if this slot CAN be booked Shared
  permitirUsoExclusivo: boolean; // Renamed from esExclusivo: Admin sets if this slot CAN be booked exclusively
  cobrarSoloSiEsExclusivo: boolean; // If true, rental cost is 0 for shared reservations
  fechaCreacion?: Timestamp;
  usuarioCreacion?: string;
  fechaModificacion?: Timestamp;
  usuarioModificacion?: string;
}

export interface ReservaEspacioComun {
  id?: string; // Firestore auto-generated ID
  condominioId: string;
  espacioComunId: string;
  espacioComunNombre: string; // Denormalized for easier display
  usuarioId: string; // UID of the user who made the reservation
  departamentoId?: string | null; // Optional, if user is linked to a department
  fechaHoraInicio: Timestamp;
  fechaHoraFin: Timestamp;
  estado: 'SOLICITADO' | 'CONFIRMADO' | 'RECHAZADO' | 'CANCELADO_USUARIO' | 'CANCELADO_ADMIN';
  motivoReserva?: string | null;
  costoReserva?: number;
  montoAlquiler?: number;
  montoGarantia?: number;
  monedaCosto?: string | null;
  esExclusivo: boolean; // Snapshot of exclusivity at time of booking

  pagoNroOperacion?: string | null;
  pagoConstanciaUrl?: string | null;
  pago_estado_validacion?: 'pendiente' | 'validado' | 'rechazado';
  pago_fecha_validacion?: Timestamp | FieldValue;
  pago_usuario_validacion?: string;
  periodo_ingreso_balance?: string;
  pago_diferido?: boolean;           // User chose to pay later
  pago_diferido_plazo_dias?: number; // Grace period in days
  pago_diferido_fecha_limite?: Timestamp; // Deadline to pay

  notasAdmin?: string;
  grupoReservaId?: string;
  dias_anticipacion_cancelacion?: number; // Denormalized from espacioComun at booking time
  fechaCreacion: Timestamp | FieldValue;
  fechaModificacion?: Timestamp | FieldValue;
  usuarioModificacion?: string; // UID of user who last modified

  fechaCancelacionUsuario?: Timestamp | FieldValue;
  usuarioCancelacion?: string;

  userEmail?: string;
  userDisplayName?: string | null;
  paymentValidatorEmail?: string;
  requiere_aprobacion?: boolean;
  garantia_estado?: 'pendiente' | 'devuelto' | 'no_aplica' | 'cancelado';
  garantia_devolucion_fecha?: any;
  garantia_devolucion_periodo?: string | null;
  garantia_devolucion_constancia_url?: string | null;
  garantia_devolucion_nro_operacion?: string | null;
  garantia_devolucion_cuenta_id?: string | null;
  garantia_devolucion_transaccion_id?: string | null;
  garantia_devolucion_notas?: string | null;
  garantia_devolucion_monto?: number;
  garantia_devolucion_original?: number;
  garantia_devolucion_diferencia?: number;
  garantia_devolucion_diferencia_motivo?: string | null;
  garantia_devolucion_diferencia_evidencia_url?: string | null;

  pago_devolucion_monto?: number;
  pago_devolucion_original?: number;
  pago_devolucion_diferencia?: number;
  pago_devolucion_fecha?: any;
  pago_devolucion_constancia_url?: string | null;
  pago_devolucion_usuario?: string;
  pago_devolucion_nro_operacion?: string | null;
  pago_devolucion_cuenta_id?: string | null;
  pago_devolucion_transaccion_id?: string | null;
  pago_devolucion_notas?: string | null;
  pago_devolucion_descuento_motivo?: string | null;
  pago_devolucion_descuento_evidencia_url?: string | null;
  historialCambios?: Array<{
    fecha: any;
    usuarioId: string | null;
    usuarioNombre: string;
    fechaHoraInicioAnterior: any;
    fechaHoraFinAnterior: any;
    fechaHoraInicioNueva: any;
    fechaHoraFinNueva: any;
    estadoAnterior: string;
    estadoNuevo: string;
    motivo: string;
  }>;
}


export interface CondoUser {
  id: string; // User's email, which is the document ID in the subcollection
  departamentos_asignados: string[];
  roles: Record<string, boolean>; // e.g., { administrador: true, inquilino: false }
  permisos?: Record<string, boolean>; // Union of all permissions from assigned roles
  fecha_creacion: Timestamp;
  usuario_creacion: string; // UID of user who performed the assignment
}

export interface TorreBloque {
  id: string; // User-defined ID, e.g., "A", "Bloque Norte"
  descripcion: string;
  usuario_delegado?: string | null;
  usuario_secretario?: string | null;
  usuario_tesorero?: string | null;
  fecha_actualizacion?: Timestamp;
  usuario_modificacion?: string;
}

export interface GrupoGasto {
  id: string;
  nombre: string;
  descripcion?: string;
  color?: string; // Hex code para gráficos
  orden?: number;
  es_sistema?: boolean;
  fecha_creacion: Timestamp | any;
  usuario_creacion: string;
}

export interface TipoGasto {
  id: string; // Firestore auto-generated ID
  nombre: string;
  descripcion: string;
  tipo_calculo:
  | 'total_unidades'
  | 'solo_habitadas'
  | 'solo_inhabitadas'
  | 'grupo_especifico'
  | 'monto_fijo_unidad'
  | 'por_torre_habitadas'
  | 'por_torre_inhabitadas'
  | 'por_torre_todas'
  | string;
  monto_fijo_valor?: number | null;
  torre_especifica_id?: string | null;
  unidades_especificas?: string[];
  factor_prorrateo_id?: string | null;
  grupo_id?: string; // Referencia a GrupoGasto
  grupo_nombre?: string; // Denormalizado para facilitar listados
  mostrar_descripcion_recibo?: boolean;
  tipo_cuota?: 'ordinaria' | 'extraordinaria';
  fecha_creacion: Timestamp | any;
  fecha_modificacion?: Timestamp;
  usuario_modificacion?: string;
}

export interface FeatureGrouper {
  id: string;
  name: string;
  fecha_modificacion?: Timestamp;
  usuario_modificacion?: string;
}

export interface RolPlantilla {
  id: string;
  name: string;
  description: string;
  es_rol_predeterminado: boolean;
  permissions: string[];
  fecha_modificacion?: Timestamp;
  usuario_modificacion?: string;
}


export interface GastoDetallesFirestore {
  monto: number;
  detalles?: string[];
  comprobantes?: string[];
  fecha_gasto?: Timestamp | FieldValue;
  fecha_creacion?: Timestamp | FieldValue;
  usuario_creacion?: string;
  fecha_modificacion?: Timestamp | FieldValue;
  usuario_modificacion?: string;
  factor_prorrateo_valor?: number;
  cuenta_id?: string;
  transaccion_id?: string;
}

export interface AsistenteProgresoPaso {
  completado: boolean;
  fecha?: Timestamp | FieldValue | any;
  detalles?: Record<string, any>;
}

export interface AsistenteProgreso {
  paso_1_periodo?: AsistenteProgresoPaso;
  paso_2_comprobantes?: AsistenteProgresoPaso;
  paso_3_factores?: AsistenteProgresoPaso;
  paso_4_cierre?: AsistenteProgresoPaso;
  paso_5_generacion?: AsistenteProgresoPaso;
  paso_6_publicacion?: AsistenteProgresoPaso;
  ultimo_paso_visitado?: number;
  ultima_actualizacion?: Timestamp | FieldValue | any;
}

export interface PeriodoBalanceFirestoreData {
  id?: string;
  ingresos?: Record<string, number>;
  ingresos_validados_del_periodo?: number; // Sum of validated maintenance payments recorded in this period
  ingresos_validados_reservas_ec?: number; // Sum of validated common area payments recorded in this period
  ingresos_manuales_totales?: number; // Pre-calculated sum of 'ingresos' record
  gastos?: Record<string, GastoDetallesFirestore>;
  total_gastos_calculados?: number; // Pre-calculated sum of all 'gastos' monto
  fecha_inicio?: Timestamp | FieldValue;
  fecha_fin?: Timestamp | FieldValue;
  esta_cerrado?: boolean;
  fecha_creacion?: Timestamp | FieldValue;
  usuario_creacion?: string;
  fecha_modificacion?: Timestamp | FieldValue;
  usuario_modificacion?: string;
  factores_por_departamento?: Record<string, Record<string, number>>;
  lecturas_agua_por_departamento?: Record<string, { anterior: number; actual: number }>;
  evidencias_prorrateo_por_departamento?: Record<string, Record<string, string>>; // factorId -> deptId -> url
  asistente_paso_actual?: number;
  asistente_progreso?: AsistenteProgreso;
  [key: string]: any;
}

export interface PeriodoBalance {
  id: string;
  fecha_inicio: Timestamp;
  fecha_fin: Timestamp;
  saldo_anterior: number;
  ingresos: number;
  ingresos_manuales: number;
  ingresos_validados_mantenimiento: number;
  ingresos_validados_reservas_ec: number;
  gastos: number;
  moneda: string;
  esta_cerrado: boolean;
  fecha_creacion?: Timestamp;
  usuario_creacion?: string;
  fecha_modificacion?: Timestamp;
  usuario_modificacion?: string;
  firestoreData: PeriodoBalanceFirestoreData;
}

export interface IngresoDetalleView {
  id: string;
  concepto: string;
  monto: number;
}

export interface GastoDetalleView {
  id: string;
  tipo_gasto_nombre: string;
  monto: number;
  detalles_gasto: string;
  comprobantes_urls?: string[];
}

export interface GastoFormData {
  tipo_gasto_id: string;
  monto: number | '';
  descripcion: string;
  fecha_gasto?: Date | null;
  comprobantes_urls_texto?: string;
  factor_prorrateo_valor?: number | string | null;
  periodo_id?: string; // Used in consolidated views
  cuenta_id: string;
}

export interface ProrationFactorPageData {
  [factorId: string]: {
    [departmentId: string]: number | '';
  };
}

export interface ActiveProrationFactorTab {
  id: string;
  displayName: string;
  tiposGastoAsociados: TipoGasto[];
}

export interface RegistroPago {
  id?: string; // Firestore auto-generated ID for this specific payment record
  condominioId: string; // Added for efficient filtering in validation page
  pago_fecha_registro: Timestamp | FieldValue; // Fecha en que el usuario registra el pago
  pago_fecha_efectiva: Timestamp; // Fecha en que el usuario dice que pagó
  pago_nro_operacion: string;
  pago_importe: number;
  pago_importe_principal?: number;
  pago_importe_mora?: number;
  pago_importe_excedente?: number;
  pago_constancia_url?: string; // URL de la imagen de la constancia
  pago_estado_validacion: 'pendiente' | 'validado' | 'rechazado';
  pago_usuario_registro: string; // UID del usuario que registró el pago

  pago_fecha_validacion?: Timestamp | FieldValue; // Fecha en que el admin valida/rechaza
  pago_usuario_validacion?: string; // UID del admin que való/rechazó
  pago_observaciones_validacion?: string; // Comentarios del admin
  periodo_ingreso_balance?: string; // ID of the balance period where this payment was accounted for as income
  moneda_estado_cuenta?: string; // Added for context in views

  // Trazabilidad Bancaria (Requerimiento 003)
  transaccion_id?: string; // ID del movimiento generado en la cuenta bancaria
  esta_conciliado?: boolean; // Bloqueador de edición si ya fue conciliado
  cuenta_id?: string; // Cuenta donde se depositó el dinero

  // Trazabilidad de usuario que registró el pago
  registrado_por_email?: string; // Email del usuario que registró el pago
  registrado_por_nombre?: string; // Nombre del usuario que registró el pago
}

export interface AjusteRecibo {
  id: string;
  concepto: string;
  monto: number;
  motivo: string;
  url_sustento?: string;
  fecha: Timestamp | Date;
  usuario_id: string;
  usuario_nombre?: string;
}

export interface EstadoCuentaDepartamento {
  id?: string; // El mismo que el periodoId, ej: "2025-05"
  condominioId?: string; // Denormalized
  departamentoId?: string; // Denormalized
  dueño_nombre?: string; // Denormalized
  propietario_nombre?: string; // Denormalized / Consolidated
  propietario_correo?: string;
  propietario_telefono?: string;
  propietario_dni?: string;
  departamento_piso?: string;
  departamento_area?: number;
  departamento_participacion?: number;
  periodo_nombre?: string; // Legado: solo lectura para compatibilidad con recibos anteriores
  torre?: string; // Denormalized
  detalle_gastos: Record<string, number>; // tipoGastoId -> monto_asignado_al_dpto
  estado: string; // ej: "Pendiente de pago", "Pagado", "Vencido"
  fecha_emision: Timestamp;
  fecha_vencimiento: Timestamp;
  moneda: string;
  periodo: string; // ej: "2025-05"
  total: number; // Suma de todos los montos en detalle_gastos
  fecha_creacion?: Timestamp;
  usuario_creacion?: string; // UID del usuario que generó el estado de cuenta
  ajustes?: AjusteRecibo[]; // Lista de ajustes manuales aplicados al recibo
  isPublished?: boolean; // Si es true, el recibo es visible para el residente
  fecha_publicacion?: Timestamp; // Fecha y hora en que se publicó el recibo
  total_pagado_validado?: number; // Suma de todos los pagos validados para este estado de cuenta.
  tienePagosPendientesValidacion?: boolean; // Indicador si hay pagos en subcolección pendientes de validar
  montoPendienteDePago?: number; // Campo calculado: total - total_pagado_validado
  montoPendienteDeValidacion?: number; // Campo calculado: suma de importes de pagos pendientes
  tipo_generacion?: 'automatico' | 'migracion' | string; // Para identificar si fue generado masivamente o por migración

  // Nuevos campos para trazabilidad de mora y principal
  total_principal?: number;
  total_mora?: number;
  pendiente_principal?: number;
  pendiente_mora?: number;
  total_recibo?: number;
  total_credito?: number;

  // Campos para exoneración de moras
  exonerado_mora?: boolean;
  motivo_exoneracion?: string;
  monto_mora_exonerada?: number;
  fecha_exoneracion_mora?: any;
  historial_motivo_exoneracion?: Array<{
    motivo: string;
    fecha: any;
    usuario_uid: string;
    usuario_nombre: string;
  }>;


  // Campos LEGADOS (la información de pago ahora está en la subcolección `registros_pago`)
  // Mantener por retrocompatibilidad o hasta migración completa
  pago_fecha_registro?: Timestamp;
  pago_fecha_efectiva?: Timestamp;
  pago_nro_operacion?: string;
  pago_importe?: number;
  pago_constancia_url?: string;
  pago_estado_validacion?: 'pendiente' | 'validado' | 'rechazado';
  pago_usuario_registro?: string;
  pago_fecha_validacion?: Timestamp;
  pago_usuario_validacion?: string;
  pago_observaciones_validacion?: string;
  nro_recibo?: string; // Número de recibo legible (ej: REC-000008)
  email_notificacion?: {
    enviado: boolean;
    status?: 'success' | 'error' | 'sending';
    fecha: Timestamp;
    error?: string | null;
  };
}

export interface Solicitud {
  id?: string;
  condominioId: string;
  usuarioId: string;
  departamentoId: string | null;
  asunto: string;
  descripcion: string;
  categoria: 'MANTENIMIENTO' | 'SUGERENCIA' | 'QUEJA' | 'REQUERIMIENTO' | 'OTROS';
  prioridad: 'BAJA' | 'MEDIA' | 'ALTA' | 'CRITICA';
  estado: 'ABIERTA' | 'EN_PROCESO' | 'RESUELTA' | 'CERRADA';
  fechaCreacion: Timestamp | FieldValue;
  fechaModificacion?: Timestamp | FieldValue;
  usuarioModificacion?: string;
  respuestaAdmin?: string | null;
  evidenciaUrl?: string | null;
  evidenciasUrls?: string[] | null;
  sustentoCierreUrl?: string | null;
  sustentoCierreTipo?: 'image' | 'pdf' | null;
  originalSolicitudId?: string | null;
  motivoCierre?: 'RESUELTA' | 'DUPLICADO' | null;
  involucradosIds?: string[];
  seguidores?: { usuarioId: string; usuarioNombre: string; departamentoId: string | null; fechaUnion: Timestamp }[];
  esPrivado?: boolean;
}

export interface MensajeSolicitud {
  id?: string;
  texto: string;
  usuarioId: string;
  usuarioNombre: string;
  fechaEnvio: Timestamp | FieldValue;
  esAdmin: boolean;
  imagenUrl?: string | null;
}

export interface ProyectoCondominio {
  id?: string;
  title: string;
  description: string;
  status: 'IN_PROGRESS' | 'PLANNED' | 'COMPLETED';
  category: 'REMODELING' | 'INFRASTRUCTURE' | 'AMENITIES' | 'SECURITY' | 'MAINTENANCE';
  progress: number;
  startDate: Timestamp;
  endDate: Timestamp;
  budget: number;
  moneda: string;
  imageUrl?: string;
  fecha_creacion: Timestamp | FieldValue;
  usuario_creacion: string;
  fecha_modificacion: Timestamp | FieldValue;
  usuario_modificacion: string;
}

export interface ReporteSeguimiento {
  id?: string;
  fechaReporte: Timestamp;
  progreso: number;
  montoInvertido: number;
  comentarios?: string | null;
  fecha_creacion: Timestamp | FieldValue;
  usuario_creacion: string;
}

export interface AuditLogEntry {
  id?: string;
  action: string;
  user: string;
  userEmail: string;
  module: string;
  details: string;
  timestamp: Timestamp | FieldValue;
  type: 'create' | 'update' | 'delete' | 'validate' | 'system' | 'auth';
}

export interface Visita {
  id?: string;
  condominioId: string;
  usuarioId: string; // UID del residente que registró la visita
  departamentoId: string;
  visitante_documento: string;
  visitante_nombre: string;
  visitante_apellido: string;
  tipo_visita: 'FECHA_ESPECIFICA' | 'RANGO_FECHAS' | 'PERMANENTE';
  fecha_inicio?: Timestamp | null;
  fecha_fin?: Timestamp | null;
  qr_codigo: string; // Token único generado para el QR
  codigo_acceso?: string; // Código numérico de 6 dígitos para ingreso manual
  estado: 'ACTIVA' | 'REVOCADA' | 'CADUCADA' | 'ELIMINADA';
  accesos_registrados: number; // Para saber si ya se usó y bloquear borrado
  esta_borrado?: boolean;
  es_registro_manual?: boolean;
  motivo_eliminacion?: string;
  fecha_creacion: Timestamp | FieldValue;
  usuario_creacion: string;
  fecha_modificacion?: Timestamp | FieldValue;
  usuario_modificacion?: string;
  acompanantes?: {
    nombre: string;
    apellido: string;
    es_menor: boolean;
    documento?: string;
  }[];
}

export interface AccesoVisita {
  id?: string;
  visitaId: string;
  condominioId: string;
  fecha_acceso: Timestamp | FieldValue;
  tipo_acceso: 'ENTRADA' | 'SALIDA';
  guardiaId: string; // UID del administrador/guardia que escaneó/registró el acceso
  visitante_nombre: string; // Denormalizado para reportes rápidos
  visitante_documento: string;
  departamentoId: string;
}

export type NotificationType = 'info' | 'success' | 'warning' | 'error' | 'project' | 'payment' | 'reservation' | 'visit' | 'ticket' | 'announcement' | 'global';

export interface AppNotification {
  id: string;
  condominioId?: string;
  userId: string; // Target user
  title: string;
  message: string;
  type: NotificationType;
  link?: string; // Optional URL to redirect (e.g., to the specific payment or project)
  isRead: boolean;
  fecha_creacion: Timestamp;
  metadata?: Record<string, any>; // Extra info like projectId, paymentId, etc.
}

export interface NotificationChannelSettings {
  app: boolean;
  email: boolean;
  push: boolean;
}

export interface CondoNotificationSettings {
  projects: NotificationChannelSettings;
  payments: NotificationChannelSettings;
  reservations: NotificationChannelSettings;
  visits: NotificationChannelSettings;
  tickets: NotificationChannelSettings;
  announcements: NotificationChannelSettings;
}

export interface UserNotificationSettings extends Partial<CondoNotificationSettings> {
  // Banderas planas de compatibilidad previa
  recibosEmail?: boolean;
  recibosPush?: boolean;
  reservasWhatsApp?: boolean;
  reservasPush?: boolean;
  paquetesPush?: boolean;
  comunicadosPush?: boolean;
}

export interface ComprobantePago {
  id: string; // Document ID
  ruc: string;
  razonSocial: string;
  importeTotal: number;
  igv: number;
  concepto: string;
  totalPagado: number;
  numeroRecibo: string;
  fechaEmision: Timestamp | Date;
  estadoPago: 'PAGADO' | 'PENDIENTE' | 'PARCIAL' | 'CONCILIADO' | 'PROVISIÓN';
  deudaRestante: number;
  archivoUrl: string;
  archivoTipo?: string;
  condominioId: string;

  periodoId?: string;
  tipoGastoId?: string;

  // Fase 2 y 4: Gasto Previsto y Conciliación
  tipoComprobante?: TipoComprobante;
  esPrevisto?: boolean;
  montoPresupuestado?: number;
  gastoPrevistoOriginalId?: string;
  conciliado?: boolean;
  esReversion?: boolean;
  reversionDocId?: string;
  comprobanteRealId?: string;
  diferencia_conciliacion?: number;
  fecha_conciliacion?: Timestamp | FieldValue;
  usuario_conciliacion?: string;

  // Nuevos campos para Aplicación de Provisiones parciales/múltiples
  monto_aplicado_acumulado?: number;
  monto_remanente?: number;
  aplicado_a_provision?: boolean;
  provisiones_aplicadas?: { provisionId: string; montoAplicado: number }[];
  facturas_aplicadas?: { facturaRealId: string; montoAplicado: number; fecha: Timestamp | Date }[];

  fecha_creacion: Timestamp | FieldValue;
  usuario_creacion: string;
  // Enlace a Mantenimientos y Órdenes de Trabajo
  mantenimiento_id?: string;
  mantenimiento_titulo?: string;
  pagos?: {
    fecha: Timestamp | Date;
    monto: number;
    metodo?: string;
    comprobantePagoUrl?: string;
    periodo_id?: string;
    transaccion_id?: string;
    cuenta_id?: string;
    descripcion?: string;
    conciliado_a_comprobante_id?: string;
    heredado_de_provision_id?: string;
  }[];
}

// --- MÓDULO DE CUENTAS (CASH/BANKS) ---

export interface Cuenta {
  id: string; // Firestore document ID
  nombre: string;
  tipo: 'caja_chica' | 'banco' | 'fondo';
  saldo_actual: number;
  moneda: string;
  responsable_id?: string; // UID del encargado
  fecha_creacion: Timestamp | FieldValue;
  usuario_creacion: string;
  fecha_actualizacion?: Timestamp | FieldValue;
  usuario_modificacion?: string;
}

export interface CuentaTransaccion {
  id: string; // Firestore document ID
  cuenta_id: string;
  monto: number; // Siempre positivo, el tipo_operacion define suma o resta
  tipo_operacion: 'ingreso' | 'egreso';
  fecha_transaccion: Timestamp | Date;
  categoria: string;
  descripcion: string;
  voucher_url?: string; // URL del comprobante
  usuario_registro: string; // UID de quien registró
  pago_id?: string; // ID del registro de pago o reserva asociado
  fecha_creacion: Timestamp | FieldValue;
  esta_conciliado?: boolean;
  conciliacion_id?: string;
  notas_conciliacion?: string;
  num_operacion?: string;
  period_id?: string;
  periodo_id?: string;
  fecha_original?: Timestamp | Date;
  periodo_original_id?: string;
  historial_traslados?: Array<{
    fecha_traslado: Timestamp;
    fecha_origen: Timestamp | Date;
    fecha_destino: Timestamp;
    motivo: string;
    usuario_email: string;
  }>;
}

// --- CONCILIACIÓN BANCARIA ---

export interface MovimientoBanco {
  id: string; // Firestore document ID
  cuenta_id: string;
  fecha: Timestamp | Date;
  descripcion: string;
  monto: number;
  tipo: 'ingreso' | 'egreso';
  referencia?: string;
  esta_conciliado: boolean;
  conciliacion_id?: string;
  notas?: string;
  periodoId?: string;
  fecha_carga: Timestamp | FieldValue;
  num_op?: string;
  usuario_carga: string;
  periodo_id: string; // ej: "2024-04" para facilitar filtrado
}

export interface ConciliacionBancaria {
  id: string; // Firestore document ID
  condominioId: string;
  cuentaId: string;
  movimiento_banco_id: string;
  transaccion_app_id: string;
  fecha_conciliacion: Timestamp | FieldValue;
  usuario_conciliacion: string;
  notas?: string;
}

// --- GESTIÓN DE PROVEEDORES (Requerimiento 004) ---

export interface ProveedorMaestro {
  id: string; // RUC o DNI (usado como ID único)
  nombre_fiscal: string;
  nombre_comercial?: string;
  tipo_documento: 'RUC' | 'DNI' | 'CE' | 'Pasaporte' | 'Otros';
  direccion_fiscal?: string;
  categorias: string[]; // Lista de categorías acumuladas de diversos condominios
  estado_global: 'activo' | 'bloqueado';
  fecha_creacion: Timestamp | FieldValue;
  usuario_creacion?: string;
}

export interface ProveedorDetalleBanco {
  id: string; // UUID local
  alias: string;
  banco_id: string;
  moneda: 'PEN' | 'USD';
  tipo_cuenta: 'Ahorros' | 'Corriente' | 'Detracciones' | 'Otros';
  nro_cuenta: string;
  cci: string;
  titular: string;
}

export interface ProveedorCondoData {
  id: string; // FK to ProveedorMaestro.id (RUC/DNI)
  categorias: string[]; // Lista de categorías asignadas localmente en este condominio
  condicion_pago?: string;
  detalles_bancarios: ProveedorDetalleBanco[];
  contactos_locales: {
    id: string;
    nombre: string;
    correo?: string;
    telefono?: string;
    cargo?: string;
  }[];
  estado_local: 'activo' | 'bloqueado';
  usuario_vinculacion: string;
  fecha_vinculacion: Timestamp | FieldValue;
  fecha_actualizacion?: Timestamp | FieldValue;
  usuario_modificacion?: string;
}

export interface CategoriaProveedor {
  id: string;
  nombre: string;
  es_global: boolean; // true si es maestro, false si es de condominio
  condominioId?: string; // Solo si es_global es false
  fecha_creacion: Timestamp | FieldValue;
}

export interface ContactConfig {
  receptionPhone?: string;
  receptionAnexo?: string;
  whatsappNumber?: string;
  emergencyPolice?: string;
  emergencyFire?: string;
  emergencyAmbulance?: string;
  emergencySecurity?: string;
  meetings?: any[];
  shifts?: { name: string; staff: string; hours: string; photoUrl?: string | null; }[];
  boardMembers?: { position: string; name: string; }[];
  boardEmail?: string;
  staffDay?: string;
  staffNight?: string;
  realEstateName?: string;
  realEstateRuc?: string;
  realEstatePosition?: string;
  realEstateEmail?: string;
  realEstateContactName?: string;
  realEstateCustomerServiceEmail?: string;
  realEstateCustomerServiceNote?: string;
  whatsappLink?: string;
}

// --- GESTIÓN DE PRESUPUESTO ANUAL (Requerimiento 010) ---

export interface PartidaPresupuestoAnual {
  nombreGasto: string;
  frecuencia: 'mensual' | 'bimestral' | 'trimestral' | 'semestral' | 'anual' | 'ad_hoc';
  montoTotalAnual: number;
  distribucion: Record<number, number>; // mes (1-12) -> monto
}

export interface IngresoExtraordinarioPresupuesto {
  monto: number;
  concepto: string;
}

export interface PresupuestoAnual {
  id?: string;                          // Document ID (the year, e.g. "2026")
  anio: number;
  saldo_inicial_caja: number;           // Capital de trabajo inicial (1 de Enero)
  recaudacion_mensual_sugerida: number; // (Suma Egresos Anual - Saldo Inicial) / 12 o simple (Egresos Anual / 12)
  recaudacion_planificada: Record<number, number>; // mes (1-12) -> monto a recaudar
  ingresos_extraordinarios: Record<number, IngresoExtraordinarioPresupuesto[]>; // mes (1-12) -> lista de cobros extraordinarios
  partidas: Record<string, PartidaPresupuestoAnual>; // tipoGastoId -> partidas
  fecha_creacion: Timestamp | FieldValue;
  usuario_creacion: string;
  fecha_modificacion?: Timestamp | FieldValue;
  usuario_modificacion?: string;
}

export const TIPOS_COMPROBANTE = [
  'Boleta',
  'Factura',
  'Recibo por Honorarios',
  'Recibo de Servicios',
  'Recibo Simple',
  'Nota de Crédito',
  'Nota de Débito',
  'Comprobante de Ingreso',
  'Otro'
] as const;

export type TipoComprobante = typeof TIPOS_COMPROBANTE[number];

// --- GESTIÓN DE EQUIPOS Y MANTENIMIENTOS (Requerimientos 011 & 012) ---

export type CategoriaEquipo =
  | 'bombas_agua'
  | 'ascensores'
  | 'electricidad_grupo'
  | 'seguridad_cctv'
  | 'contra_incendios'
  | 'portones_accesos'
  | 'piscina_areas'
  | 'cisternas_tanques'
  | 'climatizacion'
  | 'otros';

export type EstadoEquipo = 'operativo' | 'en_mantenimiento' | 'fuera_servicio' | 'requiere_inspeccion';

export type TipoMantenimiento =
  | 'preventivo'
  | 'correctivo'
  | 'inspeccion_certificacion'
  | 'rutinario'
  | 'emergencia';

export type EstadoMantenimiento = 'cotizacion' | 'programado' | 'en_proceso' | 'completado' | 'cancelado';

export type PrioridadMantenimiento = 'baja' | 'media' | 'alta' | 'urgente';

export type AfectacionServicio =
  | 'sin_afectacion'
  | 'corte_agua'
  | 'corte_luz'
  | 'corte_ascensor'
  | 'ruido_molesto'
  | 'acceso_restringido'
  | 'fumigacion'
  | 'otro';

export interface EquipoCondominio {
  id?: string;
  condominioId: string;
  nombre: string;
  codigo?: string;
  categoria: CategoriaEquipo;
  ubicacion: string;
  marca_modelo?: string;
  numero_serie?: string;
  fecha_instalacion?: Timestamp | Date | string | null;
  garantia_expira?: Timestamp | Date | string | null;
  estado: EstadoEquipo;
  frecuencia_mantenimiento_dias?: number;
  proveedor_preferido_id?: string;
  proveedor_preferido_nombre?: string;
  tipo_gasto_id?: string;
  tipo_gasto_nombre?: string;
  costo_estimado_mantenimiento?: number;
  notas?: string;
  fecha_creacion?: Timestamp | FieldValue | Date;
  usuario_creacion?: string;
  fecha_modificacion?: Timestamp | FieldValue | Date;
  usuario_modificacion?: string;
}

export interface EventoAdjudicacion {
  id?: string;
  tipo: 'adjudicacion' | 'cancelacion';
  fecha: Timestamp | Date | string;
  motivo?: string;
  usuario?: string;
  monto?: number;
  moneda?: string;
}

export interface SolicitudCotizacionProveedor {
  id: string; // Token único
  proveedor_id?: string;
  proveedor_nombre: string;
  proveedor_email: string;
  proveedor_telefono?: string;
  fecha_solicitud: Timestamp | Date | string;
  fecha_limite?: Timestamp | Date | string | null;
  fecha_expiracion?: Timestamp | Date | string | null;
  estado: 'enviada' | 'respondida' | 'adjudicada' | 'descartada' | 'expirada';
  monto_cotizado?: number;
  moneda?: string;
  incluye_igv?: boolean;
  tiempo_estimado?: string;
  validez_dias?: number;
  observaciones?: string;
  archivo_url?: string;
  archivo_nombre?: string;
  fecha_respuesta?: Timestamp | Date | string | null;
  intentos_envio?: number; // Contador de envíos (máx 2: 1 inicial + 1 actualización)
  max_intentos?: number;
  motivo_adjudicacion?: string;
  fecha_adjudicacion?: Timestamp | Date | string | null;
  motivo_cancelacion_adjudicacion?: string;
  fecha_cancelacion_adjudicacion?: Timestamp | Date | string | null;
  historial_adjudicaciones?: EventoAdjudicacion[];
}

export interface ComprobanteAsociadoMantenimiento {
  id: string; // ComprobantePago doc id
  tipo_comprobante?: string;
  nro_comprobante: string;
  monto: number;
  fecha_emision?: Timestamp | Date | string | null;
  proveedor_nombre?: string;
  proveedor_ruc?: string;
  archivo_url?: string;
}

export interface MantenimientoCondominio {
  id?: string;
  condominioId: string;
  codigo_ot?: string;
  titulo: string;
  descripcion?: string;
  tipo: TipoMantenimiento;
  categoria_equipo?: CategoriaEquipo | string;
  equipo_id?: string;
  equipo_nombre?: string;
  proveedor_id?: string;
  proveedor_nombre?: string;
  proveedor_contacto?: string;
  estado: EstadoMantenimiento;
  prioridad: PrioridadMantenimiento;
  fecha_programada_inicio: Timestamp | Date | string;
  fecha_programada_fin: Timestamp | Date | string;
  fecha_real_ejecucion?: Timestamp | Date | string | null;
  
  // Presupuesto & Finanzas
  tipo_gasto_id?: string;
  tipo_gasto_nombre?: string;
  costo_estimado?: number;
  costo_real?: number;
  moneda?: string;
  incluir_en_presupuesto?: boolean;
  comprobantes_asociados?: ComprobanteAsociadoMantenimiento[];
  
  // Cotizaciones RFQ
  solicitudes_cotizacion?: SolicitudCotizacionProveedor[];
  
  // Responsable y Cierre
  responsable_tecnico?: string;
  observaciones_cierre?: string;
  documentos_adjuntos?: { nombre: string; url: string; tipo: string; size?: number }[];
  
  // Comunicación Residentes
  es_publico_residentes?: boolean;
  afectacion_servicio?: AfectacionServicio;
  descripcion_afectacion?: string;
  recomendaciones_residentes?: string;
  // Plan Anual Preventivo (PAM)
  es_plan_anual?: boolean;
  plan_anual_id?: string;
  plan_anual_codigo?: string;
  plan_anual_anio?: number;
  
  fecha_creacion?: Timestamp | FieldValue | Date;
  usuario_creacion?: string;
  fecha_modificacion?: Timestamp | FieldValue | Date;
  usuario_modificacion?: string;
}

export interface PlanAnualPreventivo {
  id?: string;
  condominioId: string;
  codigo: string;
  anio: number;
  equipo_id: string;
  equipo_nombre: string;
  frecuencia_dias: number;
  dia_mes_sugerido: number;
  tipo_gasto_id?: string;
  tipo_gasto_nombre?: string;
  costo_estimado_servicio: number;
  moneda: string;
  total_mantenimientos: number;
  fecha_creacion?: Timestamp | Date | FieldValue;
  usuario_creacion?: string;
  fecha_modificacion?: Timestamp | Date | FieldValue;
  usuario_modificacion?: string;
}



