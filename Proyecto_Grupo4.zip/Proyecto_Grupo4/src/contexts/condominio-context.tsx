
"use client";

import type { ReactNode } from 'react';
import React, { createContext, useState, useContext, useEffect, useCallback } from 'react';

export interface SelectedCondominioInfo {
  id: string;
  nombre: string;
  imageUrl?: string;
  moneda?: string;
  chatbot_ia_activo?: boolean;
  chatbotIaActivo?: boolean;
}

interface CondominioContextType {
  selectedCondominio: SelectedCondominioInfo | null;
  setSelectedCondominio: (condo: SelectedCondominioInfo | null) => void;
  isLoading: boolean; // To indicate if context is still loading from localStorage
  openGroups: string[];
  setOpenGroups: (groups: string[] | ((prev: string[]) => string[])) => void;
  isSidebarMounted: boolean;
  setIsSidebarMounted: (mounted: boolean) => void;
}

const CondominioContext = createContext<CondominioContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'comunidad360-selected-condo';

export const CondominioProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [selectedCondominio, setSelectedCondominioState] = useState<SelectedCondominioInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [openGroups, setOpenGroups] = useState<string[]>([]);
  const [isSidebarMounted, setIsSidebarMounted] = useState(false);

  useEffect(() => {
    try {
      const storedCondoItem = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (storedCondoItem) {
        setSelectedCondominioState(JSON.parse(storedCondoItem));
      }
    } catch (error) {
      console.error("Failed to parse selected condominio from localStorage", error);
      localStorage.removeItem(LOCAL_STORAGE_KEY); // Clear corrupted data
    }
    setIsLoading(false);
  }, []);

  const setSelectedCondominio = useCallback((condo: SelectedCondominioInfo | null) => {
    setSelectedCondominioState(condo);
    if (condo) {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(condo));
    } else {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    }
  }, []);

  return (
    <CondominioContext.Provider value={{ 
      selectedCondominio, 
      setSelectedCondominio, 
      isLoading, 
      openGroups, 
      setOpenGroups,
      isSidebarMounted,
      setIsSidebarMounted
    }}>
      {children}
    </CondominioContext.Provider>
  );
};

export const useCondominioContext = () => {
  const context = useContext(CondominioContext);
  if (context === undefined) {
    throw new Error('useCondominioContext must be used within a CondominioProvider');
  }
  return context;
};
