
"use client";

import type { ReactNode } from 'react';
import React, { createContext, useState, useContext, useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { auth, db, createUserProfileDocument, getUserProfileDocument, checkIfSystemAdmin, getCondominiosForUser, googleProvider } from '@/lib/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { 
  onAuthStateChanged, 
  signOut as firebaseSignOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  sendPasswordResetEmail,
  type User as FirebaseUserType
} from 'firebase/auth';
import type { Condominio, UserNotificationSettings } from '@/types';

interface User {
  uid: string;
  email: string | null;
  displayName?: string | null;
  photoURL?: string | null;
  role: string;
  roles: string[];
  isSystemAdmin?: boolean;
  assignedCondominios?: Condominio[] | null;
  telefono?: string;
  contactoEmergenciaNombre?: string;
  contactoEmergenciaRelacion?: string;
  contactoEmergenciaTelefono?: string;
  vehiculos?: Array<{ patente: string; marca: string; modelo: string; color: string }>;
  mascotas?: Array<{ nombre: string; especie: string; raza: string; fotoUrl?: string }>;
  preferenciasNotificaciones?: UserNotificationSettings;
  idiomaPreferido?: 'es' | 'en';
  temaPreferido?: 'claro' | 'oscuro' | 'sistema';
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, pass: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  register: (email: string, pass: string, displayName?: string) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updateUserProfile: (profileData: Partial<User>) => Promise<void>;
  loading: boolean; 
  authLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [operationLoading, setOperationLoading] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser: FirebaseUserType | null) => {
      setAuthLoading(true);
      if (firebaseUser) {
        let userProfile = await getUserProfileDocument(firebaseUser.uid);
        let systemAdminStatus = false;
        let userAssignedCondominios: Condominio[] | null = null;

        const normalizedEmail = firebaseUser.email?.toLowerCase().trim() || null;

        if (!userProfile) {
          await createUserProfileDocument(firebaseUser, { 
            roles: ['user'], 
            displayName: firebaseUser.displayName || normalizedEmail?.split('@')[0] || '',
            isSystemAdmin: false,
            photoURL: firebaseUser.photoURL,
            email: normalizedEmail
          });
          userProfile = await getUserProfileDocument(firebaseUser.uid);
        }

        if (userProfile) {
          systemAdminStatus = userProfile.isSystemAdmin || false;
          if (normalizedEmail && !systemAdminStatus) {
             userAssignedCondominios = await getCondominiosForUser(normalizedEmail);
          }
          
          const primaryRole = userProfile.roles?.includes('admin') ? 'admin' : 
                              userProfile.roles?.includes('editor') ? 'editor' : 
                              userProfile.roles?.includes('viewer') ? 'viewer' : 'user';

          const currentUserData: User = {
            uid: firebaseUser.uid,
            email: normalizedEmail,
            displayName: userProfile.displayName || firebaseUser.displayName,
            photoURL: userProfile.photoURL || firebaseUser.photoURL,
            roles: userProfile.roles || ['user'],
            role: primaryRole,
            isSystemAdmin: systemAdminStatus,
            assignedCondominios: userAssignedCondominios,
            telefono: userProfile.telefono || '',
            contactoEmergenciaNombre: userProfile.contactoEmergenciaNombre || '',
            contactoEmergenciaRelacion: userProfile.contactoEmergenciaRelacion || '',
            contactoEmergenciaTelefono: userProfile.contactoEmergenciaTelefono || '',
            vehiculos: userProfile.vehiculos || [],
            mascotas: userProfile.mascotas || [],
            preferenciasNotificaciones: userProfile.preferenciasNotificaciones || {
              projects: { app: true, email: true, push: true },
              payments: { app: true, email: true, push: true },
              reservations: { app: true, email: true, push: true },
              visits: { app: true, email: true, push: true },
              tickets: { app: true, email: true, push: true },
              announcements: { app: true, email: true, push: true },
            },
            idiomaPreferido: userProfile.idiomaPreferido || 'es',
            temaPreferido: userProfile.temaPreferido || 'sistema',
          };
          setUser(currentUserData);
        } else {
            setUser(null);
        }

      } else {
        setUser(null);
      }
      setAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!authLoading && !isLoggingOut) {
      // Register removed from public paths to enforce admin creation
      const publicPaths = ['/', '/login', '/presentacion', '/demo'];
      const isPublicPath = publicPaths.includes(pathname) || pathname.startsWith('/__');

      if (!user && !isPublicPath) {
        router.push('/login');
      } else if (user) {
        // Logged in users cannot see login. 
        // Only system admins can see register.
        if (pathname === '/login') {
          window.location.href = '/';
        } else if (pathname === '/register' && !user.isSystemAdmin) {
          router.push('/');
        }
      }
    }
  }, [user, authLoading, pathname, router, isLoggingOut]);

  const login = async (email: string, pass: string) => {
    setOperationLoading(true);
    const normalizedEmail = email.toLowerCase().trim();
    try {
      await signInWithEmailAndPassword(auth, normalizedEmail, pass);
    } catch (error) {
      console.error("Login error:", error);
      setOperationLoading(false);
      throw error;
    }
  };

  const loginWithGoogle = async () => {
    setOperationLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Google login error:", error);
      setOperationLoading(false);
      throw error;
    }
  };

  const register = async (email: string, pass: string, displayName?: string) => {
    setOperationLoading(true);
    const normalizedEmail = email.toLowerCase().trim();
    try {
      await createUserWithEmailAndPassword(auth, normalizedEmail, pass);
    } catch (error) {
      console.error("Registration error:", error);
      throw error;
    } finally {
      setOperationLoading(false);
    }
  };

  const logout = async () => {
    setIsLoggingOut(true);
    try {
      await firebaseSignOut(auth);
      window.location.href = '/login';
    } catch (error) {
      console.error("Logout error:", error);
      setIsLoggingOut(false);
    }
  };

  const updateUserProfile = async (profileData: Partial<User>) => {
    if (!user) return;
    setOperationLoading(true);
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, profileData);
      setUser(prev => prev ? { ...prev, ...profileData } : null);
    } catch (error) {
      console.error("Error updating user profile:", error);
      throw error;
    } finally {
      setOperationLoading(false);
    }
  };

  const resetPassword = async (email: string) => {
    setOperationLoading(true);
    const normalizedEmail = email.toLowerCase().trim();
    try {
      await sendPasswordResetEmail(auth, normalizedEmail);
    } catch (error) {
      console.error("Password reset error:", error);
      throw error;
    } finally {
      setOperationLoading(false);
    }
  }

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      login,
      loginWithGoogle,
      register,
      logout,
      resetPassword,
      updateUserProfile,
      loading: operationLoading,
      authLoading
    }}>
      {(authLoading || isLoggingOut) && pathname !=='/login' && pathname !=='/register' ? <LoadingScreen /> : children}
    </AuthContext.Provider>
  );
};

const LoadingScreen: React.FC = () => (
  <div className="flex items-center justify-center h-screen bg-background">
    <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary"></div>
  </div>
);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
