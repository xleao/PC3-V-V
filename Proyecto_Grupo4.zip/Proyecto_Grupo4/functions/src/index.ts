import {onSchedule} from "firebase-functions/v2/scheduler";
import * as admin from "firebase-admin";

if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();

interface MoraConfig {
  mora_activa: boolean;
  mora_tipo: "porcentaje" | "monto_fijo";
  mora_valor: number;
  mora_periodo_gracia: number;
  mora_metodo_generacion: "incluir_en_recibo" | "recibo_independiente";
  mora_intervalo_unidad: "diario" | "semanal" | "mensual" | "unico";
  mora_intervalo_valor: number;
}

/**
 * Returns the start of the day for a given date.
 * @param {Date} date The input date.
 * @return {Date} The date at 00:00:00.
 */
function startOfDayJS(date: Date): Date {
  const newDate = new Date(date);
  newDate.setHours(0, 0, 0, 0);
  return newDate;
}

/**
 * Calculates the difference in days between two dates.
 * @param {Date} d1 The first date.
 * @param {Date} d2 The second date.
 * @return {number} The difference in days.
 */
function differenceInDaysJS(d1: Date, d2: Date): number {
  const msPerDay = 1000 * 60 * 60 * 24;
  const utc1 = Date.UTC(d1.getFullYear(), d1.getMonth(), d1.getDate());
  const utc2 = Date.UTC(d2.getFullYear(), d2.getMonth(), d2.getDate());
  return Math.floor((utc1 - utc2) / msPerDay);
}

/**
 * Calculates the late fee for the daily cron report.
 * @param {number} montoPrincipal The principal balance.
 * @param {any} fechaVencimiento The due date of the receipt.
 * @param {MoraConfig} config The interest configuration.
 * @param {Date} [fechaReferencia] The date of reference for calculation.
 * @return {number} The calculated late fee.
 */
function calcularMoraLocal(
  montoPrincipal: number,
  fechaVencimiento: any,
  config: MoraConfig,
  fechaReferencia: Date = new Date()
): number {
  if (!config || !config.mora_activa || !fechaVencimiento) return 0;

  let due: Date;
  if (fechaVencimiento instanceof Date) {
    due = fechaVencimiento;
  } else if (typeof fechaVencimiento.toDate === "function") {
    due = fechaVencimiento.toDate();
  } else {
    due = new Date(fechaVencimiento);
  }

  const startOfDue = startOfDayJS(due);
  const startOfToday = startOfDayJS(fechaReferencia);

  const diasAtrasoTotal = differenceInDaysJS(startOfToday, startOfDue);
  const diasEfectivos = diasAtrasoTotal - (config.mora_periodo_gracia || 0);

  if (diasEfectivos <= 0) return 0;

  let multiplicador = 1;
  const unidad = config.mora_intervalo_unidad || "mensual";
  const valorIntervalo = config.mora_intervalo_valor || 1;

  if (unidad === "diario") {
    multiplicador = Math.ceil(diasEfectivos / valorIntervalo);
  } else if (unidad === "semanal") {
    multiplicador = Math.ceil(diasEfectivos / (7 * valorIntervalo));
  } else if (unidad === "mensual") {
    multiplicador = Math.ceil(diasEfectivos / (30 * valorIntervalo));
  } else if (unidad === "unico") {
    multiplicador = 1;
  }

  if (config.mora_tipo === "porcentaje") {
    return (montoPrincipal * (config.mora_valor / 100)) * multiplicador;
  } else {
    return config.mora_valor * multiplicador;
  }
}

/**
 * Genera el reporte de morosidad (snapshot) para todos los condominios.
 */
export const generarReporteMorosidadGlobal = onSchedule(
  "every 24 hours",
  async () => {
    const condominiosSnap = await db.collection("condominios").get();

    for (const condoDoc of condominiosSnap.docs) {
      const condoId = condoDoc.id;

      try {
        console.log(`[Sync] Iniciando proceso global para: ${condoId}`);

        const daysAgo = new Date();
        daysAgo.setDate(daysAgo.getDate() - 30);

        // 1. MARCAR RECIBOS COMO PAGADOS
        const pSnap = await db
          .collectionGroup("registros_pago")
          .where("condominioId", "==", condoId)
          .where("pago_estado_validacion", "==", "validado")
          .where("pago_fecha_validacion", ">=",
            admin.firestore.Timestamp.fromDate(daysAgo))
          .get();

        const ecUpdates = new Map<string, admin.firestore.DocumentReference>();
        const ecUpdateData = new Map<string, admin.firestore.UpdateData<any>>();

        pSnap.docs.forEach((pDoc) => {
          const data = pDoc.data();
          if (!data.procesado_sync) {
            const ecRef = pDoc.ref.parent.parent;
            if (ecRef) {
              ecUpdates.set(ecRef.path, ecRef);
              ecUpdateData.set(ecRef.path, {
                estado: "Pagado",
                fecha_pago_completo: data.pago_fecha_validacion ||
                  data.pago_fecha_registro ||
                  admin.firestore.FieldValue.serverTimestamp(),
              });
              ecUpdates.set(pDoc.ref.path, pDoc.ref);
              ecUpdateData.set(pDoc.ref.path, {procesado_sync: true});
            }
          }
        });

        if (ecUpdates.size > 0) {
          let batch = db.batch();
          let ops = 0;
          for (const [path, ref] of ecUpdates.entries()) {
            const updateData = ecUpdateData.get(path);
            if (updateData) {
              batch.update(ref, updateData);
              ops++;
            }
            if (ops === 450) {
              await batch.commit();
              batch = db.batch();
              ops = 0;
            }
          }
          if (ops > 0) {
            await batch.commit();
          }
        }

        // 2. RECALCULAR SALDOS
        const configSnap = await db
          .collection("condominios")
          .doc(condoId)
          .collection("config")
          .doc("general")
          .get();
        const config = configSnap.exists ?
          (configSnap.data() as MoraConfig) :
          null;

        const deptsSnap = await db
          .collection("condominios")
          .doc(condoId)
          .collection("departamentos")
          .get();

        let totalDeuda = 0;
        let totalDeudaVencida = 0;
        let totalDeudaVencidaPrincipal = 0;
        let totalDeudaVencidaMora = 0;
        let totalDeudaEnPlazo = 0;
        let unidadesConDeudaVencida = 0;
        let unidadesConDeudaEnPlazo = 0;
        let unidadesSinDeuda = 0;
        const totalUnidades = deptsSnap.size;
        const rankingRaw: Array<Record<string, unknown>> = [];

        const chunkSize = 20;
        for (let i = 0; i < deptsSnap.docs.length; i += chunkSize) {
          const chunk = deptsSnap.docs.slice(i, i + chunkSize);
          await Promise.all(chunk.map(async (deptDoc) => {
            const dData = deptDoc.data();
            const dId = deptDoc.id;

            const eccSnap = await db
              .collection("condominios")
              .doc(condoId)
              .collection("departamentos")
              .doc(dId)
              .collection("estado_cuenta")
              .where("estado", "in", ["Pendiente de pago", "Vencido"])
              .get();

            let saldoDept = 0;
            let saldoVencido = 0;
            let saldoVencidoPrincipal = 0;
            let saldoVencidoMora = 0;
            let saldoEnPlazo = 0;
            let mesesTotal = 0;
            let tieneDeudaVencida = false;
            const now = new Date();

            for (const ecDoc of eccSnap.docs) {
              const ecData = ecDoc.data();
              if (ecData.isPublished !== true) continue;

              // Query registros_pago subcollection
              const paymentsSnap = await db
                .collection("condominios")
                .doc(condoId)
                .collection("departamentos")
                .doc(dId)
                .collection("estado_cuenta")
                .doc(ecDoc.id)
                .collection("registros_pago")
                .where("pago_estado_validacion", "==", "validado")
                .get();

              let totalPagadoValidado = 0;
              paymentsSnap.forEach((pDoc) => {
                totalPagadoValidado += Number(pDoc.data().pago_importe) || 0;
              });

              const totalReceipt = Number(ecData.total) || 0;
              const pendienteVal = Math.max(
                0,
                totalReceipt - totalPagadoValidado
              );

              if (pendienteVal <= 0) continue;

              let dateVencimiento: Date | null = null;
              if (ecData.fecha_vencimiento instanceof
                  admin.firestore.Timestamp) {
                dateVencimiento = ecData.fecha_vencimiento.toDate();
              } else if (ecData.fecha_vencimiento) {
                dateVencimiento = new Date(ecData.fecha_vencimiento);
              }

              const startOfDue = dateVencimiento ? startOfDayJS(dateVencimiento) : null;
              const startOfToday = startOfDayJS(now);
              const isOverdue = ecData.estado === "Vencido" ||
                (startOfDue && startOfDue < startOfToday);

              if (isOverdue) {
                const moraVal = (config && config.mora_activa) ?
                  calcularMoraLocal(
                    pendienteVal,
                    dateVencimiento,
                    config,
                    now
                  ) :
                  0;
                const totalVal = pendienteVal + moraVal;
                saldoVencido += totalVal;
                saldoVencidoPrincipal += pendienteVal;
                saldoVencidoMora += moraVal;
                saldoDept += totalVal;
                mesesTotal++;
                tieneDeudaVencida = true;
              } else {
                saldoEnPlazo += pendienteVal;
                saldoDept += pendienteVal;
              }
            }

            if (dData.saldo_actual !== Number(saldoDept.toFixed(2)) ||
                dData.meses_atraso !== mesesTotal) {
              await db
                .collection("condominios")
                .doc(condoId)
                .collection("departamentos")
                .doc(dId)
                .update({
                  saldo_actual: Number(saldoDept.toFixed(2)),
                  meses_atraso: mesesTotal,
                });
            }

            if (saldoDept > 0) {
              totalDeuda += saldoDept;
              totalDeudaVencida += saldoVencido;
              totalDeudaVencidaPrincipal += saldoVencidoPrincipal;
              totalDeudaVencidaMora += saldoVencidoMora;
              totalDeudaEnPlazo += saldoEnPlazo;

              if (tieneDeudaVencida) {
                unidadesConDeudaVencida++;
              } else {
                unidadesConDeudaEnPlazo++;
              }

              rankingRaw.push({
                id: dId,
                dueño: dData.dueño_nombre || "Desconocido",
                torre: dData.torre || "N/A",
                monto: Number(saldoDept.toFixed(2)),
                montoVencido: Number(saldoVencido.toFixed(2)),
                montoVencidoPrincipal: Number(saldoVencidoPrincipal.toFixed(2)),
                montoVencidoMora: Number(saldoVencidoMora.toFixed(2)),
                montoEnPlazo: Number(saldoEnPlazo.toFixed(2)),
                mesesAtraso: mesesTotal,
              });
            } else {
              unidadesSinDeuda++;
            }
          }));
        }

        // 3. ACTUALIZAR SNAPSHOT FINAL
        const snapshotData = {
          totalDeuda: Number(totalDeuda.toFixed(2)),
          totalDeudaVencida: Number(totalDeudaVencida.toFixed(2)),
          totalDeudaVencidaPrincipal: Number(
            totalDeudaVencidaPrincipal.toFixed(2)
          ),
          totalDeudaVencidaMora: Number(
            totalDeudaVencidaMora.toFixed(2)
          ),
          totalDeudaEnPlazo: Number(totalDeudaEnPlazo.toFixed(2)),
          tasaMorosidad: totalUnidades > 0 ?
            (unidadesConDeudaVencida / totalUnidades) * 100 : 0,
          unidadesConDeuda: unidadesConDeudaVencida + unidadesConDeudaEnPlazo,
          unidadesConDeudaVencida,
          unidadesConDeudaEnPlazo,
          unidadesSinDeuda,
          totalUnidades,
          rankingDeudores: rankingRaw.sort((a, b) => {
            const aHasVencido = ((a.montoVencido as number) ?? 0) > 0;
            const bHasVencido = ((b.montoVencido as number) ?? 0) > 0;
            if (aHasVencido && !bHasVencido) return -1;
            if (!aHasVencido && bHasVencido) return 1;
            if (aHasVencido && bHasVencido) {
              return ((b.montoVencido as number) ?? 0) -
                ((a.montoVencido as number) ?? 0);
            }
            return ((b.montoEnPlazo as number) ?? 0) -
              ((a.montoEnPlazo as number) ?? 0);
          }).slice(0, 50),
          fechaSnapshot: admin.firestore.FieldValue.serverTimestamp(),
        };

        await db
          .collection("condominios")
          .doc(condoId)
          .collection("reportes_morosidad")
          .doc("ultimo_snapshot")
          .set(snapshotData);

        console.log(`[Success] Sincronización completa para: ${condoId}`);
      } catch (error) {
        console.error(`[Error] Falló sincronización en ${condoId}:`, error);
      }
    }
  }
);

/**
 * Libera automáticamente las reservas que no han sido pagadas.
 */
export const autoliberarReservasExpiradas = onSchedule(
  "every 1 hours",
  async () => {
    const now = admin.firestore.Timestamp.now();

    try {
      console.log("[AutoRelease] Iniciando limpieza de reservas...");

      const expiredSnap = await db
        .collectionGroup("reservas")
        .where("estado", "==", "SOLICITADO")
        .where("pago_diferido", "==", true)
        .where("pago_diferido_fecha_limite", "<", now)
        .get();

      if (expiredSnap.empty) {
        return;
      }

      const batch = db.batch();
      let cancelCount = 0;

      expiredSnap.docs.forEach((resDoc) => {
        const data = resDoc.data() || {};

        // Evitar cancelar si el usuario ya registró el comprobante de pago
        const hasVoucher = !!(data.pagoNroOperacion || data.pagoConstanciaUrl || data.voucher_url);
        if (hasVoucher) {
          console.log(`[AutoRelease] Saltando reserva ${resDoc.id} porque ya tiene comprobante registrado.`);
          return;
        }

        batch.update(resDoc.ref, {
          estado: "CANCELADO_ADMIN",
          notasAdmin: "Cancelación automática: Plazo expirado.",
          fechaModificacion: admin.firestore.FieldValue.serverTimestamp(),
          usuarioModificacion: "system-auto-release",
          ...(data.montoGarantia && data.montoGarantia > 0 ? { garantia_estado: "cancelado" } : {}),
          ...(data.pago_requerido || data.montoTotal > 0 ? { pago_estado_validacion: "cancelado" } : {})
        });
        cancelCount++;
      });

      if (cancelCount > 0) {
        await batch.commit();
        console.log(`[AutoRelease] Limpieza completada. Reservas anuladas: ${cancelCount}`);
      }
    } catch (error) {
      console.error("[AutoRelease] Error:", error);
    }
  }
);

/**
 * Envía recordatorios de pago consolidados periódicos de acuerdo al calendario de cada condominio.
 */
export const despacharRecordatoriosPeriodicos = onSchedule(
  "every 24 hours",
  async () => {
    const today = new Date();
    const todayDayNum = today.getDate();
    const todayString = today.toISOString().split("T")[0]; // YYYY-MM-DD

    // Calculate if today is the last day of the month
    const tomorrow = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
    const isLastDayOfMonth = tomorrow.getDate() === 1;

    const baseUrl = process.env.APP_URL || "https://www.comunidad360app.com";
    const condominiosSnap = await db.collection("condominios").get();

    for (const condoDoc of condominiosSnap.docs) {
      const condoId = condoDoc.id;
      const condoData = condoDoc.data() || {};

      try {
        // Fetch configurations
        const configDoc = await db.collection("condominios").doc(condoId).collection("config").doc("general").get();
        if (!configDoc.exists) continue;

        const config = configDoc.data() || {};
        if (!config.recordatorios_activos) continue;

        const scheduledDays = config.recordatorios_dias_mes || [];
        const isScheduledToday = scheduledDays.includes(todayDayNum) || 
          (scheduledDays.includes("ultimo") && isLastDayOfMonth);

        if (!isScheduledToday) continue;

        // Prevent duplicates
        const runRecordRef = db.collection("condominios").doc(condoId).collection("registro_recordatorios").doc(todayString);
        const runRecordDoc = await runRecordRef.get();
        if (runRecordDoc.exists) continue;

        // Fetch departments
        const deptsSnap = await db.collection("condominios").doc(condoId).collection("departamentos").get();
        if (deptsSnap.empty) continue;

        let sentCount = 0;

        for (const deptDoc of deptsSnap.docs) {
          const dept = deptDoc.data() || {};
          const deptId = deptDoc.id;

          const recipientEmails = new Set<string>();
          if (dept.dueño_correo?.includes("@")) {
            recipientEmails.add(dept.dueño_correo.toLowerCase().trim());
          }
          if (Array.isArray(dept.correos_notificaciones)) {
            dept.correos_notificaciones.forEach((em: string) => {
              if (em?.includes("@")) recipientEmails.add(em.toLowerCase().trim());
            });
          }

          if (recipientEmails.size === 0) continue;

          // Fetch outstanding receipts
          const receiptsSnap = await db.collection("condominios").doc(condoId)
            .collection("departamentos").doc(deptId)
            .collection("estado_cuenta")
            .where("isPublished", "==", true)
            .where("estado", "in", ["Pendiente de pago", "Vencido"])
            .get();

          if (receiptsSnap.empty) continue;

          const groupedReceipts: Record<string, any[]> = {};
          receiptsSnap.docs.forEach(docSnap => {
            const receipt = docSnap.data() || {};
            const principal = Math.max(0, (receipt.total || 0) - (receipt.total_pagado_validado || 0));

            if (principal <= 0) return;

            const mora = calcularMoraLocal(principal, receipt.fecha_vencimiento, config as any, today);
            const total = principal + mora;

            const currency = receipt.moneda || condoData.moneda || "S/";
            if (!groupedReceipts[currency]) {
              groupedReceipts[currency] = [];
            }

            groupedReceipts[currency].push({
              periodo: receipt.periodo || "",
              nro_recibo: receipt.nro_recibo || "",
              fecha_vencimiento: receipt.fecha_vencimiento,
              estado: receipt.estado || "",
              principal,
              mora,
              total
            });
          });

          const currencies = Object.keys(groupedReceipts);
          if (currencies.length === 0) continue;

          const condoName = condoData.nombre || "tu condominio";
          const bankDetails = condoData.detalles_bancarios || "<p style=\"color: #64748b; font-size: 12px; margin: 0;\">No hay detalles registrados.</p>";

          // Build HTML
          let htmlContent = `
            <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 20px; background-color: #ffffff; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);">
              <div style="background: linear-gradient(135deg, #0a9396 0%, #1e3a8a 100%); padding: 30px 20px; border-radius: 14px 14px 0 0; text-align: center; color: #ffffff;">
                <span style="background: rgba(255,255,255,0.2); color: white; padding: 4px 12px; border-radius: 50px; font-size: 11px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.1em;">
                  Notificación de Cobranza
                </span>
                <h2 style="margin: 15px 0 5px 0; font-size: 24px; font-weight: 800; color: #ffffff;">Recordatorio de Pago</h2>
                <p style="margin: 0; font-size: 13px; opacity: 0.9;">Dpto. ${deptId} - ${condoName}</p>
              </div>

              <div style="padding: 20px 5px; color: #334155; font-size: 15px; line-height: 1.6;">
                <p style="margin-top: 0;">Estimado(a) propietario/residente,</p>
                <p>Te enviamos este estado de cuenta consolidado con el detalle de tus recibos de mantenimiento pendientes de pago a la fecha:</p>
          `;

          currencies.forEach(currency => {
            const list = groupedReceipts[currency];
            const sumTotal = list.reduce((sum, item) => sum + item.total, 0);

            htmlContent += `
              <div style="background: #f8fafc; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; text-align: center; margin: 20px 0;">
                <p style="margin: 0; font-size: 12px; color: #64748b; font-weight: bold; text-transform: uppercase; letter-spacing: 0.05em;">Total Pendiente (${currency})</p>
                <h1 style="margin: 8px 0 0 0; font-size: 32px; font-weight: 800; color: #1e3a8a;">${currency} ${sumTotal.toFixed(2)}</h1>
              </div>

              <div style="overflow-x: auto; margin-bottom: 25px;">
                <table style="width: 100%; border-collapse: collapse; min-width: 500px; text-align: left; font-size: 13px;">
                  <thead>
                    <tr style="border-bottom: 2px solid #e2e8f0; color: #475569; font-weight: 700;">
                      <th style="padding: 10px 6px;">Período</th>
                      <th style="padding: 10px 6px;">Nro. Recibo</th>
                      <th style="padding: 10px 6px;">Vencimiento</th>
                      <th style="padding: 10px 6px; text-align: right;">Principal</th>
                      <th style="padding: 10px 6px; text-align: right;">Mora</th>
                      <th style="padding: 10px 6px; text-align: right;">Total</th>
                    </tr>
                  </thead>
                  <tbody>
            `;

            list.forEach(item => {
              const dueDate = item.fecha_vencimiento?.toDate ? item.fecha_vencimiento.toDate() : new Date(item.fecha_vencimiento);
              const formattedDate = dueDate ? `${String(dueDate.getDate()).padStart(2, "0")}/${String(dueDate.getMonth() + 1).padStart(2, "0")}/${dueDate.getFullYear()}` : "N/A";
              const isOverdue = item.estado === "Vencido";

              htmlContent += `
                <tr style="border-bottom: 1px solid #f1f5f9; color: #334155;">
                  <td style="padding: 12px 6px; font-weight: 600;">${item.periodo}</td>
                  <td style="padding: 12px 6px; font-family: monospace;">${item.nro_recibo || "S/N"}</td>
                  <td style="padding: 12px 6px;">
                    ${formattedDate} 
                    ${isOverdue ? "<span style=\"color: #ef4444; font-size: 10px; font-weight: bold; margin-left: 4px;\">⚠️</span>" : ""}
                  </td>
                  <td style="padding: 12px 6px; text-align: right;">${currency} ${item.principal.toFixed(2)}</td>
                  <td style="padding: 12px 6px; text-align: right; color: ${item.mora > 0 ? "#ef4444" : "#64748b"}; font-weight: ${item.mora > 0 ? "600" : "normal"};">
                    ${currency} ${item.mora.toFixed(2)}
                  </td>
                  <td style="padding: 12px 6px; text-align: right; font-weight: 700; color: #0f172a;">
                    ${currency} ${item.total.toFixed(2)}
                  </td>
                </tr>
              `;
            });

            htmlContent += `
                  </tbody>
                </table>
              </div>
            `;
          });

          htmlContent += `
                <div style="text-align: center; margin: 30px 0;">
                  <a href="${baseUrl}/condominios/${condoId}/departamentos/${deptId}/estado-de-cuenta" style="display: inline-block; background-color: #4f46e5; color: #ffffff; padding: 12px 32px; font-size: 14px; font-weight: bold; text-decoration: none; border-radius: 8px; box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.2);">
                    Ver detalle y pagar
                  </a>
                </div>

                <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px; margin-bottom: 20px;">
                  <h3 style="margin-top: 0; margin-bottom: 8px; font-size: 13px; color: #1e293b; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;">Cuentas Bancarias para Depósito/Transferencia:</h3>
                  <div style="font-size: 12.5px; color: #475569; line-height: 1.6;">
                    ${bankDetails}
                  </div>
                </div>

                <p style="font-size: 12px; color: #64748b; margin-bottom: 0;">Una vez realizado el depósito o transferencia, recuerda registrar el comprobante de pago en el aplicativo para su validación por parte de la administración.</p>
              </div>

              <div style="font-size: 11px; color: #94a3b8; text-align: center; border-top: 1px solid #f1f5f9; padding-top: 15px; margin-top: 15px;">
                Este es un correo automático enviado en representación del condominio ${condoName}.
              </div>
            </div>
          `;

          // Queue email
          const emailsList = Array.from(recipientEmails);
          for (const email of emailsList) {
            await db.collection("mail").add({
              to: email,
              message: {
                subject: `📌 Estado de Cuenta Consolidado - Dpto. ${deptId} - ${condoName}`,
                html: htmlContent
              },
              metadata: {
                condominioId: condoId,
                departamentoId: deptId,
                type: "consolidated_reminder",
                triggeredAt: admin.firestore.Timestamp.fromDate(today)
              }
            });
            sentCount++;
          }
        }

        // Save execution audit log
        await runRecordRef.set({
          fecha: admin.firestore.FieldValue.serverTimestamp(),
          manual: false,
          correosEnviados: sentCount
        });

        console.log(`[Sync] Reminders sent for condo ${condoId}: ${sentCount}`);
      } catch (err: any) {
        console.error(`[Sync] Error sending reminders for condo ${condoId}:`, err);
      }
    }
  }
);

